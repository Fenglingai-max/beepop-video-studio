from pathlib import Path
import tempfile,zipfile,hashlib,subprocess,os,unittest
WORKER=Path(__file__).resolve().parent/'macos/worker.zsh'
class WorkerTests(unittest.TestCase):
 def fixture(self,folder,script):
  resources=folder/'应用 中文/Resources';resources.mkdir(parents=True)
  with zipfile.ZipFile(resources/'payload.zip','w') as z:z.writestr('启动beepoptvc.command',script)
  (resources/'payload.sha256').write_text(hashlib.sha256((resources/'payload.zip').read_bytes()).hexdigest())
  support=folder/'支持 中文';env={**os.environ,'BEEPOP_SUPPORT_DIR':str(support)}
  return resources,support,env
 def test_failure_retry_lock_cleanup_and_private_data_path(self):
  with tempfile.TemporaryDirectory() as t:
   r,s,e=self.fixture(Path(t),'echo "$BEEPOP_DATA_DIR"\necho "详细错误"\nexit 17\n')
   for _ in range(2):
    p=subprocess.run(['/bin/zsh',str(WORKER),str(r)],env=e);self.assertEqual(p.returncode,1)
    self.assertIn('详细错误',(s/'failed').read_text());self.assertIn(str(s/'data'),(s/'startup.log').read_text());self.assertFalse((s/'launcher.lock').exists())
   self.assertEqual(len(list(s.glob('runtime-*'))),1)
 def test_corrupt_payload_is_rejected_before_execution(self):
  with tempfile.TemporaryDirectory() as t:
   r,s,e=self.fixture(Path(t),'touch NEVER_RUN\n');(r/'payload.zip').write_bytes(b'corrupt')
   p=subprocess.run(['/bin/zsh',str(WORKER),str(r)],env=e);self.assertEqual(p.returncode,1);self.assertIn('校验失败',(s/'failed').read_text());self.assertEqual(list(s.glob('runtime-*')),[])
 def test_running_lock_does_not_start_duplicate_worker(self):
  with tempfile.TemporaryDirectory() as t:
   r,s,e=self.fixture(Path(t),'exit 17\n');lock=s/'launcher.lock';lock.mkdir(parents=True);(lock/'pid').write_text(str(os.getpid()))
   p=subprocess.run(['/bin/zsh',str(WORKER),str(r)],env=e);self.assertEqual(p.returncode,0);self.assertFalse((s/'startup.log').exists())
if __name__=='__main__':unittest.main()
