#!/usr/bin/env python3
"""Build clean, platform-specific installers from the verified production payload."""
from pathlib import Path
import argparse,hashlib,io,json,shutil,stat,subprocess,tempfile,zipfile
ROOT=Path(__file__).resolve().parent.parent

def digest(b): return hashlib.sha256(b).hexdigest()
def archive(path, files):
    with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for name,data,mode in sorted(files):
            i=zipfile.ZipInfo(name,(2026,11,27,0,0,0));i.create_system=3;i.compress_type=zipfile.ZIP_DEFLATED;i.external_attr=(stat.S_IFREG|mode)<<16;z.writestr(i,data)

def base_files():
    m=json.loads((ROOT/'companion-v6-resources.json').read_text())
    b=b''.join((ROOT/p).read_bytes() for p in m['parts'])
    if len(b)!=m['bytes'] or digest(b)!=m['sha256']: raise ValueError('Base archive checksum mismatch')
    files={}
    with zipfile.ZipFile(io.BytesIO(b)) as z:
        for i in z.infolist():
            p=Path(i.filename)
            if p.parts[0]!='beepoptvc' or '..' in p.parts or p.is_absolute(): raise ValueError('Unsafe payload path')
            if i.is_dir():continue
            rel=Path(*p.parts[1:])
            if any(x in {'data','node_modules','_runtime','.git','__pycache__'} for x in rel.parts):raise ValueError('Runtime data in source archive')
            if rel.name in {'auth.json','connections.json','relay.json','.env'} or rel.suffix in {'.pem','.key','.sqlite','.log'}:raise ValueError('Private file in source archive')
            files[rel.as_posix()]=(z.read(i),0o755 if rel.suffix=='.command' else 0o644)
    for name in ['start.cjs','启动beepoptvc.command']:
        files[name]=((ROOT/'oneclick'/name).read_bytes(),0o755 if name.endswith('.command') else 0o644)
    return files,m

def build(output):
    output.mkdir(parents=True,exist_ok=True)
    files,base=base_files()
    with tempfile.TemporaryDirectory(prefix='beepop-oneclick-') as tmp:
        tmp=Path(tmp);app=tmp/'BeePOP.app'
        subprocess.run(['/usr/bin/osacompile','-o',str(app),str(ROOT/'oneclick/macos/launcher.applescript')],check=True)
        resources=app/'Contents/Resources'
        archive(resources/'payload.zip',[(n,b,mode) for n,(b,mode) in files.items()])
        (resources/'payload.sha256').write_text(digest((resources/'payload.zip').read_bytes())+'\n')
        shutil.copyfile(ROOT/'oneclick/macos/worker.zsh',resources/'worker.zsh')
        subprocess.run(['/usr/bin/xattr','-cr',str(app)],check=True)
        subprocess.run(['/usr/bin/codesign','--force','--sign','-',str(app)],check=True)
        subprocess.run(['/usr/bin/codesign','--verify','--deep','--strict',str(app)],check=True)
        mac=output/'BeePOP-macOS.zip'
        archive(mac,[('BeePOP.app/'+p.relative_to(app).as_posix(),p.read_bytes(),p.stat().st_mode&0o777) for p in app.rglob('*') if p.is_file()])
        win=output/'BeePOP-Windows.zip'
        archive(win,[('BeePOP/内部组件/'+n,b,mode) for n,(b,mode) in files.items()]+[('BeePOP/启动BeePOP.cmd',(ROOT/'oneclick/windows/启动BeePOP.cmd').read_bytes().replace(b'\n',b'\r\n'),0o644)])
    manifest={'schema':1,'version':'1.0.0','executionVersion':base['version'],'baseSha256':base['sha256'],'platforms':{}}
    for platform,filename in [('macos','BeePOP-macOS.zip'),('windows','BeePOP-Windows.zip')]:
        b=(output/filename).read_bytes();parts=[]
        for index,offset in enumerate(range(0,len(b),600000),1):
            name=f'companion-oneclick-{platform}-{index:02}.bin';(ROOT/name).write_bytes(b[offset:offset+600000]);parts.append(name)
        manifest['platforms'][platform]={'filename':filename,'bytes':len(b),'sha256':digest(b),'parts':parts}
    (ROOT/'companion-oneclick.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({p:{'bytes':m['bytes'],'parts':len(m['parts'])} for p,m in manifest['platforms'].items()}))
if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,required=True);build(parser.parse_args().output.resolve())
