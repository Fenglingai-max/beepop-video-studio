'use strict';
const fs=require('node:fs'),path=require('node:path'),{spawn}=require('node:child_process');
const root=__dirname;
function run(bin,args){return new Promise((resolve,reject)=>{const c=spawn(bin,args,{cwd:root,stdio:'inherit',windowsHide:false});c.on('error',reject);c.on('exit',code=>code===0?resolve():reject(Error('组件准备未完成，退出码 '+code)));});}
function openSite(){if(process.env.BEEPOP_NO_OPEN==='1')return;const url='https://fenglingai-max.github.io/beepop-video-studio/?v=20261127-oneclick1#create';const c=process.platform==='win32'?spawn('cmd.exe',['/c','start','',url],{stdio:'ignore',windowsHide:true}):spawn('open',[url],{stdio:'ignore'});c.on('error',()=>{});c.unref();}
async function start(){
 process.env.PATH=[path.dirname(process.execPath),path.join(root,'node_modules','.bin'),process.env.PATH||''].join(path.delimiter);
 if(+process.versions.node.split('.')[0]<22)throw Error('请使用资源包中的启动文件，以自动准备新版Node。');
 try{const r=await fetch('http://127.0.0.1:47831/health',{signal:AbortSignal.timeout(1500)});const s=await r.json();if(s.service==='beepoptvc-local'){if(s.version==='0.9.12'){console.log('新版助手已在运行，可以返回工作台生成视频。');openSite();return;}throw Object.assign(Error('旧助手仍在运行，请先关闭旧助手，再打开新版启动文件。'),{busy:true});}}catch(e){if(e.busy)throw e;}
 let installed=false;try{require.resolve('@remotion/cli');require.resolve('sharp');require.resolve('kokoro-js');require('./platform.cjs').createPlatform().mediaTools();installed=true;}catch{}
 if(!installed){console.log('[1/5] 首次准备制作组件，请保持联网，完成后自动打开工作台。');const npm=path.join(path.dirname(process.execPath),'node_modules','npm','bin','npm-cli.js');const alternate=path.resolve(path.dirname(process.execPath),'../lib/node_modules/npm/bin/npm-cli.js');const cli=[npm,alternate].find(f=>fs.existsSync(f));if(!cli)throw Error('运行时不完整，请重新打开资源包中的启动文件。');await run(process.execPath,[cli,'exec','--yes','--package=pnpm@11.25.0','--','pnpm','install','--frozen-lockfile','--ignore-scripts']);}
 console.log('[2/5] 正在准备校验组件…');await require('./prepare-python.cjs').preparePython();
 console.log('[3/5] 正在准备剪辑组件…');await require('./setup-media.cjs').ensureMedia();
 console.log('[4/5] 正在准备自然配音组件，首次约310 MB，后续复用。');await require('./setup-voice.cjs').ensureVoice();
 const {createRequire}=require('node:module'),req=createRequire(require.resolve('@remotion/cli')),cli=path.resolve(path.dirname(req.resolve('@remotion/cli')),'../remotion-cli.js');
 if(process.env.REMOTION_BROWSER_EXECUTABLE&&!fs.existsSync(process.env.REMOTION_BROWSER_EXECUTABLE)){console.log('旧渲染浏览器路径已失效，重新准备官方组件。');delete process.env.REMOTION_BROWSER_EXECUTABLE;}
 console.log('[5/5] 正在检查渲染浏览器…');
 if(!process.env.REMOTION_BROWSER_EXECUTABLE)await run(process.execPath,[cli,'browser','ensure']);
 const server=require('./server.cjs').createServer(process.env.BEEPOP_DATA_DIR?{dataDir:process.env.BEEPOP_DATA_DIR}:{});
 try{await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(47831,'127.0.0.1',resolve)});await server.ready;}catch(e){server.close();throw Error(e.code==='EADDRINUSE'?'启动端口已被其他程序占用，请关闭旧助手后重试。':e.message);}
 openSite();console.log('BeePOP 助手已就绪，返回工作台点击连接并验证。');process.on('SIGINT',()=>server.close(()=>process.exit(0)));
}
module.exports={start,run};if(require.main===module)start().catch(e=>{console.error(e.message);process.exitCode=1;});
