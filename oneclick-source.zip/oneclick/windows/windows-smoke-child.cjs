'use strict';
const assert=require('node:assert/strict'),path=require('node:path'),{spawnSync}=require('node:child_process');
assert.equal(process.platform,'win32');assert.ok(+process.versions.node.split('.')[0]>=22);
const nested=spawnSync('node',['--version'],{encoding:'utf8'});assert.equal(nested.status,0,nested.stderr);assert.equal(nested.stdout.trim(),'v'+process.versions.node);
assert.equal(process.cwd(),__dirname);assert.equal(process.env.BEEPOP_DATA_DIR,path.join(process.env.LOCALAPPDATA,'BeePOP','data'));
const server=require('node:http').createServer((q,r)=>r.end('ok'));
server.listen(0,'127.0.0.1',async()=>{try{const r=await fetch('http://127.0.0.1:'+server.address().port);assert.equal(await r.text(),'ok');console.log('BUNDLED_NODE_PATH_AND_LOOPBACK_OK');}catch(e){console.error(e);process.exitCode=1;}finally{server.close();}});
