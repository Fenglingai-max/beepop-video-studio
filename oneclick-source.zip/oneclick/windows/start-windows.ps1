param([switch]$SelfTest)
$ErrorActionPreference = 'Stop'
$root = $PSScriptRoot
$dataHome = Join-Path $env:LOCALAPPDATA 'BeePOP'
$logFile = Join-Path $dataHome 'logs\startup-windows.log'
function Note([string]$message) {
    Write-Host $message
    Add-Content -LiteralPath $logFile -Encoding UTF8 -Value $message
}
try {
    New-Item -ItemType Directory -Force -Path (Split-Path $logFile) | Out-Null
    Set-Content -LiteralPath $logFile -Encoding UTF8 -Value ('BeePOP startup ' + (Get-Date -Format o))
    Set-Location -LiteralPath $root
    if (-not [Environment]::Is64BitOperatingSystem) { throw 'Windows 10/11 64-bit is required.' }
    $spec = Get-Content -LiteralPath (Join-Path $root 'runtime.json') -Raw -Encoding UTF8 | ConvertFrom-Json
    $node = Join-Path $root '_runtime\node\node.exe'
    if (-not (Test-Path -LiteralPath $node)) {
        $name = 'node-' + $spec.version + '-win-x64.zip'
        $expected = $spec.files.$name
        if ($spec.version -notmatch '^v\d+\.\d+\.\d+$' -or $expected -notmatch '^[a-f0-9]{64}$') { throw 'Invalid runtime manifest. Download BeePOP again.' }
        $runtime = Join-Path $root '_runtime'
        New-Item -ItemType Directory -Force -Path $runtime | Out-Null
        $zip = Join-Path $runtime ($name + '.partial')
        [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
        $downloaded = $false
        for ($attempt=1; $attempt -le 3; $attempt++) {
            try {
                Note "Preparing official Node runtime (attempt $attempt/3)..."
                Invoke-WebRequest -UseBasicParsing -Uri ('https://nodejs.org/dist/' + $spec.version + '/' + $name) -OutFile $zip -TimeoutSec 300
                if ((Get-FileHash -LiteralPath $zip -Algorithm SHA256).Hash.ToLower() -ne $expected) { throw 'Runtime checksum mismatch.' }
                $downloaded = $true
                break
            } catch {
                Note ('Download attempt failed: ' + $_.Exception.Message)
                if ($attempt -eq 3) { throw }
            }
        }
        if (-not $downloaded) { throw 'Runtime download did not complete.' }
        $stage = Join-Path $runtime ('unpack-' + [Guid]::NewGuid().ToString('N'))
        # Expand-Archive requires a .zip extension on Windows PowerShell 5.1.
        $archive = Join-Path $runtime $name
        Move-Item -LiteralPath $zip -Destination $archive -Force
        Expand-Archive -LiteralPath $archive -DestinationPath $stage
        $nodeHome = Join-Path $runtime 'node'
        if (Test-Path -LiteralPath $nodeHome) { Move-Item -LiteralPath $nodeHome -Destination ($nodeHome + '-incomplete-' + [Guid]::NewGuid().ToString('N')) }
        Move-Item -LiteralPath (Join-Path $stage ('node-' + $spec.version + '-win-x64')) -Destination $nodeHome
    }
    $env:PATH = (Split-Path $node) + ';' + (Join-Path $root 'node_modules\.bin') + ';' + $env:PATH
    $env:BEEPOP_DATA_DIR = Join-Path $dataHome 'data'
    Note ('Project data: ' + $env:BEEPOP_DATA_DIR)
    Note ('Startup log: ' + $logFile)
    if ($SelfTest) {
        & $node (Join-Path $root 'windows-smoke-child.cjs')
        if ($LASTEXITCODE -ne 0) { throw 'Bundled Node startup self-test failed.' }
        Note 'WINDOWS_BOOTSTRAP_SELF_TEST_OK'
        exit 0
    }
    Note 'Preparing BeePOP components. Keep this window open. First setup requires internet.'
    $ErrorActionPreference = 'Continue'
    & $node (Join-Path $root 'start.cjs') 2>&1 | Tee-Object -FilePath $logFile -Append
    $result = $LASTEXITCODE
    $ErrorActionPreference = 'Stop'
    if ($result -ne 0) { throw ('Component preparation stopped (exit ' + $result + '). Check the log, then double-click the launcher to retry.') }
    exit 0
} catch {
    $message = $_.Exception.Message
    Write-Host ''
    Write-Host ('STARTUP FAILED: ' + $message) -ForegroundColor Red
    Write-Host ('Log: ' + $logFile)
    try { Add-Content -LiteralPath $logFile -Encoding UTF8 -Value ('STARTUP FAILED: ' + $message) } catch {}
    exit 1
}
