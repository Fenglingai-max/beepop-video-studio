@echo off
setlocal
cd /d "%~dp0"
if errorlevel 1 goto path_error
if not exist "%~dp0internal\start-windows.ps1" goto extract_error
where powershell.exe >nul 2>&1
if errorlevel 1 goto powershell_error
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0internal\start-windows.ps1" %*
set "BEEPOP_EXIT=%ERRORLEVEL%"
echo.
if not "%BEEPOP_EXIT%"=="0" echo BeePOP could not start. The error and log location are shown above.
if "%BEEPOP_EXIT%"=="0" echo BeePOP has stopped. You can start it again by double-clicking this file.
goto finish
:extract_error
echo Please EXTRACT ALL files from BeePOP-Windows.zip first.
echo Keep this launcher next to the internal folder. Do not run it inside the ZIP.
set "BEEPOP_EXIT=2"
goto finish
:path_error
echo Cannot open the application folder. Extract the ZIP to a local folder and retry.
set "BEEPOP_EXIT=3"
goto finish
:powershell_error
echo Windows PowerShell is unavailable. This version requires Windows 10/11 64-bit.
set "BEEPOP_EXIT=4"
:finish
echo.
echo Press any key to close this window...
pause >nul
exit /b %BEEPOP_EXIT%
