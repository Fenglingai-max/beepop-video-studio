@echo off
chcp 65001 >nul
cd /d "%~dp0内部组件"
call 启动beepoptvc.cmd
