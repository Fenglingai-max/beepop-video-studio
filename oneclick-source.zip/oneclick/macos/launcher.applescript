on healthy()
 try
  set healthText to do shell script "/usr/bin/curl --noproxy '*' -fsS --max-time 2 http://127.0.0.1:47831/health"
  return healthText contains "beepoptvc-local" and healthText contains "0.9.12"
 on error
  return false
 end try
end healthy
on run
 set siteURL to "https://fenglingai-max.github.io/beepop-video-studio/?v=20261127-oneclick1#create"
 if my healthy() then
  open location siteURL
  return
 end if
 set appFolder to POSIX path of (path to me)
 set resources to appFolder & "Contents/Resources"
 set supportFolder to POSIX path of (path to home folder) & "Library/Application Support/BeePOP"
 try
  do shell script "/bin/mkdir -p " & quoted form of supportFolder
 on error
  display dialog "无法创建 BeePOP 应用数据目录，请检查当前用户的文件夹权限。" buttons {"关闭"} default button 1
  return
 end try
 repeat
  set progress total steps to -1
  set progress description to "BeePOP 正在启动"
  set progress additional description to "首次需要下载组件，请保持联网；完成后自动打开工作台。"
  do shell script "/usr/bin/nohup /bin/zsh " & quoted form of (resources & "/worker.zsh") & " " & quoted form of resources & " >/dev/null 2>&1 </dev/null &"
  delay 2
  repeat
   if my healthy() then
    set progress total steps to 0
    open location siteURL
    display notification "本机助手已连接，可以开始制作。" with title "BeePOP 已就绪"
    return
   end if
   try
    set failureText to do shell script "/bin/cat " & quoted form of (supportFolder & "/failed")
    exit repeat
   end try
   try
    set stageText to do shell script "/usr/bin/tail -c 8000 " & quoted form of (supportFolder & "/startup.log") & " | /usr/bin/grep -E '\\[[1-5]/5\\]|正在|首次|Progress:|[0-9]+%' | /usr/bin/tail -1 | /usr/bin/cut -c 1-200"
    if stageText is not "" then set progress additional description to stageText
   end try
   try
    set workerPID to do shell script "/bin/cat " & quoted form of (supportFolder & "/launcher.lock/pid")
    do shell script "/bin/kill -0 " & quoted form of workerPID
   on error
    set failureText to "启动进程已结束，或另一个程序占用了连接端口。请查看日志后重试。"
    exit repeat
   end try
   delay 2
  end repeat
  set progress total steps to 0
  set choice to button returned of (display dialog ("助手尚未启动。\n" & failureText & "\n\n点击重试可继续准备组件；不会提交视频任务。") buttons {"退出", "查看日志", "重试"} default button "重试" with icon caution)
  if choice is "退出" then return
  if choice is "查看日志" then
   do shell script "/usr/bin/open -a TextEdit " & quoted form of (supportFolder & "/startup.log")
   return
  end if
 end repeat
end run
