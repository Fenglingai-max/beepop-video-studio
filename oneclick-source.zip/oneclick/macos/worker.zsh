#!/bin/zsh
set -u
setopt extendedglob
resources=$1
support="${BEEPOP_SUPPORT_DIR:-$HOME/Library/Application Support/BeePOP}"
mkdir -p "$support" || exit 1
lock="$support/launcher.lock"
if ! mkdir "$lock" 2>/dev/null; then
  previous=$(cat "$lock/pid" 2>/dev/null)
  if [[ "$previous" == <-> ]] && kill -0 "$previous" 2>/dev/null; then exit 0; fi
  rm -f "$lock/pid"
  rmdir "$lock" 2>/dev/null || exit 1
  mkdir "$lock" || exit 1
fi
echo $$ > "$lock/pid"
trap 'rm -f "$lock/pid"; rmdir "$lock" 2>/dev/null' EXIT
rm -f "$support/failed"
exec > "$support/startup.log" 2>&1
fail() { print -r -- "$1"; print -r -- "$1" > "$support/failed"; exit 1; }
expected=$(cat "$resources/payload.sha256")
[[ "$expected" == [a-f0-9]## && ${#expected} == 64 ]] || fail '应用安装包信息无效，请重新下载。'
actual=$(/usr/bin/shasum -a 256 "$resources/payload.zip")
[[ "${actual%% *}" == "$expected" ]] || fail '应用安装包校验失败，请重新下载。'
root="$support/runtime-${expected[1,12]}"
if [[ ! -f "$root/.complete" ]]; then
  print '正在展开内置组件…'
  stage="$support/unpack-$$"
  mkdir -p "$stage" || fail '无法创建应用数据目录。'
  /usr/bin/ditto -x -k "$resources/payload.zip" "$stage" || fail '组件展开失败，请重新下载。'
  touch "$stage/.complete"
  # Only move a fully expanded payload into place.
  if [[ -e "$root" ]]; then /bin/mv "$root" "$support/incomplete-$$"; fi
  /bin/mv "$stage" "$root" || fail '组件保存失败。'
fi
cd "$root" || fail '运行目录无法打开。'
export PATH="$root/_runtime/node/bin:/usr/local/bin:/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin:${PATH:-}"
export BEEPOP_NO_OPEN=1 BEEPOP_BACKGROUND=1 BEEPOP_DATA_DIR="$support/data"
/bin/zsh ./启动beepoptvc.command
result=$?
if (( result != 0 )); then
  reason=$(/usr/bin/tail -n 4 "$support/startup.log")
  fail "启动未完成（$result）：$reason"
fi
