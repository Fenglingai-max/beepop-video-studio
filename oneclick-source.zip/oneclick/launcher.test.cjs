'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),{EventEmitter}=require('node:events'),crypto=require('node:crypto');
const root=path.resolve(__dirname,'..');
test('first component installation receives bundled Node in PATH on a clean Mac',async()=>{
 const env={PATH:'/usr/bin:/bin'},fakeProcess={env,execPath:'/Applications/BeePOP/runtime/node/bin/node',versions:{node:'24.0.0'},platform:'darwin'},module={exports:{}};let spawned=false;
 const req=name=>{
  if(name==='node:fs')return {existsSync:()=>true};if(name==='node:path')return path;
  if(name==='node:child_process')return {spawn(bin,args){spawned=true;assert.equal(env.PATH.split(':')[0],'/Applications/BeePOP/runtime/node/bin');assert.ok(args.includes('--package=pnpm@11.25.0'));const c=new EventEmitter();queueMicrotask(()=>c.emit('error',Error('test stop before installation')));return c;}};
  throw Error('missing optional dependency');
 };
 req.resolve=()=>{throw Error('not installed')};req.main=null;
 vm.runInNewContext(fs.readFileSync(path.join(__dirname,'start.cjs'),'utf8'),{require:req,module,__dirname:'/test/中文目录',process:fakeProcess,fetch:async()=>{throw Error('not running')},AbortSignal,console:{log(){}}});
 await assert.rejects(module.exports.start(),/test stop/);assert.equal(spawned,true);
});
test('published platform archives match complete ordered parts',()=>{
 const m=JSON.parse(fs.readFileSync(path.join(root,'companion-oneclick.json')));assert.equal(m.executionVersion,'0.9.12');
 for(const [platform,p]of Object.entries(m.platforms)){assert.ok(p.parts.length);for(let i=0;i<p.parts.length;i++)assert.equal(p.parts[i],`companion-oneclick-${platform}-${String(i+1).padStart(2,'0')}.bin`);const b=Buffer.concat(p.parts.map(n=>fs.readFileSync(path.join(root,n))));assert.equal(b.length,p.bytes);assert.equal(crypto.createHash('sha256').update(b).digest('hex'),p.sha256);}
});
