#!/bin/zsh
set -e
cd -- "${0:A:h}"
export PATH="$PWD/_runtime/node/bin:/usr/local/bin:/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin:${PATH:-}"
version=$(cat runtime-version.txt | tr -d '\r\n')
arch=$(uname -m)
[[ "$arch" == "x86_64" ]] && arch=x64
if [[ "$arch" != "arm64" && "$arch" != "x64" ]]; then echo '暂不支持此电脑架构'; exit 1; fi
mkdir -p _runtime
if [[ ! -x _runtime/node/bin/node ]]; then
  archive="node-${version}-darwin-${arch}.tar.gz"
  expected=$(awk -v name="$archive" '$2 == name {print $1}' runtime-sha256.txt)
  [[ ${#expected} == 64 ]] || { echo '运行时清单无效'; exit 1; }
  echo '正在自动准备官方 Node.js 运行时…'
  /usr/bin/curl --fail --location --connect-timeout 20 --max-time 600 --retry 2 --proto '=https' --tlsv1.2 "https://nodejs.org/dist/${version}/${archive}" -o "_runtime/${archive}"
  actual=$(/usr/bin/shasum -a 256 "_runtime/${archive}" | awk '{print $1}')
  [[ "$actual" == "$expected" ]] || { echo '下载校验失败，请重新启动'; exit 1; }
  /usr/bin/tar -xzf "_runtime/${archive}" -C _runtime
  mv "_runtime/node-${version}-darwin-${arch}" _runtime/node
fi
set +e
"$PWD/_runtime/node/bin/node" start.cjs
result=$?
[[ "${BEEPOP_BACKGROUND:-0}" == 1 ]] && exit "$result"
if (( result != 0 )); then
  echo "启动未完成，请双击 BeePOP一键启动，选择重试或查看日志。"
fi
echo '助手已结束。按回车关闭。'
read
