# BeePOP 一键启动

macOS 下载包解压后仅有 BeePOP.app。双击应用，查看准备进度，助手就绪后自动打开工作台。无需终端命令，也不依赖桌面上的旧资源包。运行代码与三版插件装在应用的只读 payload.zip 中，首次使用校验并展开至 `~/Library/Application Support/BeePOP/`，后续复用。项目数据单独保存在该目录下的 data 中。

Windows 下载包仅包含“启动BeePOP.cmd”和“内部组件”文件夹。双击前者自动准备运行组件，并在就绪后打开工作台。保留启动窗口。Windows 启动脚本已有自动下载官方 Node 的逻辑，修正后的 start.cjs 在安装 pnpm 前就设置 Node 路径。

Mac 应用使用本地临时签名，尚未经 Apple Developer ID 签名与公证；下载后可能触发 macOS 的首次打开确认。应用会显示失败原因、重试与查看日志入口。首次需联网下载 Node、制作组件、约310 MB配音模型与渲染浏览器；这不是离线完整安装包。

构建：在 Mac 仓库根目录执行 `python3 oneclick/package.py --output /absolute/output/path`。构建器先校验原资源包 SHA-256，再只覆盖启动文件，保留制作规则；输出按系统拆分的 zip、网页分片与下载清单。系统目录、账号、缓存、项目与本地 node_modules 不进入包。发布时将 companion-oneclick.json、全部 companion-oneclick-*.bin 与网页一起提交。
