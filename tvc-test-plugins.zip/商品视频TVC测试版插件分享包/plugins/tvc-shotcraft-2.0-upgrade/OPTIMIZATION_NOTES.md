# TVC Shotcraft 2.0 优化说明

- 纯 Remotion：移除 10 秒视频前置假设，成片只由 Remotion timeline 驱动。
- 时长：`durationSeconds` 允许 15–20 秒；Root 与导出脚本按该字段计算帧数。
- 素材混剪：新增 `editPlan.sourceSegments`、`mixOrder`，要求至少两段素材并绑定卖点。
- 差异化：新增 `variantId` 与 `differenceNote`，每条成片必须记录可见差异。
- 证据链：保留原有事实→价值→依据→镜头校验，新增混剪计划校验。

原始安装副本位于只读缓存目录；本目录是可写、可替换的优化副本。
