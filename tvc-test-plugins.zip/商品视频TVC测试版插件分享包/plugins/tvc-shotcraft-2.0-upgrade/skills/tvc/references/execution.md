# 工程执行与验收

在工作工程安装 `pnpm install --frozen-lockfile`。安装插件不自动安装Node、Python、Remotion、浏览器或配音模型。

执行 `pnpm check`、`node scripts/check-motion.cjs product.json`、`node scripts/validate-inputs.cjs product.json`。输入校验检查事实结构、实际资源、图片尺寸与WAV时长；当前时长校验使用PCM WAV，新音轨使用其他格式先转换或扩展校验，不能直接称已支持所有编码。

预览 `pnpm studio`，选择KineticProductTVC。实际导出 `node scripts/render-kinetic.cjs product.json`；输出out/product.mp4，1920×1080、30fps，帧数按durationSeconds（15–20秒）计算，并整理封装。可通过REMOTION_BROWSER_EXECUTABLE指定可用浏览器。浏览器权限失败须如实处理，不用其他逐帧流程冒充Remotion验证。

HTM与Remotion共享同一画面引擎；修改public/motion-engine.js须同步HTM内嵌脚本。使用工程快照保持交付效果，不能只更新版本号或指令。

检查关键帧和主要接点，完整播放和试听后才标记对应检查通过。未完成的人工检查保留not_checked。用户确认的交付参考与测试生成结果分开记录；新商品不能自动获得参考案例验收结论。

默认交付仅 MP4：目标文件夹内直接看到视频，无产品子文件夹、HTM、JSON、字幕、说明、ZIP或校验文件。工作工程及验收记录留在工作区；用户另要源码时再提供。可运行插件 scripts/deliver-videos.cjs 将明确列出的成片复制到交付目录。上传、发消息、安装插件不由技能扩大授权。GitHub中不要提交依赖目录、缓存、配音模型、凭据或环境私密文件。

## 纯 Remotion 混剪与差异化

2.0 不使用 10 秒视频前置素材。将用户图片、短片或录音按可见证据拆成 `editPlan.sourceSegments`，每段记录 `in/out`、asset 与 featureIds；至少两段按 `mixOrder` 交错进入成片，不能把所有素材集中在开头。每条成片必须有新的 `variantId`，并在 `differenceNote` 说明与上一条在镜头顺序、节奏、场景或文案上的可见差异。

`durationSeconds` 必须为 15–20；旁白、字幕、音乐和画面统一由 Remotion timeline 驱动。
