# 商品输入

productUnderstanding保存原始描述、用户、用途、场景、缺失项。每个features[].sellingPoint保存fact、benefit、basis、source、visualPlan、translationZh、narrationIndex。basis正式值：provided_description、visible_structure、inference；unverified只用于空白草稿，不能正式导出。

heroAsset使用透明主图，visual.heroWidth/heroHeight为实际像素。focus.x/y是细节焦点的0–1坐标；两张shots填实际路径、尺寸和rect。禁止用缩略图局部放大充当高清；本版源像素倍率约1.5为质量检查参考。

motionDesign.editorial为各段标题；motionDesign.aplus是标签与辅助说明数据名，不恢复被拒绝的色块框。文案先基于商品事实理解，再翻译自然英文；不能只替换产品名和沿用猫玩具卖点。

narration填写真实配音时段、逐句字幕和资源路径。不存在逐词时间戳时不声称逐词同步。music填写实际BGM资源、来源和按商品编曲的简报。现有案例Kokoro af_heart是AI合成声，程序音乐不是录音音乐或外部音乐模型生成。

独立HTM已经内嵌参考资产，默认通用占位。绑定文件、修改JSON、应用后另存即可保留新商品。`scripts/extract-htm.py <HTM> <输出目录> [--reference]`可提取资源与product.json；正式Remotion支持的图片/音频检查以执行脚本为准。
