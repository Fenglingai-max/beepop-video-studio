# 产品特效与配乐质量：制作前必读

“允许特效”不是完成特效设计。先实际查看产品，再在 product.json 的 creativeDirection 中记录产品依据、镜头和效果；制作效果并审查实际渲染，不能只填写记录。

## 产品适配

productAnalysis 包含 category、useTask、materialEvidence、shape、palette、mood、effectReason。effectPlan 记录 mode、reason、rejectedAlternatives、config、protectedRegions 和 review。默认选择能帮助当前镜头理解或增强商品气质的效果，不一律彩带撒花；用户指定的特效仍需明显落实。

- 聚会/庆典商品：纸屑、彩带或星纸可较强，释放与聚会氛围和收尾呼应。
- 运动商品：方向拖尾、短促速度线、节拍弹性，不能用随机晃动代替动作。
- 透明展示/精细结构：沿可见边缘扫光、微小高光和景深层次；不编造不透明边或背面。
- 日常放松/按摩器：有缓急的轮廓扫光与局部柔光，按握柄/双球结构绑定；开头或收尾可搭配与主体有区分度的青绿和香槟色彩带。不要医疗波纹、红热发光或震动来暗示未证实的加热、电动和治疗功能。
- 节日家居：匹配节庆的星纸或光点，保留主体轮廓和材质。

这些是选择起点，不是类别自动套用表。禁止改颜色即视为完成分析。工程使用 creativeDirection.cameraKeys 明确逐镜 time/x/y/size（1920×1080画布，size为图像宽度），由共享引擎实际消费；原图等比，素材清晰度与文案避让需另查。

## 实现与强度

共享引擎支持 effectPlan.config 的 shape（ribbon/streamer/star/spark/paper）、palette、seed、size、width、gravity、bursts[{time,duration,count,originY}]，以及 effectPlan.accents[{start,end,kind,x,y,radius,color}]（kind为glow或sweep，x/y/radius为产品图归一化坐标）。protectedRegions 为带 start/end/x/y/w/h 的实际画布文字区域。场景段停用产品粒子；字幕固定区域不绘粒子。

默认以可见强度起步而非近乎不可见：1920画面中纸屑约14–24px、彩带线宽5–8px、长度约60–110px，主要释放约60–100粒，持续约1.8–2.6秒。数字仅为起点，受构图、对比和产品大小影响，必须审查实际画面；不能把密度一味加大。前后层次与重力围绕产品，强调结构的扫光按真实锚点移动。

至少输出特效峰值、卖点段和收尾的实际帧，按正常1920及缩至480宽检查：无需放大寻找就能看出选定效果，且不遮住卖点、标题和字幕。记录 effectPlan.review={status,frames,observations}。没有真实检查保留pending；只检查字段或粒子数量不能标记视觉通过。

## 配乐沿用5.0品质标准

每款先写 music.direction：使用任务、情绪曲线、配器、律动和收束。至少比较两首不同曲目的真实可用素材，记录 music.candidates[{id,asset,source,rights,categoryFit}]、selectedCandidateId、comparisonClips、listeningStatus。最终 music.asset 与选中候选一致；候选有真实许可，不能用改名、变速或换起点假装两首不同曲目。

优先真实乐器质感的现成授权配乐；不默认用正弦波、程序拨弦和简陋循环作正式BGM，也不直接复用模板旧音乐。按摩器可比较温暖电钢琴/吉他配细腻打击与柔和低音的两种方向；舒缓不等于无节拍、长铺底。不要只写“轻快、温馨”。不因本规则自动付费；来源不足时说明缺口。

导出8–12秒含当前配音的两段同响度混音样段。开头快速建立律动，卖点保持推进，结尾有完整落点；避免随意循环和突然截断。混音依据当前音频的实际响度调整，不能照抄baseVolume=.24/duckVolume=.12等固定比例：人声清晰且背景的鼓点、低音仍可辨，避免每句旁白都把音乐压没。不要仅靠增大音量补救单薄音色。音乐单轨、旁白单轨、全混音分别核对，检查峰值和完整解码；实际试听未做，listeningStatus保留pending，并提供预览供用户听审。参数合格不能宣称已有5.0质感。

## 执行门槛

render-kinetic.cjs 在正常导出前运行 check-creative.cjs。该脚本只检配置和资源，不代替视觉/听审。缺当前产品分析、未实现效果或缺配乐比较资源时先补工作；允许 --draft 导出明确草稿，不能把草稿当正式交付绕过质量要求。人工审查仍按实际能力如实记录。
