const fs=require('fs'),path=require('path');
function check(d,root){
 const c=d.creativeDirection,fail=s=>{throw Error('创意质量：'+s)};
 if(!c?.productAnalysis||!['category','useTask','mood','effectReason'].every(k=>c.productAnalysis[k]?.trim()))fail('缺当前产品特效适配分析');
 const ks=c.cameraKeys;if(!Array.isArray(ks)||ks.length<4)fail('至少提供4个实际消费的cameraKeys');
 for(let i=0;i<ks.length;i++)if(!['time','x','y','size'].every(k=>Number.isFinite(ks[i][k]))||ks[i].size<=0||i&&ks[i].time<=ks[i-1].time)fail('cameraKeys需有效数值和递增时点');
 const e=c.effectPlan;if(!e?.reason?.trim()||!e.rejectedAlternatives?.length)fail('缺特效选择与排除理由');
 if(e.mode==='none')fail('本用户明确要求明显特效，不能默认禁用');
 if(!e.config?.bursts?.length&&!e.accents?.length)fail('只有文字描述，没有引擎可执行特效');
 if(e.config?.bursts?.length&&(!e.config.palette?.length||!['paper','ribbon','streamer','star','spark'].includes(e.config.shape)))fail('粒子需支持的shape与palette');
 if(!Array.isArray(e.protectedRegions)||!e.protectedRegions.length)fail('需填写标题和CTA避让区域');
 const m=d.music,cs=m?.candidates;if(!m?.direction?.trim()||!Array.isArray(cs)||cs.length<2)fail('需当前产品音乐简报和至少两首候选');
 const asset=p=>{const f=path.resolve(root,'public',p||'');if(!f.startsWith(path.resolve(root,'public')+path.sep)||!fs.existsSync(f)||!fs.statSync(f).isFile())fail('音乐/样段资源不存在：'+p);return fs.readFileSync(f)};
 const crypto=require('crypto'),hash=p=>crypto.createHash('sha256').update(asset(p)).digest('hex');
 const hashes=cs.map(x=>{if(!x.id||!x.source?.trim()||!x.rights?.trim()||!x.categoryFit?.trim()||/^(unknown|pending|待定|未知)$/i.test(x.rights.trim()))fail('候选缺来源、许可或产品适配依据');return hash(x.asset)});
 if(new Set(hashes).size<2)fail('候选实际音频相同');
 const selected=cs.find(x=>x.id===m.selectedCandidateId);if(!selected||hash(selected.asset)!==hash(m.asset))fail('最终BGM与选定候选不一致');
 if(!Array.isArray(m.comparisonClips)||m.comparisonClips.length<2)fail('缺带当前配音的比较样段');
 for(const x of cs){const clip=m.comparisonClips.find(y=>y.candidateId===x.id);if(!clip||clip.durationSeconds<8||clip.durationSeconds>12)fail('每首候选需8–12秒比较样段');asset(clip.asset)}
 return {status:'configuration_checked',visualReview:e.review?.status||'pending',listening:m.listeningStatus||'pending'};
}
if(require.main===module){const root=path.resolve(__dirname,'..'),file=path.resolve(root,process.argv[2]||'product.json');console.log(JSON.stringify(check(JSON.parse(fs.readFileSync(file)),root)))}
module.exports={check};
