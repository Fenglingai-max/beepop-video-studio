export type Shot={start:number;end:number;asset:string;imageWidth:number;imageHeight:number;rect:number[];label:string;kind:'push'|'panel'};
export type Focus={x:number;y:number;scale:number};
export type SellingPoint={fact:string;benefit:string;basis:'provided_description'|'visible_structure'|'inference';source:string;visualPlan:string;translationZh:string;narrationIndex:number};
export type ProductUnderstanding={providedDescription:string;descriptionStatus:'provided'|'not_provided';primaryUse:string;audience:string;scenario:string;unknowns:string[]};
export type Feature={caption:string;description?:string;focus:Focus;sellingPoint:SellingPoint};
export type Narration={start:number;end:number;text:string;asset:string};
export type ProductData={assetManifest?:string;durationSeconds?:number;editPlan?:{variantId:string;sourceSegments:Array<{id:string;asset:string;in:number;out:number;featureIds:string[]}>;mixOrder:string[];differenceNote:string};productUnderstanding:ProductUnderstanding;templateVersion?:string;productName:string;brandName?:string;headline:string;subtitle?:string;heroAsset:string;features:Feature[];endingHeadline?:string;cta?:string;accent?:string;background?:string;shots:Shot[];narration:Narration[];music:{asset:string;baseVolume:number;duckVolume:number;attack:number;release:number};timeline:{detail1Start:number;detail2Start:number;scenesStart:number;endingStart:number;detailMove:number;returnMove:number;sceneBlend:number};visual:{baseSize:number;heroWidth:number;heroHeight:number;wholeCenterX:number;detail1CenterX:number;detail2CenterX:number;centerY:number;maxPixelScale:number;heroBlendMode?:'normal'|'multiply'}};
export function validate(d:ProductData){
 for(const key of ['productName','headline','heroAsset'] as const)if(typeof d[key]!=='string'||!d[key].trim())throw Error(`${key} 必须填写`);
 if(!Array.isArray(d.features)||d.features.length!==2)throw Error('必须提供两个展示点');
 const understanding=d.productUnderstanding;
 if(!understanding||!['provided','not_provided'].includes(understanding.descriptionStatus)||typeof understanding.providedDescription!=='string'||!Array.isArray(understanding.unknowns)||!understanding.unknowns.every(x=>typeof x==='string')||['primaryUse','audience','scenario'].some(key=>typeof understanding[key as keyof ProductUnderstanding]!=='string'||!String(understanding[key as keyof ProductUnderstanding]).trim()))throw Error('先填写产品理解：原始描述、用途、用户、场景和待确认项');
 if(understanding.descriptionStatus==='provided'&&!understanding.providedDescription.trim())throw Error('已提供描述时必须保留原文；没有描述请标记 not_provided');
 for(const f of d.features){const claim=f.sellingPoint;
 if(!claim||['fact','benefit','source','visualPlan','translationZh'].some(key=>typeof claim[key as keyof SellingPoint]!=='string'||!String(claim[key as keyof SellingPoint]).trim())||!['provided_description','visible_structure','inference'].includes(claim.basis))throw Error('每个卖点必须填写特点、用户价值、依据类型、来源、镜头方案与中文释义');
 if(claim.basis==='provided_description'&&understanding.descriptionStatus!=='provided')throw Error('没有产品描述，不能将卖点标记为描述已确认');
 if(!Number.isInteger(claim.narrationIndex)||claim.narrationIndex<0||!d.narration?.[claim.narrationIndex])throw Error('卖点必须关联实际旁白 narrationIndex');
 }
 const v=d.visual,t=d.timeline;const duration=d.durationSeconds||15;if(!Number.isFinite(duration)||duration<15||duration>20)throw Error('durationSeconds 必须在15–20秒');if(!d.editPlan||!d.editPlan.variantId||d.editPlan.sourceSegments.length<2||d.editPlan.mixOrder.length<2||!d.editPlan.differenceNote?.trim())throw Error('必须提供素材混剪计划与差异说明');if(!v||!t)throw Error('缺少 visual / timeline');
 if(!(0<t.detail1Start&&t.detail1Start<t.detail2Start&&t.detail2Start<t.scenesStart&&t.scenesStart<t.endingStart&&t.endingStart<duration))throw Error('镜头时间顺序不正确');
 for(const f of d.features){const p=f.focus;if(!f.caption||!p||![p.x,p.y,p.scale].every(Number.isFinite)||p.x<0||p.x>1||p.y<0||p.y>1||p.scale<1)throw Error('细节文案或坐标不正确');if(v.baseSize*p.scale/Math.min(v.heroWidth,v.heroHeight)>v.maxPixelScale)throw Error('细节超过源像素倍率上限，请换素材或降低倍率');}
 let previousEnd=0;for(const s of d.shots){const [x,y,w,h]=s.rect;if(s.start<previousEnd||s.start<t.scenesStart||s.end>t.endingStart||s.end<=s.start)throw Error('场景时段越界或重叠');if(!(x>=0&&y>=0&&w>0&&h>0&&x+w<=s.imageWidth&&y+h<=s.imageHeight))throw Error('场景裁切区域越界');const scale=s.kind==='panel'?1.1:Math.max(1920/w,1080/h)*1.015;if(scale>v.maxPixelScale+.04)throw Error('场景源像素不足，禁止局部放大铺屏');previousEnd=s.end;}
 previousEnd=0;for(const n of d.narration){if(n.start<previousEnd||n.end<=n.start||n.end>duration||!n.text||!n.asset)throw Error('旁白时段/内容无效');previousEnd=n.end;}
 if(d.music&&!(d.music.duckVolume>=0&&d.music.baseVolume<=1&&d.music.duckVolume<=d.music.baseVolume))throw Error('音乐音量配置无效');return d;
}
