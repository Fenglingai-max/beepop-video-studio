import type {Focus,ProductData} from './data';
export const clamp=(x:number)=>Math.max(0,Math.min(1,x));
export const smooth=(x:number)=>{const u=clamp(x);return u*u*(3-2*u)};
export const pose=():Focus=>({x:.5,y:.5,scale:1});
export function mix(a:Focus,b:Focus,p:number):Focus{const e=smooth(p);return {x:a.x+(b.x-a.x)*e,y:a.y+(b.y-a.y)*e,scale:a.scale+(b.scale-a.scale)*e};}
export function camera(t:number,d:ProductData){const a=d.features[0].focus,b=d.features[1].focus,v=d.timeline,base=pose();if(t<v.detail1Start)return mix({...base,scale:.96},base,t/.6);if(t<v.detail2Start)return mix(base,a,(t-v.detail1Start)/v.detailMove);if(t<v.endingStart)return mix(a,b,(t-v.detail2Start)/v.detailMove);return mix(b,base,(t-v.endingStart)/v.returnMove);}
export const envelope=(t:number,a:number,b:number,c:number,e:number)=>smooth((t-a)/(b-a))*smooth((e-t)/(e-c));
export function musicVolume(t:number,d:ProductData){const m=d.music;const active=d.narration.reduce((v,n)=>Math.max(v,clamp((t-n.start+m.attack)/m.attack)*clamp((n.end+m.release-t)/m.release)),0);return (m.baseVolume-(m.baseVolume-m.duckVolume)*active)*clamp(t/.18)*clamp((15-t)/.5);}
