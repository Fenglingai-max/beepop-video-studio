import React from 'react';
import {AbsoluteFill,Composition} from 'remotion';
import product from '../product.json';
import {KineticTVC,KineticData} from './KineticTVC';
const Video=(props:KineticData)=>props.heroAsset.startsWith('placeholder:')?<AbsoluteFill style={{background:'#f4f0e7',color:'#1b2928',display:'flex',justifyContent:'center',alignItems:'center',fontSize:44}}>先填写商品资料与真实素材，或明确选择交付案例。</AbsoluteFill>:<KineticTVC {...props}/>;
export const Root=()=> <Composition id="KineticProductTVC" component={Video} durationInFrames={Math.round(((product as any).durationSeconds||15)*30)} fps={30} width={1920} height={1080} defaultProps={product as unknown as KineticData}/>;
