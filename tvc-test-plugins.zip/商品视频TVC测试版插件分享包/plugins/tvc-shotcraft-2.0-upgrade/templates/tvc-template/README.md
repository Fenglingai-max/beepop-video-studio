# 商品视频TVC 2.0工程

先填写product.json，或创建时明确选--example cat。默认空白不是猫玩具，也不能直接正式渲染。
安装锁定依赖：pnpm install --frozen-lockfile。
检查：pnpm check；node scripts/validate-inputs.cjs product.json。
预览：pnpm studio。Composition：KineticProductTVC。
导出：pnpm render；明确复现交付案例时pnpm render:cat。
主图与音频路径相对public，使用英文神经配音与真实音频时间段。
打开商品视频TVC_2.0.htm可离线编辑；与Remotion共用public/motion-engine.js。
如编辑引擎，需要同步HTM内嵌脚本并检查一致性；不要只改一端。
Remotion依赖4.0.506，支持显式REMOTION_BROWSER_EXECUTABLE。浏览器权限失败应报告或申请必要执行权限。
