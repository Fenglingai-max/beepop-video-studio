/* Frame-deterministic editorial compositor shared by HTML and Remotion. */
(function(root){
const clamp=x=>Math.max(0,Math.min(1,x)),mix=(a,b,p)=>a+(b-a)*p;
const smooth=x=>{x=clamp(x);return x*x*x*(x*(x*6-15)+10)};
const phase=(t,a,b)=>smooth((t-a)/(b-a));
function draw(ctx,t,d,images){
 const W=1920,H=1080,m=d.motionDesign,ink=m.ink||'#1b2928',paper=m.paper||'#f4f0e7',accent=m.accent||'#52665b';
 const ap=m.aplus||{introKicker:'PRODUCT COLLECTION',introBody:['Discover the details.'],featureKickers:['PRODUCT DETAIL','PRODUCT DESIGN'],featureBodies:[['Explore the product.'],['Made for your moment.']],endKicker:'EVERYDAY MOMENTS',endBody:['Discover the collection.']};
 const e=m.editorial||{intro:['Your product.','Your moment.'],features:[['First benefit.'],['Second benefit.']],featureSub:['',''],ending:['Made for','your day.']};
 ctx.clearRect(0,0,W,H);ctx.fillStyle=paper;ctx.fillRect(0,0,W,H);
 function txt(s,x,y,size,opt={}){ctx.save();ctx.font=`${opt.weight||600} ${size}px Helvetica Neue, Arial, sans-serif`;ctx.fillStyle=opt.color||ink;ctx.globalAlpha*=opt.alpha===undefined?1:opt.alpha;
  if(opt.max){const w=ctx.measureText(s).width;if(w>opt.max){size*=opt.max/w;ctx.font=`${opt.weight||600} ${size}px Helvetica Neue, Arial, sans-serif`}}
  ctx.fillText(s,x,y);ctx.restore();}
 function moving(s,x,y,size,start,end,style='up',opt={}){const p=phase(t,start,start+.6),q=phase(t,end-.38,end);ctx.save();ctx.globalAlpha=p*(1-q);
  if(style==='left'){ctx.translate((1-p)*-62-q*40,0)}
  else if(style==='right'){ctx.translate((1-p)*62+q*48,0)}
  else if(style==='down'){ctx.translate(0,-(1-p)*45+q*35)}
  else {ctx.translate(0,(1-p)*45-q*35)}
  txt(s,x,y,size,opt);ctx.restore();}
 // A single position/scale path spans every product slot. Slot changes never reset it.
 function camera(){const im=images[d.heroAsset],ratio=im?im.height/im.width:1;const f=d.features;const pose=(time,size,fx,fy,x,y)=>({time,size,x:x-fx*size,y:y-fy*size*ratio});
 const fallbackKeys=[pose(0,2050,f[0].focus.x,f[0].focus.y,990,460),pose(1.12,1120,.5,.5,1290,536),pose(2.25,1140,.5,.5,1290,532),pose(3.42,2070,f[0].focus.x,f[0].focus.y,1550,450),pose(4.7,2080,f[0].focus.x,f[0].focus.y,1540,445),pose(5.98,1640,f[1].focus.x,f[1].focus.y,540,640),pose(6.85,1650,f[1].focus.x,f[1].focus.y,535,636),pose(8.45,1800,f[0].focus.x,f[0].focus.y,1000,455)];
 const planned=d.creativeDirection?.cameraKeys;
 if(planned?.length>=2){const ks=planned;let i=ks.findIndex((k,j)=>j<ks.length-1&&t<ks[j+1].time);if(t<=ks[0].time)return ks[0];if(i<0)return ks[ks.length-1];const a=ks[i],b=ks[i+1],q=phase(t,a.time,b.time);return {size:mix(a.size,b.size,q),x:mix(a.x,b.x,q),y:mix(a.y,b.y,q)}}
 const keys=fallbackKeys;
 if(t>=10.65){const q=phase(t,11.2,12.45);return {size:mix(1030,950,q),x:mix(1340-515,490-475,q),y:mix(550-1030*ratio/2,535-950*ratio/2,q)}}
 let i=keys.findIndex((k,j)=>j<keys.length-1&&t<keys[j+1].time);if(i<0)i=keys.length-2;const a=keys[i],b=keys[i+1],q=phase(t,a.time,b.time);return {size:mix(a.size,b.size,q),x:mix(a.x,b.x,q),y:mix(a.y,b.y,q)};}
 function effects(front){
  const plan=d.creativeDirection?.effectPlan,cfg=plan?.config;
  if(!cfg||plan.mode==='none'||(t>=7.95&&t<11.6))return;
  const c=camera(),im=images[d.heroAsset];if(!im)return;
  const h=c.size*im.height/im.width;
  const rnd=(i,k)=>{const v=Math.sin(i*127.1+k*311.7+(cfg.seed||1)*43.19)*43758.5453;return v-Math.floor(v)};
  for(const burst of cfg.bursts||[]){const age=t-burst.time,dur=burst.duration||2.1;if(age<0||age>dur)continue;
   for(let i=0;i<(burst.count||72);i++){
    if((i%3===0)!==front)continue;
    const r=rnd(i+1,burst.time),s=i%2?-1:1,dep=front?1:.7;
    const x=c.x+c.size*.5+s*c.size*.3+s*(110+r*240)*age*dep+Math.sin(age*5+i)*24;
    const y=c.y+h*(burst.originY??.3)-(160+r*260)*age*dep+(cfg.gravity||155)*age*age;
    if(x<20||x>1900||y<105||y>935)continue;
    // Explicit title/CTA exclusion regions follow authored copy timing.
    if((plan.protectedRegions||[]).some(b=>t>=b.start&&t<b.end&&x>b.x&&x<b.x+b.w&&y>b.y&&y<b.y+b.h))continue;
    if(x>c.x+c.size*.18&&x<c.x+c.size*.82&&y>c.y+h*.12&&y<c.y+h*.88)continue;
    const size=(cfg.size||14)*(0.7+r*.8)*dep;
    ctx.save();ctx.globalAlpha=Math.min(1,age/.1)*Math.max(0,1-age/dur)*(front?.95:.7);ctx.translate(x,y);ctx.rotate(r*6+age*(i%2?4:-4));
    ctx.fillStyle=ctx.strokeStyle=cfg.palette[i%cfg.palette.length];
    if(cfg.shape==='ribbon'||cfg.shape==='streamer'){ctx.lineWidth=cfg.width||5;ctx.beginPath();ctx.moveTo(-size*.5,-size*2);ctx.bezierCurveTo(size*1.3,-size,-size*1.2,size,size*.5,size*2.5);ctx.stroke()}
    else if(cfg.shape==='star'||cfg.shape==='spark'){const n=cfg.shape==='star'?5:4;ctx.beginPath();for(let k=0;k<n*2;k++){const a=k*Math.PI/n,z=k%2?size*.32:size;k?ctx.lineTo(Math.cos(a)*z,Math.sin(a)*z):ctx.moveTo(Math.cos(a)*z,Math.sin(a)*z)}ctx.closePath();ctx.fill()}
    else{ctx.scale(1,Math.max(.25,Math.abs(Math.cos(age*6+i))));ctx.fillRect(-size*.5,-size*.7,size,size*1.4)}
    ctx.restore();
   }
  }
 }
 function accents(){
  const list=d.creativeDirection?.effectPlan?.accents||[],im=images[d.heroAsset];if(!im||t>=7.95&&t<11.6)return;const c=camera(),h=c.size*im.height/im.width;
  for(const a of list){if(t<a.start||t>a.end)continue;const u=(t-a.start)/(a.end-a.start),x=c.x+a.x*c.size,y=c.y+a.y*h,r=a.radius*c.size;
   ctx.save();ctx.beginPath();ctx.rect(0,105,1920,830);for(const b of d.creativeDirection?.effectPlan?.protectedRegions||[]){if(t>=b.start&&t<b.end)ctx.rect(b.x,b.y,b.w,b.h)}ctx.clip('evenodd');ctx.globalAlpha=Math.sin(Math.PI*u)*.62;
   if(a.kind==='glow'){const g=ctx.createRadialGradient(x,y,0,x,y,r);g.addColorStop(0,a.color);g.addColorStop(1,'rgba(255,255,255,0)');ctx.fillStyle=g;ctx.fillRect(x-r,y-r,r*2,r*2)}
   else{ctx.beginPath();ctx.arc(x,y,r,0,Math.PI*2);ctx.clip();const px=x-r+u*r*2,g=ctx.createLinearGradient(px-r*.2,0,px+r*.2,0);g.addColorStop(0,'rgba(255,255,255,0)');g.addColorStop(.5,a.color);g.addColorStop(1,'rgba(255,255,255,0)');ctx.fillStyle=g;ctx.fillRect(x-r,y-r,r*2,r*2)}ctx.restore();
  }
 }
 function product(){const im=images[d.heroAsset];if(!im)return;const c=camera();effects(false);ctx.drawImage(im,c.x,c.y,c.size,c.size*im.height/im.width);accents();effects(true);}
 function focused(){product();}
 function photo(index,zoom=1,cx=W/2,cy=H/2,offset=0){const shot=d.shots[index];if(!shot)return;const im=images[shot.asset];if(!im)return;const ratio=W/H;let sw=im.width,sh=im.height,sx=0,sy=0;if(sw/sh>ratio){sw=sh*ratio;sx=(im.width-sw)/2}else{sh=sw/ratio;sy=(im.height-sh)/2}ctx.save();ctx.translate(cx+offset,cy);ctx.scale(zoom,zoom);ctx.drawImage(im,sx,sy,sw,sh,-W/2,-H/2,W,H);ctx.restore();}
 // One type family, common size per headline, and stable optical alignment.
 function typeBlock(lines,x,y,size,width,start,end,mode='up',color=ink,weight=500){
  ctx.save();ctx.font=`${weight} ${size}px Helvetica Neue, Arial, sans-serif`;
  const longest=Math.max(1,...lines.map(line=>ctx.measureText(line).width));const fitted=Math.min(size,size*width/longest),leading=fitted*1.12;
  for(let i=0;i<lines.length;i++){
   const p=phase(t,start+i*.085,start+.55+i*.085),q=phase(t,end-.3,end);
   ctx.save();ctx.globalAlpha=p*(1-q);const shift=(1-p)*24;
   ctx.translate(mode==='side'?shift:0,mode==='down'?-shift:mode==='side'?0:shift);
   txt(lines[i],x,y+i*leading,fitted,{weight,color});ctx.restore();
  }
  ctx.restore();
 }
 function label(s,x,y,start,end,color=accent){const p=phase(t,start,start+.45)*(1-phase(t,end-.3,end));ctx.save();ctx.globalAlpha=p;ctx.translate(0,(1-p)*12);ctx.font='500 21px Helvetica Neue, Arial, sans-serif';ctx.fillStyle=color;let xx=x;for(const c of s){ctx.fillText(c,xx,y);xx+=ctx.measureText(c).width+2.1}ctx.restore();}
 function body(lines,x,y,start,end,color=accent,width=620){const p=phase(t,start,start+.5)*(1-phase(t,end-.3,end));ctx.save();ctx.globalAlpha=p;lines.forEach((line,i)=>txt(line,x,y+i*38,28,{weight:400,color,max:width}));ctx.restore();}
 // One continuous warm background. Hierarchy comes from type and product scale.
 if(t<3){
  focused();
  label(ap.introKicker,128,285,.55,2.65);
  typeBlock(e.intro,128,455,150,650,.62,2.68,'up',ink,600);
  body(ap.introBody,132,720,1.12,2.58,accent,570);
 }
 else if(t<5.2){
  focused();
  label(ap.featureKickers[0],128,258,3.4,4.9);
  typeBlock(e.features[0],128,382,98,480,3.42,4.92,'side',ink,500);
  body(ap.featureBodies[0],130,584,3.66,4.9,accent,460);
 }
 else if(t<7){
  focused();
  label(ap.featureKickers[1],1130,298,5.72,6.98,accent);
  typeBlock(e.features[1],1128,437,106,650,5.75,6.98,'up',ink,500);
  body(ap.featureBodies[1],1132,660,6.02,6.98,accent,620);
 }
 else if(t<8.15){focused();}
 else if(t>=11){
  product();
  label(ap.endKicker,1090,301,12.02,16);
  typeBlock(e.ending,1090,442,106,700,12.1,16,'down',ink,500);
  body(ap.endBody,1094,658,12.55,16,accent,680);
  const p=phase(t,12.95,13.5);ctx.save();ctx.globalAlpha=p;ctx.translate(0,(1-p)*18);
  txt(d.cta||'Take a closer look',1090,790,27,{color:ink,weight:500,max:330});txt('→',1430,790,29,{color:ink,weight:400});ctx.restore();
 }
 // Overlapping full-frame scene handoffs retain slow camera travel, without whip pans.
 if(t>=7.95&&t<11.6){
  if((t>=8.15&&t<8.62)||(t>=10.65&&t<11))product();
  const enter=phase(t,7.95,8.62),leave=phase(t,11.05,11.4),q=phase(t,9.48,10.08);
  ctx.save();ctx.globalAlpha=enter*(1-leave);
  const a=clamp((t-7.95)/2.1),b=clamp((t-9.48)/2.12);
  photo(0,mix(1.035,1.065,a),mix(960,952,a),540);
  ctx.save();ctx.beginPath();ctx.rect(W*(1-q),0,W*q,H);ctx.clip();photo(1,mix(1.045,1.075,b),mix(960,952,b)+90*(1-q),540);ctx.restore();
  ctx.restore();
 }
 // Stable brand and accessible sentence captions. No invented brand name.
 const inPhoto=t>=7.95&&t<11.6;txt(d.brandName||'Pet collection',128,88,24,{weight:600,color:ink});

 const n=(d.narration||[]).find(n=>t>=n.start&&t<n.end);if(n){ctx.save();ctx.font='400 27px Helvetica Neue, Arial, sans-serif';const w=ctx.measureText(n.text).width;ctx.fillStyle='rgba(24,35,32,.86)';ctx.fillRect((W-w)/2-28,989,w+56,51);txt(n.text,(W-w)/2,1024,27,{weight:400,color:'#fff'});ctx.restore();}
}
const api={draw};if(typeof module!=='undefined')module.exports=api;else root.TVCMotion=api;
})(typeof window!=='undefined'?window:this);
