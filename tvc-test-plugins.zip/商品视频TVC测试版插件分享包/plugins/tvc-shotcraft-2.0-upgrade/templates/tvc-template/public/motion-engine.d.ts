export function draw(ctx:CanvasRenderingContext2D,t:number,data:any,images:Record<string,HTMLImageElement>):void;
