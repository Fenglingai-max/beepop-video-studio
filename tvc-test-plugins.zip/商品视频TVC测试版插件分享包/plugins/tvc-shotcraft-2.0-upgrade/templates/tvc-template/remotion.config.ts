import {Config} from '@remotion/cli/config';
Config.overrideWebpackConfig((config)=>({...config,experiments:{...config.experiments,lazyCompilation:false},watchOptions:{...config.watchOptions,poll:1000}}));
