"""Extract embedded assets and selected product config from a TVC 2.0 HTM."""
import argparse,base64,json,re
from pathlib import Path,PurePosixPath
p=argparse.ArgumentParser();p.add_argument('htm');p.add_argument('output');p.add_argument('--reference',action='store_true',help='提取交付参考案例，而非默认配置');a=p.parse_args()
s=Path(a.htm).read_text();match=re.search(r'<script id="tvc-payload" type="application/json">(.*?)</script>',s,re.S)
if not match:raise SystemExit('未找到TVC 2.0配置')
payload=json.loads(match.group(1));d=payload.get('sampleConfig') if a.reference else payload['initialConfig']
if not d:raise SystemExit('此HTM未保留参考案例')
out=Path(a.output).resolve();out.mkdir(parents=True,exist_ok=True)
refs=[d['heroAsset'],*[x['asset'] for x in d['shots']],*[x['asset'] for x in d.get('narration',[])],d.get('music',{}).get('asset')]
for name in set(filter(None,refs)):
 if name.startswith('placeholder:'):raise SystemExit('当前是占位配置，请先在HTM绑定真实素材并另存，或使用--reference')
 rel=PurePosixPath(name)
 if rel.is_absolute() or '..' in rel.parts or ':' in name:raise SystemExit('素材路径必须是安全的相对路径：'+name)
 uri=payload['assets'].get(name)
 if not uri or ';base64,' not in uri:raise SystemExit('缺少内嵌素材：'+name)
 path=out/'public'/str(rel);path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(base64.b64decode(uri.split(';base64,',1)[1],validate=True))
(out/'product.json').write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n');print(out)
