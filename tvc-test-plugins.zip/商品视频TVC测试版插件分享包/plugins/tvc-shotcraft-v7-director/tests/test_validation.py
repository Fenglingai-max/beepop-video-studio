import copy
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
SKILL = ROOT / 'skills/tvc-v7'
spec = importlib.util.spec_from_file_location('validator', SKILL / 'scripts/validate.py')
v = importlib.util.module_from_spec(spec)
spec.loader.exec_module(v)


class ValidationTests(unittest.TestCase):
    def setUp(self):
        self.plan = json.loads((ROOT / 'tests/fixtures/hands-plan.json').read_text())
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.save_plan()
        edges = [0]
        for shot in self.plan["shots"]: edges.append(edges[-1] + round(shot["durationSec"] * self.plan["fps"]))
        count = len(self.plan["shots"])
        # Bytes are unit-test stand-ins only. Production CLI always uses ffprobe.
        (self.root / 'source.mp4').write_bytes(b'source fixture, not real video')
        (self.root / 'final.mp4').write_bytes(b'final fixture, not real video')
        self.review = {
            'planSha256': v.digest(self.root / 'plan.json'), 'synthetic': False,
            'reviewer': 'UNIT TEST ONLY', 'reviewedAt': '2026-11-11T00:00:00Z',
            'sources': [{'id': 'src', 'path': 'source.mp4', 'sha256': v.digest(self.root / 'source.mp4'), 'receipt': 'UNIT TEST ONLY', 'actualShots': [
                {'id': f'A{i}', 'startFrame': edges[i], 'endFrame': edges[i+1], 'reviewed': True, 'observation': 'TEST actual boundary'} for i in range(count)]}],
            'edit': [{'shotId': f'S{i+1}', 'sourceId': 'src', 'actualShotId': f'A{i}', 'type': 'video', 'inFrame': edges[i], 'outFrame': edges[i+1], 'speed': 1,
                      'productPass': True, 'productObservation': 'TEST geometry', 'motionPass': True, 'actionObservation': 'TEST contact'} for i in range(count)],
            'joins': [{'from': b['from'], 'to': b['to'], 'pass': True, 'observation': 'TEST join'} for b in self.plan['bridges']],
            'proofs': [{'benefitId': 'carry', 'shotId': 'S8', 'startSec': 16, 'endSec': 20, 'pass': True, 'observation': 'TEST evidence'}],
            'scores': {k: {'score': 4, 'evidence': 'UNIT TEST ONLY'} for k in ('continuity', 'story', 'benefits')},
            'fatalIssues': [], 'checks': {k: {'pass': True, 'evidence': 'UNIT TEST ONLY'} for k in ('silentWatch', 'fullWatch', 'listening', 'captions', 'musicRights')},
            'final': {'path': 'final.mp4', 'sha256': v.digest(self.root / 'final.mp4')}
        }
        for clip in self.review['edit']:
            clip['cinematographyReview'] = {'pass': True, 'movementObservation': 'TEST observed actual path in bound source interval', 'framingObservation': 'TEST whole product fits', 'focusObservation': 'TEST contact readable'}
        self.review['coverageReview'] = {k: {'pass': True, 'shotIds': row['shotIds'], 'observation': 'TEST actual visible content'} for k, row in self.plan['coverage'].items()}
        previous = {'hands-only': [], 'face-visible': []}
        for planned, clip in zip(self.plan['shots'], self.review['edit']):
            presence = planned['presence']
            clip['presenceReview'] = {'pass': True, 'observedPresence': presence, 'observedCastIds': planned['castIds'], 'observation': 'UNIT TEST actual role', 'productReadabilityObservation': 'UNIT TEST actual product framing', 'comparedShotIds': list(previous.get(presence, [])), 'recurrenceObservation': 'UNIT TEST actual state or viewpoint progression'}
            clip['pacingReview'] = {'pass': True, 'informationObservation': 'UNIT TEST bound visible information', 'holdObservation': 'UNIT TEST no dead wait', 'cutObservation': 'UNIT TEST contact completed before cut'}
            if presence in previous: previous[presence].append(planned['id'])
        self.review['rhythmReview'] = {'pass': True, 'densityObservation': 'UNIT TEST distinct actual source shots', 'deadTimeObservation': 'UNIT TEST no dead wait', 'recurrenceObservation': 'UNIT TEST server and receiver have different tasks'}
        self.meta = {'fps': 24, 'duration': 24, 'frames': 576, 'audio': True}

    def save_plan(self):
        (self.root / 'plan.json').write_text(json.dumps(self.plan))

    def errors(self):
        return v.release_errors(self.plan, self.review, self.root, lambda _: self.meta)

    def rejects(self, fragment):
        self.assertTrue(any(fragment in e for e in self.errors()), self.errors())

    def test_complete_record_structure(self):
        self.assertEqual(self.errors(), [])

    def test_short_or_long_film(self):
        for n in (19, 31):
            self.plan['durationSec'] = n
            self.assertTrue(v.plan_errors(self.plan))

    def test_plan_needs_five(self):
        self.plan['shots'] = self.plan['shots'][:4]
        self.assertIn('at least five planned shots required', v.plan_errors(self.plan))

    def test_no_stills(self):
        self.plan['shots'][0]['type'] = 'image'
        self.assertTrue(any('must be video' in e for e in v.plan_errors(self.plan)))

    def test_timeline_gap(self):
        self.plan['shots'][0]['durationSec'] = 3
        self.assertIn('shots must cover final duration exactly', v.plan_errors(self.plan))

    def test_core_evidence_coverage(self):
        for s in self.plan['shots']:
            s['benefitIds'] = []
        self.assertIn('core benefit missing planned visual coverage', v.plan_errors(self.plan))

    def test_story_requires_outcome(self):
        self.plan['story']['outcome'] = ''
        self.assertIn('story.outcome required', v.plan_errors(self.plan))

    def test_adjacency_not_arbitrary_matching(self):
        self.plan['bridges'][0]['to'] = 'S5'
        self.assertIn('bridge order must match cut order', v.plan_errors(self.plan))

    def test_plan_hash_stale(self):
        self.review['planSha256'] = 'old'
        self.rejects('plan hash stale')

    def test_source_changed(self):
        (self.root / 'source.mp4').write_bytes(b'changed')
        self.rejects('source hash stale')

    def test_final_changed(self):
        (self.root / 'final.mp4').write_bytes(b'changed')
        self.rejects('final video hash stale')

    def test_synthetic_not_formal(self):
        self.review['synthetic'] = True
        self.rejects('synthetic')

    def test_source_interval_reuse(self):
        self.review['edit'][1].update(actualShotId='A0', inFrame=0, outFrame=36)
        self.rejects('source interval reused')

    def test_same_long_take_split_six_times(self):
        self.review['sources'][0]['actualShots'] = [{'id': 'A', 'startFrame': 0, 'endFrame': 576, 'reviewed': True, 'observation': 'TEST one take'}]
        for c in self.review['edit']:
            c['actualShotId'] = 'A'
        self.rejects('fewer than five distinct actual camera shots')

    def test_rename_source_cannot_duplicate_camera_shots(self):
        other = copy.deepcopy(self.review['sources'][0])
        other['id'] = 'renamed'
        self.review['sources'].append(other)
        self.rejects('same actual shot duplicated')

    def test_unreviewed_actual_boundary(self):
        self.review['sources'][0]['actualShots'][0]['reviewed'] = False
        self.rejects('actual shot must be reviewed')

    def test_clip_cannot_cross_actual_cut(self):
        self.review['edit'][0]['outFrame'] = 100
        self.rejects('clip must lie in one reviewed actual shot')

    def test_no_padding_retime(self):
        self.review['edit'][0]['speed'] = 0.5
        self.rejects('padding retimes')

    def test_no_average_scores(self):
        self.review['scores']['continuity']['score'] = 3
        self.review['scores']['story']['score'] = 5
        self.review['scores']['benefits']['score'] = 5
        self.rejects('continuity must independently pass')

    def test_no_fatal_override(self):
        self.review['fatalIssues'] = ['hovering cord']
        self.rejects('fatal issues')

    def test_listening_cannot_be_pending(self):
        self.review['checks']['listening']['pass'] = False
        self.rejects('listening pending')

    def test_proof_must_be_in_referenced_shot(self):
        self.review['proofs'][0]['startSec'] = 2
        self.rejects('proof time must lie')

    def test_proof_must_reference_related_benefit(self):
        self.review['proofs'][0]['shotId'] = 'S1'
        self.rejects('proof references unrelated shot')

    def test_actual_duration_independently_checked(self):
        self.meta['duration'] = 18
        self.rejects('final duration differs')

    def test_audio_track_required(self):
        self.meta['audio'] = False
        self.rejects('final fps or audio missing')

    def test_each_required_coverage_cannot_be_omitted(self):
        for key in ('whole', 'detail', 'use', 'benefit'):
            p = copy.deepcopy(self.plan)
            del p['coverage'][key]
            self.assertTrue(any(key + ' coverage required' in e for e in v.plan_errors(p)))

    def test_studio_opening_must_transition_to_use(self):
        self.plan['productDirection'].update(category='电子产品', openingMode='studio-to-use', openingReason='外形和接口决定选购，先展现产品体积再操作')
        self.plan['shots'][0]['cinematography']['scene'] = 'studio'
        self.assertEqual(v.plan_errors(self.plan), [])
        for shot in self.plan['shots']:
            shot['cinematography']['scene'] = 'studio'
        self.assertTrue(any('studio opening then use' in e for e in v.plan_errors(self.plan)))

    def test_use_only_cannot_sneak_in_studio(self):
        self.plan['shots'][2]['cinematography']['scene'] = 'studio'
        self.assertTrue(any('use-only cannot' in e for e in v.plan_errors(self.plan)))

    def test_focal_and_focus_intent_required(self):
        for key in ('lensMm', 'focus', 'framingEnd'):
            p = copy.deepcopy(self.plan)
            del p['shots'][0]['cinematography'][key]
            self.assertTrue(v.plan_errors(p))

    def test_repetitive_motion_requires_explanation(self):
        for s in self.plan['shots']:
            s['cinematography']['movement']['type'] = 'push-in'
        self.assertTrue(any('repeated movement' in e for e in v.plan_errors(self.plan)))

    def test_action_locked_shot_is_allowed(self):
        self.assertEqual(self.plan['shots'][2]['cinematography']['movement']['type'], 'locked')
        self.assertEqual(v.plan_errors(self.plan), [])

    def test_all_locked_needs_explicit_exception(self):
        for s in self.plan['shots']:
            s['cinematography']['movement']['type'] = 'locked'
        self.plan['productDirection']['repetitionReason'] = '特殊观察式方案'
        self.assertTrue(any('staticException' in e for e in v.plan_errors(self.plan)))

    def test_requested_camera_is_not_actual_review(self):
        del self.review['edit'][0]['cinematographyReview']
        self.rejects('actual cinematography review pending')

    def test_actual_coverage_cannot_use_unrelated_shot(self):
        self.review['coverageReview']['whole']['shotIds'] = ['S3']
        self.rejects('actual whole coverage pending')

    def test_actual_four_dimensions_all_required(self):
        for key in ('whole', 'detail', 'use', 'benefit'):
            saved = self.review['coverageReview'].pop(key)
            self.rejects('actual ' + key + ' coverage pending')
            self.review['coverageReview'][key] = saved

    def enable_faces(self, same_person=False):
        c = self.plan['castingDecision']
        c.update(mode='face-supported', faceShotIds=['S1', 'S10'], faceValue='准备者说明任务，接收者的实际交流推进结果', removalEffect='丢失人物之间的接收关系')
        self.plan['shots'][0].update(presence='face-visible', castIds=['server'], humanBeat={'sceneKey': 'counter', 'viewKey': 'face-front', 'actionKey': 'look-at-product', 'stateKey': 'empty', 'narrativeGain': '建立准备目标'})
        self.plan['shots'][-1]['presence'] = 'face-visible'
        if same_person:
            c.update(characterStrategy='single', cast=c['cast'][:1])
            self.plan['shots'][-1]['castIds'] = ['server']

    def test_unmanned_product_opening_and_halfbody_use_can_coexist(self):
        p = json.loads((SKILL / 'references/example-plan.json').read_text())
        self.assertEqual(p['productDirection']['openingMode'], 'studio-to-use')
        self.assertEqual(p['shots'][0]['presence'], 'product-only')
        self.assertEqual(p['shots'][0]['cinematography']['movement']['type'], 'arc')
        self.assertEqual(p['castingDecision']['faceShotIds'], ['S6', 'S10'])
        self.assertEqual(v.plan_errors(p), [])

    def test_casting_analysis_required_for_new_contract(self):
        del self.plan['castingDecision']
        self.assertTrue(any('castingDecision.reason' in e for e in v.plan_errors(self.plan)))

    def test_hands_only_does_not_force_any_face(self):
        self.assertEqual(v.plan_errors(self.plan), [])
        self.assertEqual(self.plan['castingDecision']['faceShotIds'], [])

    def test_hands_only_cannot_sneak_in_faces(self):
        self.plan['shots'][2]['presence'] = 'face-visible'
        self.assertTrue(any('hands-only decision cannot add a face' in e for e in v.plan_errors(self.plan)))

    def test_product_only_cannot_sneak_in_hands(self):
        self.plan['castingDecision']['mode'] = 'product-only'
        self.assertTrue(any('product-only decision cannot add people' in e for e in v.plan_errors(self.plan)))

    def test_multiple_people_with_different_jobs_are_allowed(self):
        self.enable_faces()
        self.assertEqual(v.plan_errors(self.plan), [])

    def test_face_supported_requires_removal_analysis(self):
        self.enable_faces()
        self.plan['castingDecision']['removalEffect'] = ''
        self.assertTrue(any('removalEffect' in e for e in v.plan_errors(self.plan)))

    def test_face_shot_map_is_exact(self):
        self.enable_faces()
        self.plan['castingDecision']['faceShotIds'] = ['S1']
        self.assertTrue(any('faceShotIds must exactly' in e for e in v.plan_errors(self.plan)))

    def test_same_person_same_angle_look_repeated_at_end_rejected(self):
        self.enable_faces(same_person=True)
        self.plan['shots'][-1]['humanBeat'] = copy.deepcopy(self.plan['shots'][0]['humanBeat'])
        # Empty/full object state cannot disguise a repeated face/look shot.
        self.plan['shots'][-1]['humanBeat']['stateKey'] = 'loaded'
        self.assertTrue(any('repeated human angle/action' in e for e in v.plan_errors(self.plan)))

    def test_same_person_new_angle_and_action_are_allowed(self):
        self.enable_faces(same_person=True)
        self.plan['shots'][-1]['humanBeat'].update(sceneKey='counter', viewKey='face-side', actionKey='hand-cup-to-guest', narrativeGain='从准备转为交付')
        self.assertEqual(v.plan_errors(self.plan), [])

    def test_same_person_new_relevant_scene_is_allowed(self):
        self.enable_faces(same_person=True)
        self.plan['shots'][-1]['humanBeat'] = copy.deepcopy(self.plan['shots'][0]['humanBeat'])
        self.plan['shots'][-1]['humanBeat'].update(sceneKey='receiving-table', narrativeGain='到达接收地点')
        self.assertEqual(v.plan_errors(self.plan), [])

    def test_declared_cast_must_actually_participate(self):
        self.plan['castingDecision']['cast'].append({'id': 'extra', 'appearance': 'TEST', 'wardrobe': 'TEST', 'narrativeJob': 'TEST'})
        self.assertTrue(any('each declared person' in e for e in v.plan_errors(self.plan)))

    def test_long_contact_action_can_remain_complete(self):
        self.assertEqual(self.plan['shots'][7]['durationSec'], 4)
        self.assertEqual(v.plan_errors(self.plan), [])

    def test_long_hold_without_information_reason_rejected(self):
        del self.plan['shots'][7]['pacing']['longTakeReason']
        self.assertTrue(any('long hold needs' in e for e in v.plan_errors(self.plan)))

    def test_low_density_needs_protected_action_exception(self):
        p = copy.deepcopy(self.plan)
        p['shots'] = p['shots'][:6]
        for s in p['shots']:
            s['durationSec'] = 4
            s['pacing']['longTakeReason'] = 'TEST持续信息或完整接触'
        p['castingDecision'].update(characterStrategy='single', cast=p['castingDecision']['cast'][:1])
        p['rhythmPlan'].update(targetShotCount=6, alternative={'shotCount': 10, 'reason': 'TEST更密方案'})
        self.assertTrue(any('shot density too low' in e for e in v.editorial_errors(p)))
        p['rhythmPlan']['densityException'] = {'reason': 'TEST连续接触需完整四秒，密切会破坏动作证据', 'actionShotIds': ['S3', 'S4', 'S5']}
        self.assertEqual(v.editorial_errors(p), [])

    def test_pacing_read_time_cannot_exceed_shot(self):
        self.plan['shots'][0]['pacing']['minimumReadableSec'] = 99
        self.assertTrue(any('minimumReadableSec' in e for e in v.plan_errors(self.plan)))

    def test_density_candidates_cannot_be_identical(self):
        self.plan['rhythmPlan']['alternative']['shotCount'] = 10
        self.assertTrue(any('genuinely different' in e for e in v.plan_errors(self.plan)))

    def test_actual_density_cannot_be_bought_by_splitting_one_take(self):
        actual = self.review['sources'][0]['actualShots']
        actual[0]['endFrame'] = actual[1]['endFrame']
        del actual[1]
        self.review['edit'][1]['actualShotId'] = actual[0]['id']
        self.rejects('actual distinct shot count below rhythm target')

    def test_actual_face_choice_and_cast_need_review(self):
        self.review['edit'][2]['presenceReview']['observedPresence'] = 'face-visible'
        self.rejects('actual people/face selection differs')
        self.review['edit'][2]['presenceReview']['observedPresence'] = 'hands-only'
        self.review['edit'][2]['presenceReview']['observedCastIds'] = ['guest']
        self.rejects('actual people/face selection differs')

    def test_actual_pacing_and_dead_time_not_inferred_from_plan(self):
        del self.review['edit'][0]['pacingReview']
        self.rejects('actual new information, dead time and cut review pending')

    def test_nonadjacent_face_recurrence_requires_comparison(self):
        self.enable_faces()
        self.review['edit'][0]['presenceReview'].update(observedPresence='face-visible', observedCastIds=['server'], comparedShotIds=[])
        self.review['edit'][-1]['presenceReview'].update(observedPresence='face-visible', observedCastIds=['guest'], comparedShotIds=[])
        self.assertTrue(any('compare prior human shots' in e for e in v.editorial_review_errors(self.plan, self.review, 10)))

    def test_global_rhythm_cannot_be_pending(self):
        self.review['rhythmReview']['pass'] = False
        self.rejects('whole-film density, dead time and human recurrence review pending')

    def test_cinematography_v1_history_remains_compatible(self):
        old = json.loads((ROOT / 'tests/fixtures/cinematography-v1-plan.json').read_text())
        self.assertNotIn('editorialVersion', old)
        self.assertEqual(v.plan_errors(old), [])

    def test_legacy_records_remain_readable(self):
        legacy = json.loads((SKILL / 'references/legacy-example-plan.json').read_text())
        self.assertEqual(v.plan_errors(legacy), [])


if __name__ == '__main__':
    unittest.main()
