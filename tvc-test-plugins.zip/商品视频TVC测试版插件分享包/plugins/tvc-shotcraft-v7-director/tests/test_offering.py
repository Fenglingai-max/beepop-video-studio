import copy,json,unittest
import test_validation as base
v=base.v
class OfferingTests(unittest.TestCase):
    def setUp(self):
        self.p=json.loads((base.ROOT/'tests/fixtures/hands-plan.json').read_text())
        self.p['offeringVersion']=1;groups=['blue','black','pink','yellow']
        self.p['productOffering']={'saleUnit':'bundle','saleUnitReason':'4colors one pair each in one purchase','identityGroups':[{'id':g,'label':g+' pair','basis':'Original photo and listing','unitCount':1,'unit':'pair'} for g in groups],'requiredGroupIds':groups,'wholeOfferingApproach':'All4pairs separated on linen bed','stillLifeRole':'Show palette and pair count in home setting','representativeUseRole':'Blue pair illustrates wear, not whole set'}
        self.p['offeringCoverage']={'whole':{'shotIds':['S1'],'approach':'together','visibleContent':'Four pairs8socks on bed','reason':'Read sale unit'},'groups':[{'groupId':g,'shotIds':['S1'],'visibleContent':g+' pair both socks visible'} for g in groups]}
        self.r={'edit':[{'shotId':'S1'}],'offeringReview':{'whole':{'pass':True,'shotIds':['S1'],'observation':'UNIT TEST all4pairs readable'},'groups':[{'groupId':g,'pass':True,'shotIds':['S1'],'observation':'UNIT TEST '+g+' pair readable'} for g in groups],'representativeUseObservation':'UNIT TEST blue does not represent other colors'}}
    def test_four_color_bundle(self):
        self.assertEqual(v.plan_errors(self.p),[]);self.assertEqual(v.offering_review_errors(self.p,self.r),[])
    def test_blue_only_not_whole_set(self):
        self.p['offeringCoverage']['groups']=self.p['offeringCoverage']['groups'][:1]
        self.assertTrue(any('required group coverage' in e for e in v.plan_errors(self.p)))
    def test_cannot_drop_required_colors(self):
        self.p['productOffering']['requiredGroupIds']=['blue']
        self.assertTrue(any('bundle must cover every' in e for e in v.offering_errors(self.p)))
    def test_actual_missing_color(self):
        self.r['offeringReview']['groups'].pop();self.assertTrue(any('coverage incomplete' in e for e in v.offering_review_errors(self.p,self.r)))
    def test_wrong_count_fails(self):
        self.r['offeringReview']['whole'].update({'pass':False,'observation':'UNIT TEST six socks rather than8'});self.assertTrue(v.offering_review_errors(self.p,self.r))
    def test_unselected_footage_not_evidence(self):
        self.r['offeringReview']['groups'][0]['shotIds']=['S3'];self.assertTrue(v.offering_review_errors(self.p,self.r))
    def test_duplicate_group_not_missing_group(self):
        self.r['offeringReview']['groups'][-1]=copy.deepcopy(self.r['offeringReview']['groups'][0]);self.assertTrue(v.offering_review_errors(self.p,self.r))
    def test_choice_variants_not_bundled(self):
        self.p['productOffering'].update(saleUnit='choice-variants',requiredGroupIds=['blue'],variantSelectionReason='Only blue SKU purchased')
        self.p['offeringCoverage']['groups']=self.p['offeringCoverage']['groups'][:1];self.assertEqual(v.offering_errors(self.p),[])
    def test_single_supported(self):
        o=self.p['productOffering'];o.update(saleUnit='single',identityGroups=o['identityGroups'][:1],requiredGroupIds=['blue'])
        self.p['offeringCoverage']['groups']=self.p['offeringCoverage']['groups'][:1];self.assertEqual(v.offering_errors(self.p),[])
    def test_bed_still_life_without_people(self):
        self.p['productDirection']['openingMode']='still-life-to-use';self.p['shots'][0]['cinematography']['scene']='contextual-still-life'
        self.assertEqual(self.p['shots'][0]['presence'],'product-only');self.assertEqual(v.cinematography_errors(self.p),[])
    def test_use_first_with_later_still_life(self):
        self.p['productDirection']['openingMode']='use-first';self.p['shots'][0]['cinematography']['scene']='use';self.p['shots'][1]['cinematography']['scene']='contextual-still-life'
        self.assertEqual(v.cinematography_errors(self.p),[])
    def test_release_integration_rejects_missing_group(self):
        case=base.ValidationTests('test_complete_record_structure');case.setUp();self.addCleanup(case.doCleanups)
        case.plan=copy.deepcopy(self.p);case.review['offeringReview']=copy.deepcopy(self.r['offeringReview'])
        case.save_plan();case.review['planSha256']=v.digest(case.root/'plan.json')
        self.assertEqual(case.errors(),[])
        case.review['offeringReview']['groups'].pop()
        self.assertTrue(any('offering review:' in e for e in case.errors()))
    def test_counts_need_units_and_source_basis(self):
        self.p['productOffering']['identityGroups'][0]['unitCount']=0
        self.assertTrue(any('positive counts' in e for e in v.offering_errors(self.p)))
    def test_history_compatible(self):
        del self.p['offeringVersion'];del self.p['productOffering'];del self.p['offeringCoverage'];self.assertEqual(v.plan_errors(self.p),[])
if __name__=='__main__':unittest.main()
