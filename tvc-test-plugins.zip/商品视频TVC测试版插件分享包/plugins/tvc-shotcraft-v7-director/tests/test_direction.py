import unittest
import test_validation as base
v=base.v
class DirectionTests(unittest.TestCase):
    setUp=base.ValidationTests.setUp
    save_plan=base.ValidationTests.save_plan
    enable_faces=base.ValidationTests.enable_faces
    def enable(self):
        self.plan.update(directionVersion=1,facePolicy={'mode':'preferred','reason':'Product evidence matters','requiredShotIds':[]},spatialActionPlan={'strategy':'route','productSuitability':'Carry product','route':'Counter to table','actionProgression':'Lift carry set down','environmentLayers':'Person and destination','promptIntegration':'Include route in shot prompts'})
        self.review['spatialActionReview']={'pass':True,**{k:'Observed in selected intervals' for k in ('observedRoute','observedActionProgression','environmentObservation','selectionReason')}}
    def check(self):return v.editorial_review_errors(self.plan,self.review,10)
    def test_complete(self):
        self.enable();self.assertEqual(v.plan_errors(self.plan),[]);self.assertEqual(self.check(),[])
    def test_crop_usable(self):
        self.enable_faces();self.enable()
        for i in (0,-1):self.review['edit'][i]['presenceReview'].update(observedPresence='person-cropped',observedCastIds=self.plan['shots'][i]['castIds'],faceVariationObservation='Head cropped; product, task and wardrobe clear')
        self.review['edit'][-1]['presenceReview']['comparedShotIds']=['S1']
        self.assertEqual(self.check(),[])
    def test_essential_face(self):
        self.enable_faces();self.enable();self.plan['facePolicy'].update(requiredShotIds=['S1'],requirementBasis='Explicit user requirement')
        self.review['edit'][0]['presenceReview'].update(observedPresence='person-cropped',faceVariationObservation='Head cropped')
        self.assertTrue(any('actual people/face' in e for e in self.check()))
    def test_identity_still_required(self):
        self.enable();self.review['edit'][2]['presenceReview'].update(observedPresence='person-cropped',observedCastIds=['unknown'],faceVariationObservation='Head cropped')
        self.assertTrue(any('actual people/face' in e for e in self.check()))
    def test_stationary_reason(self):
        self.enable();self.plan['spatialActionPlan']['strategy']='stationary'
        self.assertTrue(any('stationary task' in e for e in v.plan_errors(self.plan)))
        self.plan['spatialActionPlan']['stationaryReason']='Fixed workbench assembly with progressing stages'
        self.assertEqual(v.plan_errors(self.plan),[])
    def test_spatial_review_required(self):
        self.enable();del self.review['spatialActionReview'];self.assertTrue(any('spatial/action' in e for e in self.check()))
    def test_spatial_plan_required(self):
        self.enable();del self.plan['spatialActionPlan'];self.assertTrue(any('spatialActionPlan' in e for e in v.plan_errors(self.plan)))
