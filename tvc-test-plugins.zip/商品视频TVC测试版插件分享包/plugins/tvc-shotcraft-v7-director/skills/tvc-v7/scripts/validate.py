#!/usr/bin/env python3
"""Validate records; never substitutes for watching, listening, or product review."""
import argparse
import hashlib
import json
import math
import os
from pathlib import Path
import shutil
import subprocess
import sys


def text(value):
    return isinstance(value, str) and bool(value.strip())


def number(value):
    return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value)


def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def cinematography_errors(p):
    # Historical records stay readable; all new tasks must opt into version 1.
    if 'cinematographyVersion' not in p:
        return []
    errors = []
    def need(ok, message):
        if not ok: errors.append('cinematography: ' + message)
    need(p.get('cinematographyVersion') == 1, 'unsupported version')
    direction = p.get('productDirection', {})
    for k in ('category', 'openingReason', 'alternative', 'referenceLimits'):
        need(text(direction.get(k)), k + ' required')
    mode = direction.get('openingMode')
    need(mode in ('studio-to-use', 'still-life-to-use', 'use-first', 'use-only'), 'invalid openingMode')
    shots = p.get('shots', [])
    by_id = {s.get('id'): s for s in shots}
    scenes, moves = [], []
    for s in shots:
        c = s.get('cinematography', {})
        tag = str(s.get('id')) + '.'
        need(c.get('scene') in ('studio', 'contextual-still-life', 'use', 'detail'), tag + 'scene required')
        scenes.append(c.get('scene'))
        need(number(c.get('lensMm')) and c['lensMm'] > 0, tag + 'positive lens intent required')
        for k in ('lensReason', 'cameraPosition', 'framingStart', 'framingEnd', 'visualPurpose'):
            need(text(c.get(k)), tag + k + ' required')
        m = c.get('movement', {})
        need(m.get('type') in ('locked', 'push-in', 'pull-out', 'arc', 'track', 'slide', 'pan', 'tilt'), tag + 'movement type required')
        moves.append(m.get('type'))
        for k in ('path', 'extent', 'pace', 'reason'):
            need(text(m.get(k)), tag + 'movement.' + k + ' required')
        for k in ('target', 'behavior', 'depthOfField'):
            need(text(c.get('focus', {}).get(k)), tag + 'focus.' + k + ' required')
    if scenes:
        if mode == 'studio-to-use':
            need(scenes[0] == 'studio' and 'use' in scenes[1:], 'studio-to-use needs studio opening then use')
        if mode == 'still-life-to-use':
            need(scenes[0] == 'contextual-still-life' and 'use' in scenes[1:], 'still-life-to-use needs contextual still life then use')
        if mode in ('use-first', 'use-only'):
            need(scenes[0] == 'use', 'use opening required')
        if mode == 'use-only':
            need('studio' not in scenes, 'use-only cannot contain studio')
            need('contextual-still-life' not in scenes, 'use-only cannot contain contextual still life; choose use-first for mixed coverage')
    if moves and len(set(moves)) == 1:
        need(text(direction.get('repetitionReason')), 'repeated movement needs reason')
    if moves and all(m == 'locked' for m in moves):
        need(text(direction.get('staticException')), 'all locked needs staticException')
    for key in ('whole', 'detail', 'use', 'benefit'):
        row = p.get('coverage', {}).get(key, {})
        ids = row.get('shotIds', [])
        valid = isinstance(ids, list) and bool(ids) and all(isinstance(i, str) and i in by_id for i in ids)
        need(valid and text(row.get('visibleContent')), key + ' coverage required')
        if valid and key == 'use':
            need(any(by_id[i].get('cinematography', {}).get('scene') == 'use' for i in ids), 'use coverage needs use scene')
        if valid and key == 'benefit':
            need(any(by_id[i].get('benefitIds') for i in ids), 'benefit coverage needs visible benefit shot')
    return errors



def offering_errors(p):
    """Check declared sale-unit coverage, not visual color/count recognition."""
    if 'offeringVersion' not in p:
        return []
    errors = []
    def need(ok, message):
        if not ok: errors.append('offering: ' + message)
    need(p.get('offeringVersion') == 1, 'unsupported version')
    offering = p.get('productOffering', {})
    mode = offering.get('saleUnit')
    need(mode in ('single', 'bundle', 'choice-variants'), 'saleUnit must distinguish single, bundle and choice-variants')
    for key in ('saleUnitReason', 'wholeOfferingApproach', 'stillLifeRole', 'representativeUseRole'):
        need(text(offering.get(key)), key + ' required')
    groups = offering.get('identityGroups', [])
    valid_groups = isinstance(groups, list) and bool(groups) and all(isinstance(g, dict) and all(text(g.get(k)) for k in ('id', 'label', 'basis')) and type(g.get('unitCount')) is int and g['unitCount'] > 0 and text(g.get('unit')) for g in groups)
    need(valid_groups, 'identityGroups need source-backed IDs, labels and positive counts with units')
    if not valid_groups: return errors
    ids = [g['id'] for g in groups]
    need(len(set(ids)) == len(ids), 'identityGroups IDs must be unique')
    required = offering.get('requiredGroupIds', [])
    valid_required = isinstance(required, list) and bool(required) and all(isinstance(i, str) and i in ids for i in required) and len(set(required)) == len(required)
    need(valid_required, 'requiredGroupIds must name known unique identity groups')
    if not valid_required: return errors
    if mode == 'bundle': need(set(required) == set(ids), 'bundle must cover every declared essential group; a representative item is not the whole offering')
    if mode == 'choice-variants': need(text(offering.get('variantSelectionReason')), 'choice-variants need selection reason; alternatives are not automatically bundled')
    shots = {x.get('id') for x in p.get('shots', [])}
    coverage = p.get('offeringCoverage', {})
    def valid_shots(row):
        x = row.get('shotIds', [])
        return isinstance(x, list) and bool(x) and all(isinstance(i, str) and i in shots for i in x) and len(set(x)) == len(x)
    whole = coverage.get('whole', {})
    whole_ok = valid_shots(whole)
    need(whole_ok and text(whole.get('visibleContent')) and whole.get('approach') in ('together', 'sequence') and text(whole.get('reason')), 'whole sale-unit coverage required; one worn pair cannot stand for a multicolor set')
    whole_ids = set(whole['shotIds']) if whole_ok else set()
    rows = coverage.get('groups', [])
    need(isinstance(rows, list), 'coverage groups must be a list')
    seen = []
    for row in rows if isinstance(rows, list) else []:
        if not isinstance(row, dict):
            need(False, 'invalid coverage group'); continue
        gid = row.get('groupId'); seen.append(gid)
        ok = valid_shots(row)
        need(isinstance(gid, str) and gid in required and ok and text(row.get('visibleContent')), 'each required group needs visible source-bound shot coverage')
        if ok: need(set(row['shotIds']) <= whole_ids, 'group coverage must be included in whole-offering shots')
    need(len(seen) == len(required) and all(isinstance(i, str) for i in seen) and set(seen) == set(required), 'missing or duplicate required group coverage')
    return errors


def offering_review_errors(p, review):
    if p.get('offeringVersion') != 1:
        return []
    errors = []
    def need(ok, message):
        if not ok: errors.append('offering review: ' + message)
    actual = {x.get('shotId') for x in review.get('edit', [])}
    planned = p.get('offeringCoverage', {})
    r = review.get('offeringReview', {})
    def check(row, plan_row):
        ids = row.get('shotIds', [])
        return row.get('pass') is True and text(row.get('observation')) and isinstance(ids, list) and bool(ids) and all(isinstance(i, str) and i in actual and i in plan_row.get('shotIds', []) for i in ids) and len(set(ids)) == len(ids)
    need(check(r.get('whole', {}), planned.get('whole', {})), 'actual whole sale-unit count/color observation required')
    plans = {x['groupId']: x for x in planned.get('groups', [])}
    rows = r.get('groups', [])
    need(isinstance(rows, list), 'actual group observations required')
    seen = []
    for row in rows if isinstance(rows, list) else []:
        if not isinstance(row, dict):
            need(False, 'invalid actual group'); continue
        gid = row.get('groupId'); seen.append(gid)
        need(isinstance(gid, str) and gid in plans and check(row, plans.get(gid, {})), 'actual required group missing, unreadable or not bound to selected planned footage')
    need(len(seen) == len(plans) and all(isinstance(i, str) for i in seen) and set(seen) == set(plans), 'actual required group coverage incomplete or duplicated')
    need(text(r.get('representativeUseObservation')), 'distinguish representative use from whole bundle evidence')
    return errors


def direction_errors(p):
    """New direction contract; historical submitted plans remain readable."""
    if 'directionVersion' not in p:
        return []
    errors = []
    def need(ok, message):
        if not ok: errors.append('direction: ' + message)
    need(p.get('directionVersion') == 1, 'unsupported version')
    need(p.get('editorialVersion') == 1 and p.get('cinematographyVersion') == 1, 'requires editorial and cinematography contracts')
    policy = p.get('facePolicy', {})
    need(policy.get('mode') == 'preferred', 'faces are preferred, not a default acceptance gate')
    need(text(policy.get('reason')), 'product-specific face reason required')
    ids = policy.get('requiredShotIds', [])
    faces = p.get('castingDecision', {}).get('faceShotIds', [])
    need(isinstance(ids, list) and all(isinstance(i, str) for i in ids) and len(ids) == len(set(ids)) and all(i in faces for i in ids), 'requiredShotIds must be unique planned face shots')
    if ids: need(text(policy.get('requirementBasis')), 'required face needs explicit user instruction or face-dependent evidence')
    space = p.get('spatialActionPlan', {})
    need(space.get('strategy') in ('route', 'task-stations', 'stationary'), 'choose spatial strategy by product task')
    for key in ('productSuitability', 'route', 'actionProgression', 'environmentLayers', 'promptIntegration'):
        need(text(space.get(key)), 'spatialActionPlan.' + key + ' required')
    if space.get('strategy') == 'stationary':
        need(text(space.get('stationaryReason')), 'stationary task needs product-specific reason, not generation convenience')
    return errors


def editorial_errors(p):
    """Declarative checks only; text keys do not prove real visual variation."""
    if 'editorialVersion' not in p:
        return []  # Preserve historical submitted contracts.
    errors = []
    def need(ok, message):
        if not ok: errors.append('editorial: ' + message)
    need(p.get('editorialVersion') == 1, 'unsupported version')
    shots = p.get('shots', [])
    by_id = {s.get('id'): s for s in shots}
    c = p.get('castingDecision', {})
    mode, strategy = c.get('mode'), c.get('characterStrategy')
    need(mode in ('product-only', 'hands-only', 'face-supported'), 'choose product-only, hands-only or face-supported')
    for key in ('reason', 'faceValue', 'removalEffect', 'productReadabilityRisk'):
        need(text(c.get(key)), 'castingDecision.' + key + ' required')
    need(strategy in ('none', 'single', 'multiple'), 'explicit characterStrategy required')
    cast = c.get('cast', [])
    need(isinstance(cast, list), 'cast must be a list')
    cast_ids = [x.get('id') for x in cast if isinstance(x, dict)] if isinstance(cast, list) else []
    need(len(cast_ids) == len(set(cast_ids)) and all(text(x) for x in cast_ids), 'unique cast IDs required')
    for row in cast if isinstance(cast, list) else []:
        need(isinstance(row, dict) and all(text(row.get(k)) for k in ('id', 'appearance', 'wardrobe', 'narrativeJob')), 'each cast needs identity, wardrobe and narrativeJob')
    need((strategy == 'none' and not cast_ids) or (strategy == 'single' and len(cast_ids) == 1) or (strategy == 'multiple' and len(cast_ids) >= 2), 'cast count must match characterStrategy')
    declared_faces = c.get('faceShotIds', [])
    need(isinstance(declared_faces, list) and len(declared_faces) == len(set(declared_faces)) and all(x in by_id for x in declared_faces), 'valid unique faceShotIds required')
    faces, used_cast, seen_human = [], set(), set()
    for s in shots:
        sid = str(s.get('id')); presence = s.get('presence'); ids = s.get('castIds', [])
        valid_ids = isinstance(ids, list) and all(isinstance(x, str) and x in cast_ids for x in ids) and len(ids) == len(set(ids))
        need(valid_ids, sid + ' known unique castIds required')
        need(presence in ('product-only', 'hands-only', 'face-visible'), sid + ' presence required')
        if valid_ids: used_cast.update(ids)
        need((presence == 'product-only' and not ids) or (presence in ('hands-only', 'face-visible') and bool(ids)), sid + ' presence/cast mismatch')
        if presence == 'face-visible': faces.append(s.get('id'))
        if mode == 'product-only': need(presence == 'product-only', 'product-only decision cannot add people')
        if mode == 'hands-only': need(presence != 'face-visible', 'hands-only decision cannot add a face')
        if presence in ('hands-only', 'face-visible'):
            beat = s.get('humanBeat', {})
            for key in ('sceneKey', 'viewKey', 'actionKey', 'stateKey', 'narrativeGain'):
                need(text(beat.get(key)), sid + '.humanBeat.' + key + ' required')
            # Face recurrences cannot hide a repeated look/smile behind empty/full product states.
            key = (presence, tuple(sorted(ids)) if valid_ids else (), beat.get('sceneKey'), beat.get('viewKey'), beat.get('actionKey'))
            if presence == 'hands-only': key += (beat.get('stateKey'),)
            need(key not in seen_human, 'repeated human angle/action: ' + sid + '; change meaningful person/scene/view/action, not labels')
            seen_human.add(key)
        pace = s.get('pacing', {})
        need(pace.get('beatType') in ('setup', 'detail', 'action', 'result'), sid + ' pacing.beatType required')
        for key in ('newInformation', 'entryCue', 'exitCue', 'cutReason'):
            need(text(pace.get(key)), sid + '.pacing.' + key + ' required')
        d, read = s.get('durationSec'), pace.get('minimumReadableSec')
        need(number(read) and number(d) and 0 < read <= d, sid + ' minimumReadableSec must fit shot')
        limit = 3.5 if pace.get('beatType') == 'action' else 2.5
        if number(d) and d > limit:
            need(text(pace.get('longTakeReason')), sid + ' long hold needs longTakeReason tied to visible information/action')
    need(used_cast == set(cast_ids), 'each declared person must have a real shot job')
    need(set(faces) == set(declared_faces), 'faceShotIds must exactly match planned face-visible shots')
    need((mode == 'face-supported' and bool(faces)) or (mode != 'face-supported' and not faces), 'face-supported decision must have purposeful face shots; other modes none')
    rhythm = p.get('rhythmPlan', {})
    target = rhythm.get('targetShotCount')
    need(type(target) is int and target == len(shots), 'targetShotCount must equal distinct planned shot count')
    need(text(rhythm.get('selectionReason')), 'rhythmPlan.selectionReason required')
    alt = rhythm.get('alternative', {})
    need(type(alt.get('shotCount')) is int and alt['shotCount'] >= 5 and alt['shotCount'] != target and text(alt.get('reason')), 'compare a genuinely different feasible shot-density candidate')
    if number(p.get('durationSec')) and len(shots) < math.ceil(p['durationSec'] / 3):
        exception = rhythm.get('densityException', {})
        ids = exception.get('actionShotIds', [])
        valid = isinstance(ids, list) and bool(ids) and all(i in by_id and by_id[i].get('pacing', {}).get('beatType') == 'action' for i in ids)
        need(text(exception.get('reason')) and valid, 'shot density too low; preserve necessary complete actions with an explicit densityException, not padding')
    return errors


def editorial_review_errors(p, review, actual_count):
    if p.get('editorialVersion') != 1:
        return []
    errors = []
    def need(ok, message):
        if not ok: errors.append('editorial review: ' + message)
    need(actual_count >= p['rhythmPlan']['targetShotCount'], 'actual distinct shot count below rhythm target; splitting one take cannot create density')
    previous = {'hands-only': [], 'face-visible': []}
    for planned, clip in zip(p['shots'], review.get('edit', [])):
        r = clip.get('presenceReview', {})
        observed = r.get('observedPresence')
        compatible = observed == planned['presence']
        if p.get('directionVersion') == 1 and planned['id'] not in p.get('facePolicy', {}).get('requiredShotIds', []):
            # Cropping a face cannot alone waste otherwise sound footage. Identity,
            # product readability, action/contact and recurrence still get reviewed.
            human = ('hands-only', 'face-visible', 'person-cropped')
            compatible = compatible or (planned['presence'] in human and observed in human and text(r.get('faceVariationObservation')))
        need(r.get('pass') is True and compatible and isinstance(r.get('observedCastIds'), list) and sorted(r['observedCastIds']) == sorted(planned['castIds']), 'actual people/face selection differs from product decision')
        for key in ('observation', 'productReadabilityObservation'):
            need(text(r.get(key)), 'actual presence ' + key + ' required')
        presence = planned['presence']
        if presence in previous:
            compared = r.get('comparedShotIds', [])
            need(isinstance(compared, list) and set(previous[presence]) <= set(compared) and set(compared) <= set(previous[presence]), 'compare prior human shots, including nonadjacent opening/ending')
            if previous[presence]: need(text(r.get('recurrenceObservation')), 'actual recurrent human variation needs observation')
            previous[presence].append(planned['id'])
        r = clip.get('pacingReview', {})
        need(r.get('pass') is True and all(text(r.get(k)) for k in ('informationObservation', 'holdObservation', 'cutObservation')), 'actual new information, dead time and cut review pending')
    if p.get('directionVersion') == 1:
        spatial = review.get('spatialActionReview', {})
        need(spatial.get('pass') is True and all(text(spatial.get(k)) for k in ('observedRoute', 'observedActionProgression', 'environmentObservation', 'selectionReason')), 'actual spatial/action review pending; camera micro-movement is not subject progression')
    r = review.get('rhythmReview', {})
    need(r.get('pass') is True and all(text(r.get(k)) for k in ('densityObservation', 'deadTimeObservation', 'recurrenceObservation')), 'whole-film density, dead time and human recurrence review pending')
    return errors


def plan_errors(p):
    errors = []
    def require(ok, message):
        if not ok:
            errors.append(message)
    require(p.get('version') == 7, 'version must be 7')
    duration = p.get('durationSec')
    require(number(duration) and 20 <= duration <= 30, 'duration must be 20–30 seconds')
    fps = p.get('fps')
    require(number(fps) and fps > 0, 'positive output fps required')
    for key in ('product', 'story', 'durationReason'):
        require(text(p.get(key)) if key == 'durationReason' else isinstance(p.get(key), dict), key + ' required')
    for key in ('task', 'trigger', 'outcome', 'productContribution'):
        require(text(p.get('story', {}).get(key)), 'story.' + key + ' required')
    product = p.get('product', {})
    require(text(product.get('name')), 'product.name required')
    require(isinstance(product.get('invariants'), list) and bool(product.get('invariants')), 'product invariants required')
    candidates = p.get('durationCandidates', [])
    require(isinstance(candidates, list) and len(candidates) >= 2 and
            all(isinstance(c, dict) and number(c.get('seconds')) and 20 <= c['seconds'] <= 30 and text(c.get('reason')) for c in candidates),
            'compare at least two feasible durations with reasons')
    benefits = p.get('benefits', [])
    require(isinstance(benefits, list) and bool(benefits), 'benefits required')
    benefit_ids = []
    for b in benefits:
        for key in ('id', 'claim', 'basis', 'visibleProof'):
            require(text(b.get(key)), 'benefit.' + key + ' required')
        require(b.get('basisType') in ('observed', 'documented', 'user-supplied'), 'benefit basisType required; unsupported claims cannot be core benefits')
        benefit_ids.append(b.get('id'))
    require(len(set(benefit_ids)) == len(benefit_ids), 'duplicate benefit IDs')
    core_ids = {b['id'] for b in benefits if b.get('core') is True and text(b.get('id'))}
    require(1 <= len(core_ids) <= 3, 'select one to three core benefits')
    shots = p.get('shots', [])
    require(isinstance(shots, list) and len(shots) >= 5, 'at least five planned shots required')
    ids, coverage, total = [], set(), 0
    for shot in shots:
        sid = shot.get('id')
        ids.append(sid)
        for key in ('id', 'action', 'storyChange', 'startState', 'endState', 'framing', 'camera', 'location', 'subjectAnchor', 'screenDirection'):
            require(text(shot.get(key)), str(sid) + '.' + key + ' required')
        d = shot.get('durationSec')
        require(number(d) and d > 0, str(sid) + ' needs positive duration')
        if number(d) and number(fps):
            total += d
            require(abs(d * fps - round(d * fps)) < 1e-6, str(sid) + ' duration must fit output frames')
        require(shot.get('type') == 'video', str(sid) + ' must be video')
        require(shot.get('role') in ('setup', 'action', 'proof', 'result', 'close'), str(sid) + ' invalid narrative role')
        bids = shot.get('benefitIds', [])
        require(isinstance(bids, list) and all(b in benefit_ids for b in bids), str(sid) + ' unknown benefit')
        if isinstance(bids, list):
            coverage.update(bids)
            if bids:
                require(text(shot.get('proofOnScreen')), str(sid) + ' visible evidence description required')
    require(all(text(i) for i in ids) and len(set(ids)) == len(ids), 'unique shot IDs required')
    if number(duration):
        require(abs(total - duration) < 1e-6, 'shots must cover final duration exactly')
    require(core_ids <= coverage, 'core benefit missing planned visual coverage')
    roles = {s.get('role') for s in shots}
    require({'setup', 'action', 'result'} <= roles, 'setup, action and result required')
    bridges = p.get('bridges', [])
    require(len(bridges) == max(0, len(shots) - 1), 'one bridge per adjacent shot pair required')
    allowed = {'action', 'state', 'space', 'eyeline', 'match', 'ellipsis'}
    for i, bridge in enumerate(bridges):
        require(i + 1 < len(ids) and bridge.get('from') == ids[i] and bridge.get('to') == ids[i + 1], 'bridge order must match cut order')
        require(bridge.get('kind') in allowed and text(bridge.get('anchor')) and text(bridge.get('reason')), 'bridge needs type, visual anchor and reason')
    errors.extend(cinematography_errors(p))
    errors.extend(editorial_errors(p))
    errors.extend(direction_errors(p))
    errors.extend(offering_errors(p))
    return errors


def probe(path, executable):
    env = dict(os.environ)
    binary_dir = Path(executable).resolve().parent
    if sys.platform == 'darwin' and any(binary_dir.glob('*.dylib')):
        env['DYLD_LIBRARY_PATH'] = str(binary_dir) + (os.pathsep + env['DYLD_LIBRARY_PATH'] if env.get('DYLD_LIBRARY_PATH') else '')
    result = subprocess.run([executable, '-v', 'error', '-show_streams', '-show_format', '-of', 'json', str(path)], capture_output=True, text=True, timeout=60, check=True, env=env)
    data = json.loads(result.stdout)
    stream = next(s for s in data['streams'] if s.get('codec_type') == 'video')
    rate = stream.get('avg_frame_rate', '0/1').split('/')
    fps = float(rate[0]) / float(rate[1])
    return {'fps': fps, 'duration': float(stream.get('duration') or data['format']['duration']),
            'frames': int(stream['nb_frames']) if stream.get('nb_frames', '').isdigit() else None,
            'audio': any(s.get('codec_type') == 'audio' for s in data['streams'])}


def release_errors(p, review, root, prober):
    errors = plan_errors(p)
    def require(ok, message):
        if not ok:
            errors.append(message)
    if errors:
        return errors
    require(review.get('planSha256') == digest(root / 'plan.json'), 'plan hash stale or plan.json missing')
    require(review.get('synthetic') is False, 'synthetic or unspecified test footage cannot be formally released')
    require(text(review.get('reviewer')) and text(review.get('reviewedAt')), 'real reviewer and review time required')
    sources = {}
    canonical = set()
    for source in review.get('sources', []):
        sid = source.get('id')
        require(text(sid) and sid not in sources, 'unique source ID required')
        source_path = root / source.get('path', '')
        require(source_path.is_file(), 'source file missing: ' + str(sid))
        if not source_path.is_file():
            continue
        sha = digest(source_path)
        require(source.get('sha256') == sha, 'source hash stale: ' + str(sid))
        meta = prober(source_path)
        require(meta['fps'] > 0 and meta['duration'] > 0, 'source video metadata invalid')
        require(text(source.get('receipt')), 'source task ID or UI submission evidence required')
        bounds = []
        for actual in source.get('actualShots', []):
            require(text(actual.get('id')), 'actual shot ID required')
            a, b = actual.get('startFrame'), actual.get('endFrame')
            valid = type(a) is int and type(b) is int and 0 <= a < b and b / meta['fps'] <= meta['duration'] + 1 / meta['fps'] and (meta.get('frames') is None or b <= meta['frames'])
            require(valid, 'actual source shot bounds invalid')
            require(actual.get('reviewed') is True and text(actual.get('observation')), 'actual shot must be reviewed, not inferred from plan')
            key = (sha, a, b)
            require(key not in canonical, 'same actual shot duplicated under another source/ID')
            canonical.add(key)
            if valid:
                require(all(b <= x or a >= y for x, y in bounds), 'actual shots overlap')
                bounds.append((a, b))
        require(len({a.get('id') for a in source.get('actualShots', [])}) == len(source.get('actualShots', [])), 'actual shot IDs duplicated')
        sources[sid] = (source, meta, sha)
    clips = review.get('edit', [])
    require(len(clips) == len(p['shots']), 'one real clip for each planned shot required; update plan after recut')
    actual_keys, used_ranges, offset = set(), {}, 0
    for i, clip in enumerate(clips):
        if i >= len(p['shots']):
            break
        planned = p['shots'][i]
        require(clip.get('shotId') == planned['id'], 'actual edit order differs from reviewed plan')
        source = sources.get(clip.get('sourceId'))
        if not source:
            errors.append('unknown clip source'); continue
        record, meta, sha = source
        actual = next((a for a in record.get('actualShots', []) if a.get('id') == clip.get('actualShotId')), None)
        a, b = clip.get('inFrame'), clip.get('outFrame')
        valid = actual and type(a) is int and type(b) is int and a < b and type(actual.get('startFrame')) is int and type(actual.get('endFrame')) is int and actual['startFrame'] <= a < b <= actual['endFrame']
        require(valid, 'clip must lie in one reviewed actual shot')
        require(clip.get('speed') == 1 and clip.get('type') == 'video', 'no freezes, stills, loops or padding retimes')
        if valid:
            require(abs((b - a) / meta['fps'] - planned['durationSec']) <= 1 / p['fps'] + 1e-6, 'clip duration differs from timeline')
            ranges = used_ranges.setdefault(sha, [])
            require(all(b <= x or a >= y for x, y in ranges), 'source interval reused')
            ranges.append((a, b))
            actual_keys.add((sha, actual['startFrame'], actual['endFrame']))
        require(text(clip.get('productObservation')) and text(clip.get('actionObservation')), 'actual product and motion observations required')
        require(clip.get('productPass') is True and clip.get('motionPass') is True, 'product or motion review not passed')
        if p.get('cinematographyVersion') == 1:
            camera = clip.get('cinematographyReview', {})
            require(camera.get('pass') is True and all(text(camera.get(k)) for k in ('movementObservation', 'framingObservation', 'focusObservation')), 'actual cinematography review pending')
        offset += planned['durationSec']
    require(len(actual_keys) >= 5, 'fewer than five distinct actual camera shots')
    errors.extend(editorial_review_errors(p, review, len(actual_keys)))
    errors.extend(offering_review_errors(p, review))
    if p.get('cinematographyVersion') == 1:
        edited = {c.get('shotId') for c in clips}
        for key in ('whole', 'detail', 'use', 'benefit'):
            row = review.get('coverageReview', {}).get(key, {})
            ids = row.get('shotIds', [])
            allowed = p['coverage'][key]['shotIds']
            require(row.get('pass') is True and text(row.get('observation')) and isinstance(ids, list) and bool(ids) and all(isinstance(i, str) and i in edited and i in allowed for i in ids), 'actual ' + key + ' coverage pending')
    joins = review.get('joins', [])
    require(len(joins) == len(p['bridges']), 'every actual join needs review')
    for i, join in enumerate(joins):
        require(i < len(p['bridges']) and join.get('from') == p['bridges'][i]['from'] and join.get('to') == p['bridges'][i]['to'] and join.get('pass') is True and text(join.get('observation')), 'actual join unresolved or out of order')
    proofs = review.get('proofs', [])
    for benefit in (b for b in p['benefits'] if b.get('core') is True):
        rows = [x for x in proofs if x.get('benefitId') == benefit['id']]
        require(bool(rows), 'core benefit lacks actual proof')
        for row in rows:
            matching = next((s for s in p['shots'] if s['id'] == row.get('shotId')), None)
            require(matching is not None and benefit['id'] in matching.get('benefitIds', []), 'proof references unrelated shot')
            if matching:
                start = sum(s['durationSec'] for s in p['shots'][:p['shots'].index(matching)])
                a, b = row.get('startSec'), row.get('endSec')
                require(number(a) and number(b) and start <= a < b <= start + matching['durationSec'], 'proof time must lie in its actual final shot')
            require(row.get('pass') is True and text(row.get('observation')), 'visible proof unresolved')
    for axis in ('continuity', 'story', 'benefits'):
        score = review.get('scores', {}).get(axis, {})
        require(type(score.get('score')) is int and 4 <= score['score'] <= 5 and text(score.get('evidence')), axis + ' must independently pass at 4/5 with observations')
    require(review.get('fatalIssues') == [], 'fatal issues pending or unspecified')
    for key in ('silentWatch', 'fullWatch', 'listening', 'captions', 'musicRights'):
        entry = review.get('checks', {}).get(key, {})
        require(entry.get('pass') is True and text(entry.get('evidence')), key + ' pending or unsubstantiated')
    final = review.get('final', {})
    path = root / final.get('path', '')
    require(path.is_file(), 'final video missing')
    if path.is_file():
        require(final.get('sha256') == digest(path), 'final video hash stale')
        meta = prober(path)
        require(abs(meta['duration'] - p['durationSec']) <= 1 / p['fps'] + 1e-6, 'final duration differs from plan')
        require(abs(meta['fps'] - p['fps']) < 0.001 and meta['audio'], 'final fps or audio missing')
    return errors


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('mode', choices=['plan', 'release'])
    parser.add_argument('plan', type=Path)
    parser.add_argument('review', type=Path, nargs='?')
    parser.add_argument('--ffprobe', default=shutil.which('ffprobe'))
    args = parser.parse_args()
    try:
        p = json.loads(args.plan.read_text())
        if args.mode == 'plan':
            errors = plan_errors(p)
        else:
            if not args.review or not args.ffprobe:
                parser.error('release requires review.json and a working --ffprobe path')
            if args.plan.name != 'plan.json':
                parser.error('release plan must be named plan.json, as referenced by its hash')
            errors = release_errors(p, json.loads(args.review.read_text()), args.plan.parent, lambda path: probe(path, args.ffprobe))
        print(json.dumps({'ok': not errors, 'mode': args.mode, 'semanticReviewAutomated': False, 'errors': errors}, ensure_ascii=False, indent=2))
        return 1 if errors else 0
    except (OSError, ValueError, TypeError, KeyError, AttributeError, subprocess.SubprocessError, StopIteration) as exc:
        print(json.dumps({'ok': False, 'errors': ['Invalid record or media: ' + str(exc)]}, ensure_ascii=False))
        return 1


if __name__ == '__main__':
    sys.exit(main())
