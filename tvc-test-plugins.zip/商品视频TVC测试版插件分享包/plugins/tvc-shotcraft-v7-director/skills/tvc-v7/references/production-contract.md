# 计划与验收格式

先核对 [整套商品、颜色与场景展示](product-offering-and-display.md)：整套商品与代表单件分别验收，无人生活静物可在床面、托盘等相关场景展示。新任务offeringVersion:1，不能以单色穿着覆盖四色套装。


先执行 [产品适配、空间动作与一次生成](product-action-direction.md)。新任务directionVersion:1；露脸为偏好，空间与主体动作需先规划并按实际素材复核，不因裁脸自动重生成。


## 目录与工作记录

在新工程中保存 `plan.json`、`review.json`、`sources/`、`audio/`、`final/`。字幕SRT/VTT、旁白、BGM许可证、平台提交记录和选段表随工程保留。项目可用绝对文件路径，也可用相对于plan.json的路径。

[example-plan.json](example-plan.json)是木托盘的完整格式示例，不是已拍摄素材、商品模板或当前商品事实。换商品时重新分析，不复制其三杯结构。使用小数秒可以用于最终剪辑；提交给模型的时间线另按其粒度编译。

`plan.json`包含：

- version=7；fps；durationSec（20–30）；durationReason；durationCandidates（至少两个可行片长与理由）。
- product：name、invariants（原图可确认的结构锁定项）。
- story：task、trigger、outcome、productContribution。
- benefits：id、core、claim、basisType（observed/documented/user-supplied）、basis、visibleProof。未证实性能不得冒充observed，用户供稿也不等于已验证。
- shots：id、type=video、durationSec、role（setup/action/proof/result/close）、action、storyChange、startState、endState、framing、camera、location、subjectAnchor、screenDirection、benefitIds；关联利益时须有proofOnScreen。无人物时subjectAnchor只写商品/关键物件。
- bridges：按相邻镜头顺序一一对应的from、to、kind（action/state/space/eyeline/match/ellipsis）、anchor、reason。

## 生成记录（不由校验脚本推测）

每次请求保存平台、项目、模型版本、模式、分辨率、画幅、请求时长、提示词原文、参考文件角色和指纹、覆盖哪些计划镜头、授权范围/次数/预算。任务ID、提交/完成时间若平台不暴露，写null并附真实界面证据路径；不要编造。下载后记录源文件SHA256与ffprobe数据。

## review.json（审看片后填写）

不要预填通过。下列JSON展示字段，null和空数组表示未完成，所以不能通过release。

```json
{
  "planSha256": "实际plan.json文件的SHA256",
  "synthetic": false,
  "reviewer": null,
  "reviewedAt": null,
  "sources": [{
    "id": "source-1", "path": "sources/source-1.mp4",
    "sha256": "实际源文件SHA256", "receipt": "实际任务ID或真实界面提交证据路径",
    "actualShots": [{"id": "actual-1", "startFrame": 0, "endFrame": 96,
      "reviewed": false, "observation": null}]
  }],
  "edit": [{"shotId": "S1", "sourceId": "source-1", "actualShotId": "actual-1",
    "type": "video", "inFrame": 0, "outFrame": 96, "speed": 1,
    "productPass": false, "productObservation": null,
    "motionPass": false, "actionObservation": null}],
  "joins": [{"from": "S1", "to": "S2", "pass": false, "observation": null}],
  "proofs": [{"benefitId": "carry", "shotId": "S3", "startSec": 8, "endSec": 12,
    "pass": false, "observation": null}],
  "scores": {
    "continuity": {"score": null, "evidence": null},
    "story": {"score": null, "evidence": null},
    "benefits": {"score": null, "evidence": null}
  },
  "fatalIssues": null,
  "checks": {
    "silentWatch": {"pass": false, "evidence": null},
    "fullWatch": {"pass": false, "evidence": null},
    "listening": {"pass": false, "evidence": null},
    "captions": {"pass": false, "evidence": null},
    "musicRights": {"pass": false, "evidence": null}
  },
  "final": {"path": "final/tvc7.mp4", "sha256": "实际成片SHA256"}
}
```

帧边界用源视频帧率，区间为[startFrame,endFrame)，结束帧不含；实际镜头表不能重叠。同一源文件同一真实镜头，不因改sourceId/actualShotId或重新裁切而算成不同镜头。一次源镜中间有明显剪切，应先修正actualShots边界。最终时间单位为秒，proof时段必须落在关联成片镜头内。声画必须以最终文件审看；重新剪辑、更换声轨或字幕后更新实际审片，重新计算文件哈希。

`release`会读取实际本地文件并调用ffprobe，检查时间、帧率和音轨。机器能发现记录矛盾、旧指纹、重复选段和未完成审片，无法识别伪造的人工观察，更不能凭评分证明画面好看。不能生成审片结论来让脚本变绿。精确语义、切点真实性与实际音质仍由审片负责。

本版默认保留原速并以非重复片段组成全片，避免变速补时；如用户明确需要风格化慢动作，需据实际动作重新定义时长规则并保留真实原镜计数，不能用改speed绕过门槛。

## 摄影升级字段（新任务必填，历史记录兼容）

`cinematographyVersion: 1`；`productDirection` 包含 category、openingMode、openingReason、alternative、referenceLimits。openingMode 为 studio-to-use/still-life-to-use/use-first/use-only；studio-to-use 先 studio 后 use，use-first/use-only 从 use 开场，use-only 不能含 studio。

`coverage` 包含 whole/detail/use/benefit 四项，每项 `{shotIds: [有效镜头ID], visibleContent: "具体可见内容"}`。use 的关联镜头必须含 use 场景，benefit 必须关联有 benefitIds 的镜头。四项均不可空。

每镜 `cinematography` 包含 scene、lensMm、lensReason、cameraPosition、framingStart、framingEnd、visualPurpose；`movement` 包含 type/path/extent/pace/reason；`focus` 包含 target/behavior/depthOfField。lensMm 为正数全画幅等效意图。全片运动类型一致时 productDirection.repetitionReason 必填；全固定时 staticException 必填。详见 cinematography.md。

release 每个 edit.cinematographyReview 包含 pass=true 和 movementObservation/framingObservation/focusObservation。coverageReview 四项均含 pass=true、shotIds、observation，镜头同时属于计划相应覆盖与实际 edit。真实观看判断，未看则 pending。

## 可用视角来源表

按 product-views.md 附 referenceViews 来源表，记录每个原图/白底参考的文件哈希、实际视角、未知面与人工审看结果。单正面仅一个视角。现有验证器不自动审验该表的真实性；逐镜 productObservation/productPass 仍须基于原图与实际连续视频。

## 产品主导人物与节奏字段（新任务）

新任务`editorialVersion:1`，历史合同不自动迁移。先读[产品主导的人物与节奏](product-presence-and-rhythm.md)。

- `castingDecision`：mode=product-only/hands-only/face-supported；reason、faceValue、removalEffect、productReadabilityRisk为具体分析。characterStrategy=none/single/multiple；cast=[{id,appearance,wardrobe,narrativeJob}]；faceShotIds必须精确对应实际计划露脸镜，不露脸为[]。单/多人物是任务选择，不要求全片同一人。
- 每镜`presence`=product-only/hands-only/face-visible；castIds只列该镜真实参与的人物，纯产品镜为[]。有人时`humanBeat`={sceneKey,viewKey,actionKey,stateKey,narrativeGain}。重复露脸镜对比同人物、场景、机位、动作；仅空托变满托不能掩盖重复看产品/微笑。手部连续装载可用真实stateKey表达状态推进。
- `rhythmPlan`：targetShotCount等于最终计划真实镜头数；selectionReason；alternative={shotCount,reason}，镜头数须与所选不同。少于ceil(durationSec/3)时，densityException={reason,actionShotIds}绑定必须完整保留的真实动作；至少五镜仍是底线。
- 每镜`pacing`：beatType=setup/detail/action/result，newInformation、entryCue、exitCue、cutReason、minimumReadableSec。非动作镜>2.5秒、动作镜>3.5秒，需longTakeReason说明持续信息/完整动作；不能靠“高级感”或等配音解释空等。

正式review每个edit增加：

```json
{
  "presenceReview": {
    "pass": false,
    "observedPresence": "hands-only",
    "observedCastIds": ["server"],
    "observation": "实际区间中的人物/手部与任务",
    "productReadabilityObservation": "实际商品占比、接触与画面协调性",
    "comparedShotIds": [],
    "recurrenceObservation": "再次出现时，相比此前同类人物镜的新人物/场景/角度/动作及叙事信息"
  },
  "pacingReview": {
    "pass": false,
    "informationObservation": "新信息实际出现在哪个动作或结构",
    "holdObservation": "动作/信息结束后是否空等",
    "cutObservation": "实际切点及完整接触是否保留"
  }
}
```

comparedShotIds列出此前所有同类人物镜（face-visible或hands-only），包括非相邻开场/收尾；首个人物镜为[]。纯产品镜无需人物复现比较。观察由sourceId/actualShotId/inFrame/outFrame定位，不能复制计划当实审。

整体`rhythmReview`={pass,densityObservation,deadTimeObservation,recurrenceObservation}。实际独立源镜数至少达到最终targetShotCount，同一源镜切成两段仍算一个。少出镜头时保留提交快照、重排最终计划与真实缺口，不通过更改actualShotId冒充密度。字段与数字检查不替代观看、人物合理性或审美判断。

## 品牌表达

执行[品牌TVC创意与声画标准](brand-tvc.md)。新任务记录brandDirection并落实到提示词、字幕与声画工程；终审根据最终成片的具体时段记录内容聚焦、影像统一、字幕版式及声音弧线的实际观察，未实际看听不得填通过。

生活场景无人静物用scene=contextual-still-life；still-life-to-use从此类场景开始后进入use。use-first可在后段加入生活静物；use-only不含棚拍或生活静物。不要为保留旧标签把床面套装静物谎称穿着使用。
