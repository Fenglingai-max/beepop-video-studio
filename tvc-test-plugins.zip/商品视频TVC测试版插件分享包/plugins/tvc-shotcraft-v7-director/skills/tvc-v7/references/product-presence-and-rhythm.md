# 产品主导的人物、变化与节奏

先核对 [整套商品、颜色与场景展示](product-offering-and-display.md)：整套商品与代表单件分别验收，无人生活静物可在床面、托盘等相关场景展示。新任务offeringVersion:1，不能以单色穿着覆盖四色套装。


先执行 [产品适配、空间动作与一次生成](product-action-direction.md)。新任务directionVersion:1；露脸为偏好，空间与主体动作需先规划并按实际素材复核，不因裁脸自动重生成。


## 先决定面部是否有用

常规人物参与商品片，先评估具体产品、机制与故事，再选择自然露脸或局部构图；露脸仅是偏好，裁脸不单独拒收。开头产品全貌、棚拍、参考支持的环绕镜可以无人；细节和关键接触镜可只出现产品或手部。不要求每镜露脸，也不先把全片导向无人。

先判断每类镜头的职责：

- **产品开场**：可无人，集中读清完整外形、体积和关键结构。环绕仅限真实参考支持的可见面，不能虚构背面/底部或默认360度；单视角不足时改安全平移/有限推拉。
- **使用与人物事件**：按产品需要选择中景露脸或身体局部构图，面部、手部与产品共同交代使用者、目标、交流和反应。自然布置产品于可读前景，不能为框入头部把小产品拉得看不清。
- **细节和操作证据**：以产品/手部近景保证结构和真实接触；完成后可回到有新动作或接收关系的人物镜，而不是再来同角度微笑。
- **产品例外**：核心证据完全由机制/手部讲清、露脸明显损害可读性，或用户明确无人时，可采用hands-only/product-only，并写当前产品的具体理由。面部佩戴、美妆或社会交流则保留必要面部。


计划记录castingDecision：mode、reason、faceValue、removalEffect、productReadabilityRisk、characterStrategy、cast、faceShotIds。对不露脸方案说明面部非必要，不用空泛的“更有生活感”替代分析。每镜presence和castIds明确；将这些决定带入实际提示词，实际与计划露脸偏好不同时如实记录并复核身份、产品可读性和叙事，不单因露脸差异重生成。

## 允许多人物、多场景，但每次出现都推进

按任务选择none/single/multiple角色策略。多人物可以分别承担准备、使用、接收、对比不同使用环境等作用；不是随机换演员让片子看起来不同。每个castId有外观/衣着与narrativeJob，跨镜只对同一个castId要求身份一致；人物变化用清楚的物件状态、传递方向、视线或时间/地点省略连接。

每个人物镜写humanBeat：sceneKey、viewKey、actionKey、stateKey、narrativeGain。face-visible镜应比对所有此前露脸镜，尤其开场与结尾。相同人物+场景+机位+同类看产品/微笑动作的重复，不能只靠空托变满托就判为人物镜的新信息；改成有作用的新人物/场景，或新的机位/动作，或删掉该人物镜。不同人物但同样空泛的微笑摆拍也需删除。

hands-only可以在同机位连续完成不同物件/状态的操作；stateKey区分真实的装载推进，narrativeGain解释为何值得另切。不能把同一次动作裁成两段、改角色/机位标签当新镜。实际验收要观察变化，字段名本身不能证明变化。

## 节奏来自信息与动作，不来自凑数

五镜是绝对最低底线。常规紧凑商品片先评估20秒8–10镜、25秒10–12镜、30秒12–14镜，比较较疏或更密方案再选择。超过或低于范围都可有依据，不将镜头数替代故事或强行扩充生成次数。

常见建立/细节/结果镜约0.8–2.5秒。动作镜给实际接触足够时间，通常约2–3.5秒；完整装配、端取等确需更长时写longTakeReason，说明持续可见的变化和保护的动作。非动作镜超过2.5秒同样须解释可读信息，不以“高级感、慢一点、等旁白”作理由。镜头完成信息任务后切走，避免表情、手悬停或相同结果长时间空等。

逐镜pacing包含beatType、newInformation、entryCue、exitCue、cutReason、minimumReadableSec；超过建议停留写longTakeReason。新景别应揭示结构、接触或结果，不能把静帧推拉、2%微缩放或相同镜头数码裁切算更多分镜。片长和旁白应跟随有效动作，不加快配音或视频来掩盖冗长。

## 计划与实际分别检查

新工程editorialVersion=1。rhythmPlan记录targetShotCount、selectionReason，以及alternative的shotCount/reason。默认少于ceil(片长/3)个真实镜头需densityException，绑定必须完整保留的actionShotIds及理由；例外不降低至少五个真实镜头、20秒纯视频、产品一致性和三项终审。

提交前按平台时长上限把真实镜头和连续动作簇分配到请求，预算按用户授权执行，不能为了增加镜头静默增加付费任务。实际少出镜头时重排/重剪并保留原提交计划；若需要更新最终plan.json，另存plan-submitted.json，不能把修改后的计划冒充原请求。

正式验收每个实际选段写presenceReview与pacingReview，绑定原有sourceId/actualShotId/inFrame/outFrame：实际人物、身份、产品占比、前后人物镜变化、何时出现新信息、是否空等和切点依据。rhythmReview分别记录densityObservation、deadTimeObservation、recurrenceObservation。实际独立源镜数必须达到最终rhythmPlan.targetShotCount；同一源镜被拆多段仍只算一个。无法达到时如实回到剪辑与素材缺口，不用字段造通过。

历史工程未声明editorialVersion时保持原合同可读。新任务不得移除标记绕过人物、节奏与实际密度检查。
