# 7.0研究记录与设计取舍

调研日期：2026-11-11。只读研究，未执行第三方Skill命令、未导入其权限或提交生成任务。以下为原文阅读后的简要转述；未复制第三方Skill实现。本插件条款是按用户要求设计，不是各平台共同保证。

## 平台与模型

| 一手来源 | 核实内容 | 7.0如何使用 | 边界 |
|---|---|---|---|
| [LibTV Skill目录](https://www.liblib.tv/skill) | 存在商业广告等分类 | 了解平台导演入口 | 页面未公开所有Skill内部说明，不声称已审计其内部实现 |
| [libtv-labs公开Skill](https://github.com/libtv-labs/libtv-skills/blob/main/skills/libtv-skill/SKILL.md) | 会话、上传、自然语言创作/编辑、进度查询；需访问密钥 | 将执行层与创意/审片层分开 | 仓库所列模型不作为当前画布完整清单；未接入或测试该API |
| [BytePlus Seedance2.5指南](https://docs.byteplus.com/en/docs/modelark/seedance-2-5-prompt-guide) | 参考按顺序与用途映射；摘要、镜头/时间线、持续一致性；整数秒需合理分配，过载会漏内容 | 全局锚定+逐镜动作+首尾状态，按任务编译 | 页面正文部分依赖JS，结合该官方域索引读取；并非亲测每项能力；不保证精确切点 |
| [BytePlus生成API](https://docs.byteplus.com/en/docs/modelark/create-video-generation-task-api) | 模型/角色/时长等字段需按实际模式核对 | 记录实际请求，区分首帧/末帧/普通参考 | 原厂API与LibTV字段不等同，费用和上限须执行时再查 |
| [Kling3.0多镜指南](https://kling.ai/blog/kling-video-3-multi-shot-guide) | 自动与自定义多镜、分镜参数、参考主体及有意义的镜头推进 | 优先结构化多镜覆盖同一场景事件 | 3.0能力不外推到其他版本，不把宣传的遵循度当实测 |
| [Kling4.0指南](https://kling.ai/quickstart/kling-4-model-user-guide) | 区分人物、动作、运镜、构图、故事板参考；故事板不应作为格线画面输出 | 参考资产明确分工，防止导演注释进入画面 | 不用其中的文字生成能力代替后期字幕 |
| [Runway图生视频指南](https://help.runwayml.com/hc/en-us/articles/48324313115155-Image-to-Video-Prompting-Guide) | 提示词主要描述主体/环境/相机运动、方向与速度，图像提供视觉锚点 | 编译简洁动作提示，避免外观重复和抽象修饰 | 当前指南优化于Gen-4.5；不能泛称所有模型多镜能力相同 |
| [Runway Gen-4指南](https://help.runwayml.com/hc/en-us/articles/39789879462419-Gen-4-Video-Prompting-Guide) | 简洁、正向动作描述，输入图质量重要 | 平台专属约束，避免万能负面词表 | 不把Gen-4规则作为Seedance2.5规则 |
| [Vidu官方说明](https://platform.vidu.com/docs/overview/introduction) | 参考生视频与首尾帧生视频是不同能力入口 | 分清主体锚定与时序锚定 | 只确认能力类别，未实测其商品交互效果 |

## 实际公开Skill比较

| 实际阅读来源 | 值得吸收的设计 | 不直接沿用 |
|---|---|---|
| [Ethanxwang/tvc-director](https://github.com/Ethanxwang/tvc-director/blob/main/SKILL.md)（仓库标MIT） | 从brief、创意到资产定调、分镜、视频脚本的导演阶段；生活方式与产品世界分开设计，匹配剪辑让世界切换有关系 | 默认悬浮拆解、过密多阶段运镜、多宫格一律作为输入，均非本次商品视频必需；它偏创意/提示词，不替代真实成片核验 |
| [Scenario video ads](https://github.com/scenario-labs/skills/blob/main/skills/scenario-video-ads/SKILL.md)（Skill标MIT） | 导演层调用机械能力；原图锚定产品，抽帧比对，预算与音频/组装分工清晰 | Scenario特定依赖、每次固定审批节点、图卡和文字层样式不搬进7.0；用户既有授权继续有效 |
| [SamurAIGPT Product Video Ads](https://github.com/SamurAIGPT/open-ai-video-agent/blob/main/agents/product-video-ads/SKILL.md) | 商品结构锁定与创意分开，批准主张关联具体beat，模型schema和输出记录可追溯 | draft-only定位与MUAPI连接不是7.0自动拥有的能力；未核实许可，不复用源码 |
| [Seedance prompt generator](https://github.com/maciejdzierzek/seedance-prompt-generator/blob/main/skills/seedance/SKILL.md) | 按版本区分参考、时间线与音频规则，提示词结构化 | 参数价格表易过期，回查原厂；未核实许可，不复用源码；提示词正确也不是成片合格 |

## 用户参考视频的本地观察

参考素材：12074365（木制杯托）、15884662（裁判卡）、17954920（花艺托盘）、18663404（麦克风腰带），来自用户提供AI视频案例。已观察抽帧与具体画面，未把抽帧观察说成音频听审。

可取的共同点：商品在实际事件中出现，细节镜头承接使用动作，场景切换增加用途，结尾展示完成状态。并非所有片都同一个人或地点，因此7.0不强制同人同屋。参考片的产品功效不转移给当前产品，也不直接复用其视频。

## 本插件的编辑判断

“至少五镜”和“20–30秒”来自用户，不是模型最佳参数。首尾状态/接缝表、静音故事审查、逐条利益证据表、三项分别4/5及致命项退回，是本插件为避免PPT感而设计的质量门槛。它们可暴露缺口，不能保证一次生成成功；真正质量仍需看实际连续视频并听成片。多镜一体与分批生成按产品交互及平台能力选择，不预设哪一种必胜。
