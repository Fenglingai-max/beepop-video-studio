# 先理解销售单位，再安排展示

## 整套商品与代表单件分别分析

先依据当前资料区分single（一个商品）、bundle（一次购买包含的套装）、choice-variants（购买时选一款的可选变体）。不能把套装四色理解成四选一，也不能把可选四色暗示为全部附赠。原图与文字冲突时记录差异，保留已知外观，不发明颜色或包装。

identityGroups登记与购买判断有关的关键颜色、款型、配件或用途分组，逐组写来源basis和数量unitCount/unit。分组按实际购买理由，不要求大工具套装每颗螺丝各占一镜；不能故意漏登记关键组来绕过覆盖。机器只检查登记的一致性，原始资料是否完整理解仍须人工复核。

本袜子是**四色四双、共八只**：蓝、黑、粉、黄各一双；原图黄色偏橙，应保留原图色相。四个身份组各unitCount=1、unit=pair。一双蓝袜的穿着仅演示其中一双，不能代替整套颜色和轮换价值。无需同一个人依次穿遍四色，也不允许连续动作里突然变色。

## 无人也可以是生活场景

比较生活静物、干净棚拍、实际使用三种展示方式的具体价值，再决定组合与开场，不强制三种都拍。不预设“服饰必须穿着开场”“无人就是白底转台”或“没有穿搭就没有内容”。

袜子可以成双摆在亚麻床面、换衣长凳、合适尺寸的浅托盘或敞开收纳区，四组分明、完整轮廓和数量可读。用相关前中后景、侧光、真实横移和不同摄影景别展示套装、织物与日常轮换。是否用盘子要符合产品和生活情境，避免食物/餐盘等无关联想；床、托盘、收纳物是置景道具，不能暗示附赠。

静物主体可以静止，视频仍须真实生成的摄影画面与信息变化，不能用图片数码推拉、冻结或重复片段冒充新镜头。静物能表达成套、选色、收纳，不自动证明穿着舒适或抓地性能。有穿着时，可由选取一双、准备动作或明确省略连接，其余颜色仍有整套展示职责；不为追求运动删掉套装证据。

四色轮换是主购买理由时，可以床面或托盘整套开场再接单双活动；使用吸引力更强时，可先使用再交代套装。没有穿搭素材也可以规划有生活语境的整套/细节镜，不强制加模特。不是把今后的袜子固定成托盘脚本，更不是所有品类都摆盘子。

## 新计划字段

新任务offeringVersion:1；历史已提交合同不回写。productOffering：

- saleUnit=single/bundle/choice-variants；saleUnitReason。
- identityGroups=[{id,label,basis,unitCount,unit}]；requiredGroupIds。bundle须覆盖所有已登记关键组；choice-variants可以选代表组，但须variantSelectionReason并明确其他颜色并非附赠。
- wholeOfferingApproach：如何让观众理解销售单位和整套关系。
- stillLifeRole：生活静物的任务；不用时写具体产品理由。
- representativeUseRole：哪件承担使用、为何足够、不能替代哪些整套证据；无穿着时如实说明，不强加模特。

新增offeringCoverage.whole={shotIds,approach,visibleContent,reason}。approach=together/sequence；优先清楚同框，数量/尺度不宜同框时可按有明确关系的序列展示并解释。新增offeringCoverage.groups=[{groupId,shotIds,visibleContent}]，逐组覆盖requiredGroupIds，shotIds归入whole.shotIds。

本例whole可为S1“四色各一双、四组八只完整摆于亚麻床面”；groups分别绑定blue/black/pink/yellow至S1，描述每组两只轮廓可辨。coverage.whole检查单体完整轮廓，offeringCoverage.whole另检查销售单位，两者不能替代；不能以单色穿着图加“四色”字幕算整套覆盖。

生活静物scene=contextual-still-life；开头静物再进入实际任务用openingMode=still-life-to-use。use-first可以后段插生活静物；use-only不含棚拍或生活静物。use可指真实穿着活动、选择轮换或收纳操作，但须如实命名；仅摆放的静物不能伪称已演示穿着/抓地。

## 实际验收

review.offeringReview.whole和groups对应计划，每项记录pass、shotIds、observation；另写representativeUseObservation。逐组对照源图核对真实色相、数量、轮廓、可读性与道具关系，观察绑定所选真实片段，不能照抄提示词。

六只不能记作八只；只拍蓝色不能因为旁白提四色而通过整套验收。若唯一一次生成缺色/少件，先查本次其他可用区间并重剪，仍不足则标明缺口；不编造颜色、拿旧片/静帧补成正式片或自动重生成。继续遵守用户次数预算、露脸偏好与空间动作规则；静物加入不等于把使用段重新锁回小空间。
