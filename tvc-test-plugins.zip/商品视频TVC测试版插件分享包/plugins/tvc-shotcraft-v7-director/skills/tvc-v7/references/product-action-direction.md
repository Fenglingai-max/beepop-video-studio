# 产品适配、空间动作与一次生成的取舍

新任务必须声明directionVersion:1，保留cinematographyVersion:1与editorialVersion:1；历史已提交合同不回写。此文件优先于其他参考中“多数露脸”或固定人物构图的建议。

先分析销售单位、购买理由与真实使用，再选开场。先执行 [整套商品、颜色与场景展示](product-offering-and-display.md)。比较生活场景静物、无人棚拍与穿着使用的价值，写入productDirection.openingReason/alternative；不预设袜子必须从穿着迈步开场。四色四双套装须让观众看懂四种颜色与成套关系，一双穿着仅证明该双的用法；床面、托盘、衣物收纳等无人生活场景可承担整套展示，再按需要连接使用。实际数量不符仍剔除该区间，不能用“已经穿上”替代套装证据。其他品类同样先判断销售单位，不套用袜子脚本。

露脸是偏好。尽量在有用、自然且产品可读的构图中露脸；裁脸、背影、腿脚或局部佩戴都可合格。不要因没露出脸单独拒收、补拍或重抽。只有用户明确要求，或面部本身承载佩戴效果/表情交流等不可替代证据时才设必需露脸镜。facePolicy={mode:"preferred",reason:当前产品理由,requiredShotIds:[]}；有必需镜时另填requirementBasis。castingDecision.faceShotIds表示计划偏好，不代表每镜硬性验收。实际presenceReview如实记observedPresence，局部身体可用person-cropped；与计划不同须写faceVariationObservation解释为何产品、身份与任务仍清楚，不能把裁脸标成露脸。身份、形态、真实动作、接触和卖点证据仍按原规则检查。

## 生成前先设计可看的空间与动作

spatialActionPlan必须包含strategy（route/task-stations/stationary）、productSuitability、route、actionProgression、environmentLayers、promptIntegration。具体说明主体从哪里到哪里、完成哪些不同阶段、动作幅度为何适合产品，以及前中后景如何交代环境；将路线、动作起止、方向和承接写进各实际生成提示词。不能只在分析中写“大空间、电影感”而提示词仍是坐在同一小垫子旁反复摸产品。

例如防滑袜可从穿好站起，到走向活动区，再完成有真实落脚的适度活动，最后落地停稳；远/中景交代路线，近景提供接触证据。按年龄与商品资料选择安全动作，不能臆造防摔保证或强行高难跳跃。换角度、微推、两步原地挪动不能自动算空间展开。场景切换必须有任务作用和连接，不能随机换房间。桌面工具、装配等原地任务可以stationary，但必须写stationaryReason，并用实质操作阶段和环境层次推进；不规定统一距离、场景数量或人人都奔跑。

实际验收另填spatialActionReview：pass、observedRoute、observedActionProgression、environmentObservation、selectionReason，绑定现有真实选段观察；字段不等于视觉质量证明。若素材确实狭窄单调，如实说明缺口，不夸称已经实现大范围运动，也不因此自动花费重生成。

## 一次生成，优先利用

默认先规划在平台实际时长上限内的一次生成；只有任务确需且用户现有授权涵盖时才拆分连续动作簇。先在提示词中解决路线、动作幅度、产品可见性和切镜职责。模型、分辨率按当前用户选择，禁止静默升级。

生成后先盘点所有可用连续区间，优先剪取、重排和压缩，保留正确产品与完整接触。露脸缺失、美感偏好、计划镜头未逐字命中不能单独成为再次生成理由。产品变形、错误数量/肢体或虚假接触等实质问题仍应剔除对应区间，不能为了“一次成功”降低事实门槛。没有足够素材满足片长/故事时交付明确标注的预览和缺口；不循环、拉伸、借旧片冒充本次生成，也不自动抽卡。任何新增付费任务须有用户授权。
