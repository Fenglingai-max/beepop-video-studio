// Real, locally encoded tiny PNG fixtures; no generated product/QA claims.
const zlib=require('zlib'),fs=require('fs'),path=require('path');
const crc=b=>{let c=0xffffffff;for(const v of b){c^=v;for(let j=0;j<8;j++)c=(c>>>1)^((c&1)?0xedb88320:0);}return(c^0xffffffff)>>>0};
function png(w=16,h=16,pixel=(x,y)=>[40,130,220,x>3&&x<12&&y>3&&y<12?255:0],filter=0){
 const chunk=(kind,data)=>{const k=Buffer.from(kind),head=Buffer.alloc(4),tail=Buffer.alloc(4);head.writeUInt32BE(data.length);tail.writeUInt32BE(crc(Buffer.concat([k,data])));return Buffer.concat([head,k,data,tail]);};
 const ih=Buffer.alloc(13);ih.writeUInt32BE(w);ih.writeUInt32BE(h,4);ih[8]=8;ih[9]=6;
 const rows=[];let prev=Buffer.alloc(w*4);
 const paeth=(a,b,c)=>{const p=a+b-c,pa=Math.abs(p-a),pb=Math.abs(p-b),pc=Math.abs(p-c);return pa<=pb&&pa<=pc?a:pb<=pc?b:c;};
 for(let y=0;y<h;y++){const row=Buffer.from(Array.from({length:w},(_,x)=>pixel(x,y)).flat()),encoded=Buffer.alloc(w*4+1);encoded[0]=filter;for(let i=0;i<row.length;i++){const a=i>=4?row[i-4]:0,b=prev[i],c=i>=4?prev[i-4]:0;encoded[i+1]=(row[i]-(filter===0?0:filter===1?a:filter===2?b:filter===3?Math.floor((a+b)/2):paeth(a,b,c)))&255;}rows.push(encoded);prev=row;}
 return Buffer.concat([Buffer.from([137,80,78,71,13,10,26,10]),chunk('IHDR',ih),chunk('IDAT',zlib.deflateSync(Buffer.concat(rows))),chunk('IEND',Buffer.alloc(0))]);
}
function install(root,b,hash){
 const put=(rel,bytes)=>{const p=path.join(root,rel);fs.mkdirSync(path.dirname(p),{recursive:true});fs.writeFileSync(p,bytes);return p},ev=(file)=>({file,sha256:hash(path.join(root,file))});
 put('public/hero.png',png());
 const composites=[['light','#ffffff'],['dark','#202020'],['film',b.design.background]].map(([background,color])=>{const rgb=[1,3,5].map(i=>parseInt(color.slice(i,i+2),16)),file='evidence/cutout-'+background+'.png';put(file,png(16,16,(x,y)=>x>3&&x<12&&y>3&&y<12?[40,130,220,255]:[...rgb,255]));return{background,color,...ev(file)};});
 const source={asset:'hero.png',sha256:hash(path.join(root,'public/hero.png'))};
 const r={reviewed:true,status:'passed',fixtureOnly:true,backgroundPolicy:'cutout-required',source,output:source,tool:'Synthetic fixture encoder, not actual product extraction',method:'original-alpha',observations:'Synthetic alpha contract fixture only; no semantic QA',alphaCheck:{outputSha256:source.sha256},maxCheckScale:1000,composites,maxScaleEvidence:ev('evidence/cutout-light.png')};
 put('evidence/cutout-review.json',JSON.stringify(r));return r;
}
module.exports={png,install};
