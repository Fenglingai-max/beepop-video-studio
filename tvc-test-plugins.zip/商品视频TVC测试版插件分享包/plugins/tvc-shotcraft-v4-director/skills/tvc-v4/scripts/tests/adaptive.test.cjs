const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('fs'),path=require('path');
const core=require('../../assets/tvc-template/scripts/adaptive-core.cjs'),media=require('../../assets/tvc-template/scripts/media.cjs'),{brief,cases,technicalFixture}=require('./fixtures-adaptive.cjs');
const clone=x=>JSON.parse(JSON.stringify(x));
for(const key of Object.keys(cases))test(key+': realistic product-specific plan covers10s video and15–20s native Remotion',()=>{
 const b=brief(key);assert.equal(core.plan(b),true);assert.ok(b.scriptPlan.shots.length>=5&&b.scriptPlan.shots.length<=8);
 const video=b.timeline.filter(x=>x.type==='video').reduce((s,x)=>s+x.end-x.start,0),motion=b.durationSec-video;
 assert.equal(video,10);assert.ok(motion>=15&&motion<=20);assert.equal(b.timeline[0].start,0);assert.equal(b.timeline.at(-1).end,b.durationSec);
 assert.equal(new Set(b.timeline.filter(x=>x.type==='video').map(x=>x.clipId)).size,b.scriptPlan.shots.length);
 assert.ok(b.timeline.filter((x,i)=>x.type==='video'&&b.timeline[i-1]?.type!=='video').length>=2);
 assert.match(core.prompt(b),new RegExp('恰好'+b.scriptPlan.shots.length+'个'));assert.match(core.prompt(b),/人脸与商品接触关系/);
});
test('three categories choose meaningfully different orders and motion families',()=>{
 const bs=Object.keys(cases).map(brief),orders=bs.map(b=>b.timeline.map(x=>x.type).join(','));assert.equal(new Set(orders).size,3);
 assert.ok(bs.every(b=>new Set(b.timeline.filter(x=>x.type!=='video').map(x=>x.effect)).size>=3));
 assert.ok(bs[1].timeline.some(x=>x.effect==='spec-grid'));assert.ok(bs[2].timeline.some(x=>x.effect==='kinetic-type'));
 assert.notEqual(bs[0].productAnalysis.primaryJob,bs[1].productAnalysis.primaryJob);
});
const reject=(title,mutate,re)=>test(title,()=>{const b=brief();mutate(b);assert.throws(()=>core.plan(b),re);});
reject('15s video budget cannot silently pass10s profile',b=>b.videoDurationSec=15,/10s video/);
reject('24s total does not meet requested25–30s duration',b=>b.durationSec=24,/25–30/);
reject('nine planned shots cannot lower5–8shot guard',b=>{b.scriptPlan.shots.push(...clone(b.scriptPlan.shots.slice(0,3)).map((s,i)=>({...s,shotId:'extra-'+i})));},/5–8/);
reject('one continuous source move cannot be declared a cut',b=>b.scriptPlan.shots[2].transition='continuous',/actual cuts/);
reject('human use requires at leastone fullsecond of face/product relationship',b=>b.scriptPlan.shots[1].facePlan.minVisibleSec=.5,/face AND product/);
reject('human role cannot be hidden as a people-free use shot',b=>b.scriptPlan.shots[1].peoplePresent=false,/cast\/use/);
reject('each benefit is tied to known source IDs',b=>b.features[0].sourceIds=['invented-spec'],/sourceIds/);
reject('timeline cannot reference a nonexistent video clip',b=>b.timeline[0].clipId='not-a-source',/video clip/);
reject('same clip cannot be replayed to inflate video time',b=>b.timeline.find(x=>x.clipId==='clip-2').clipId='clip-1',/used once/);
reject('gapped timeline is rejected',b=>b.timeline[1].start+=.5,/contiguous/);
reject('half-frame boundary cannot pass',b=>{b.timeline[1].end+=1/48;b.timeline[2].start+=1/48;},/frame-aligned/);
reject('shortened actual video interval cannot borrow declared10s budget',b=>b.story.segments[0].sourceEnd-=.25,/original-speed/);
reject('digital cropping cannot manufacture a new actual shot',b=>b.story.segments[0].crop={x:0,y:0,w:.5,h:1},/synthetic crop/);
reject('unknown Remotion effect is not accepted as implemented',b=>b.timeline[1].effect='magic-hologram',/implemented/);
reject('repeated zoom pulses are rejected rather than called silky motion',b=>{const x=b.timeline.find(x=>x.effect==='detail-glide');x.cameraPath.splice(1,0,{time:(x.start+x.end)/2,x:0,y:0,size:2000});},/repeatedly zoom/);
reject('feature omitted from every motion block is not silently discarded',b=>{for(const x of b.timeline)if(x.featureIds)x.featureIds=x.featureIds.filter(id=>id!==b.features[2].id);},/every sourced benefit/);
reject('unsupported competitor comparison cannot pass same-product evidence',b=>b.comparisons[0].mode='competitor-better',/invented competitor/);
reject('comparison with no factual basis is rejected',b=>b.comparisons[0].basis='',/basis/);
reject('comparison source reference must actually exist',b=>b.comparisons[0].sourceIds=['not-supplied'],/unsupported metric/);
reject('comparison omitted needs an explicit product-specific decision',b=>{b.comparisons=[];const x=b.timeline.find(x=>x.type==='comparison');x.type='feature';x.effect='benefit-stack';delete x.comparisonId;b.productAnalysis.comparisonDecision='';b.editorialPlan.candidates[0].order=b.timeline.map(x=>x.type);},/meaningful comparison/);
reject('director candidates must actually have different orders',b=>b.editorialPlan.candidates[1].order=clone(b.editorialPlan.candidates[0].order),/orders must actually differ/);
reject('interleaved mode cannot secretly be one opening10s video block',b=>{
 const ordered=[...b.timeline.filter(x=>x.type==='video'),...b.timeline.filter(x=>x.type!=='video')];let t=0;for(const x of ordered){const len=x.end-x.start,delta=t-x.start;x.start=t;x.end=t+len;if(x.cameraPath)x.cameraPath=x.cameraPath.map(k=>({...k,time:k.time+delta}));t+=len;}b.timeline=ordered;b.editorialPlan.candidates[0].order=b.timeline.map(x=>x.type);
},/at least2 actual video groups/);
reject('closing complete product needs a readable hold',b=>b.timeline.at(-1).fullProductVisible=false,/complete product/);
reject('unrequested product viewport cannot reintroduce a frame',b=>b.remotionPlan.productViewport={x:100,y:100,w:900,h:600},/fixed product window/);
reject('subtitle text must be vertically centered as well as horizontally',b=>b.captionStyle.verticalAlign='bottom',/vertically centered/);
reject('narration cannot be accelerated to disguise a long script',b=>b.voice.speed=1.2,/speed1/);
reject('music choice must have rights and a declared source',b=>b.music.rights='',/rights/);
reject('music beat anchors cannot lie outside video duration',b=>b.music.beatTimes=[-1],/beat grid/);
reject('adaptive version still enforces primary asset roles',b=>delete b.assetPlan,/assetPlan|source roles|primary/i);
reject('adaptive version still requires explicit product unit analysis',b=>delete b.productUnderstanding,/Product understanding|product/i);

// Stub only the metadata probe. This verifies contractual provenance and rejection
// paths using deliberately invalid audiovisual bytes; it is NOT a decode/render test.
function withSynthetic(fn,key='boots'){
 const x=technicalFixture(core,key),original=media.probe;media.probe=x.probe;try{return fn(x)}finally{media.probe=original;x.cleanup()}
}
for(const key of Object.keys(cases))test(key+': SYNTHETIC provenance contract fixture passes technical andactual validation withoutnetwork',()=>withSynthetic(x=>{assert.equal(core.technicalMedia(x.b,x.root),true);assert.equal(core.actual(x.b,x.root),true);},key));
function rejectActual(title,mutate,re){test(title,()=>withSynthetic(x=>{mutate(x);assert.throws(()=>core.actual(x.b,x.root),re);}));}
function editJSON(x,rel,fn){const f=path.join(x.root,rel),o=JSON.parse(fs.readFileSync(f));fn(o);fs.writeFileSync(f,JSON.stringify(o));}
function rebindSourceReview(x){editJSON(x,'evidence/source-review.json',r=>r.generationRecordSha256=require('../../assets/tvc-template/scripts/contracts.cjs').hash(path.join(x.root,'evidence/source-generation.json')));}
rejectActual('a source file changed after generation cannot pass its output hash',x=>fs.appendFileSync(path.join(x.root,'public/source.mp4'),'tampered'),/provenance\/fingerprint|visual review/);
rejectActual('changed hero cannot keep stale reference hashes',x=>fs.appendFileSync(path.join(x.root,'public/hero.png'),'tampered'),/reference|provenance|cutout source\/output hash/i);
rejectActual('actual human use withcropped face cannot pass',x=>editJSON(x,'evidence/source-review.json',r=>r.shots.find(q=>q.faceReview).faceReview.subjects[0].faceClear=false),/face\/product/);
rejectActual('subsecond actual face visibility cannot pass',x=>editJSON(x,'evidence/source-review.json',r=>r.shots.find(q=>q.faceReview).faceReview.subjects[0].visibleForSec=.7),/face\/product/);
rejectActual('actual review cannot claim face duration longerthan source clip',x=>editJSON(x,'evidence/source-review.json',r=>r.shots.find(q=>q.faceReview).faceReview.subjects[0].visibleForSec=9),/face\/product/);
rejectActual('overlapping source intervals cannot be used as different shots',x=>{const s=x.b.story.segments[2];s.sourceStart-=.125;s.sourceEnd-=.125;},/overlapping\/replayed/);
rejectActual('evidence hash changes invalidate visual review',x=>fs.appendFileSync(path.join(x.root,'evidence/S1.png'),'tampered'),/stale visual evidence/);
rejectActual('scene output cannot secretly be an extractedvideo frame',x=>editJSON(x,'evidence/scene-generation.json',r=>r.fromVideoFrame=true),/independent scene/);
rejectActual('comparison image swaps invalidate comparison review',x=>editJSON(x,'evidence/comparison-review.json',r=>r.leftSha256='0'.repeat(64)),/comparison review/);
rejectActual('audio stem changes invalidate soundreview',x=>fs.appendFileSync(path.join(x.root,'public/music.wav'),'tampered'),/audio stems/);
rejectActual('an unreviewed audio mix cannot be released as listened',x=>editJSON(x,'evidence/audio-review.json',r=>r.listening='not_checked'),/listening/);
rejectActual('face evidence must occurinside the actual source interval',x=>editJSON(x,'evidence/source-review.json',r=>r.shots.find(q=>q.faceReview).faceReview.subjects[0].evidence.atSourceSec=9.9),/evidence|face/i);
rejectActual('scene face passed status cannot substitute for actualsubjects',x=>editJSON(x,'evidence/scene-review.json',r=>r.faceReview.subjects=[]),/face|subjects/i);
rejectActual('a generated source cannot havezero submitted requests',x=>{editJSON(x,'evidence/source-generation.json',r=>{r.requests=[];r.submittedThisRound=0;});rebindSourceReview(x);},/request|provenance/i);
rejectActual('known charges cannot use negative real spending',x=>{editJSON(x,'evidence/source-generation.json',r=>r.requests[0].charge={status:'known',amount:-10,unit:'credits'});rebindSourceReview(x);},/charge|cost/i);

test('eight actual shots remain supported when source and edit intervals genuinely split at a new cut',()=>{
 const b=brief('trolley'),original=b.scriptPlan.shots[4],extra={...clone(original),shotId:'S5b',start:6.25,end:7,newInformation:'A distinct documented detail camera angle'};original.end=6.25;b.scriptPlan.shots.splice(5,0,extra);
 const clip=b.story.segments[4];clip.sourceEnd=6.25;b.story.segments.splice(5,0,{clipId:'clip-4b',shotId:'S5b',sourceId:'source-1',sourceStart:6.25,sourceEnd:7,continuousCropSplit:false});
 const i=b.timeline.findIndex(x=>x.clipId==='clip-4'),block=b.timeline[i],end=block.end;block.end=17.25;b.timeline.splice(i+1,0,{...clone(block),id:'block-new-cut',start:17.25,end,clipId:'clip-4b'});
 b.editorialPlan.candidates[0].order=b.timeline.map(x=>x.type);assert.equal(b.scriptPlan.shots.length,8);assert.equal(core.plan(b),true);
});
rejectActual('an actual use shot cannot be mislabeled as detail in its visual review',x=>editJSON(x,'evidence/source-review.json',r=>{const q=r.shots.find(q=>q.faceReview);q.narrativeRole='detail';q.peoplePresent=false;delete q.faceReview;}),/role|face|actual shot|people/i);
rejectActual('subdividing one verified shot cannot counterfeit a second actualcut',x=>editJSON(x,'evidence/source-review.json',r=>{const q=r.shots[2];q.actualShotStart=r.shots[1].actualShotStart;q.actualShotEnd=r.shots[2].sourceEnd;delete q.cutEvidence;}),/cut|shot|proof/i);
rejectActual('non-opening cuts need distinct before andafter evidence',x=>editJSON(x,'evidence/source-review.json',r=>{const q=r.shots[1];q.cutEvidence.after=clone(q.cutEvidence.before);}),/cut|evidence|distinct/i);
rejectActual('cut proof must actually straddle the real cut',x=>editJSON(x,'evidence/source-review.json',r=>{const q=r.shots[1];q.cutEvidence.before.atSourceSec=q.actualShotStart+.05;}),/cut|evidence/i);
rejectActual('a selectedclip cannot extend outside its reviewed actualshot',x=>editJSON(x,'evidence/source-review.json',r=>r.shots[1].actualShotEnd=r.shots[1].sourceEnd-.2),/reviewed shot|source|clip|range/i);
rejectActual('scene clear-face status cannot hide a false face-clear flag',x=>editJSON(x,'evidence/scene-review.json',r=>r.faceReview.subjects[0].faceClear=false),/face|subjects/i);
rejectActual('scene person must bind the planned castidentity',x=>editJSON(x,'evidence/scene-review.json',r=>r.faceReview.subjects[0].castId='someone-else'),/face|cast|subjects/i);

reject('scene output cannot erase planned people to bypass faces',b=>{b.scenes[0].peoplePresent=false;b.scenes[0].castIds=[];},/scene cast|face plan/i);
reject('planned human scene cannot disable face requirement',b=>b.scriptPlan.scenePlans[0].facesRequired=false,/scene cast|face plan/i);
reject('scene cast references must identify a known actor',b=>b.scriptPlan.scenePlans[0].castIds=['unknown-person'],/scene cast|face plan/i);
rejectActual('scene reviewed product count must match the scene plan',x=>editJSON(x,'evidence/scene-review.json',r=>r.productUnitCount=1),/scene provenance|semantic review/i);
rejectActual('source cast continuity must be actually reviewed',x=>editJSON(x,'evidence/source-review.json',r=>r.shots.find(q=>q.peoplePresent).castContinuity='not_checked'),/cast continuity/i);
rejectActual('source cast IDs cannot differ from the use shot plan',x=>editJSON(x,'evidence/source-review.json',r=>r.shots.find(q=>q.peoplePresent).castIds=['different-person']),/cast continuity/i);
rejectActual('complete product declaration in edit needs actual source complete-product review',x=>editJSON(x,'evidence/source-review.json',r=>r.shots[0].fullProductVisible=false),/complete product/i);

function adoptForReuse(x){
 const hash=require('../../assets/tvc-template/scripts/contracts.cjs').hash,source=x.b.story.sources[0];
 x.b.generationPlan.mode='reuse';x.b.generationPlan.maxSubmissions=0;x.b.generationPlan.reuseReason='Existing same-product local video, new edit only; no external calls authorized';source.adoptionRecord='evidence/reuse-adoption.json';
 const a={type:'reuse-adoption',planFingerprint:core.planFingerprint(x.b),originalGenerationRecordSha256:hash(path.join(x.root,source.generationRecord)),sourceSha256:hash(path.join(x.root,'public',source.asset)),productIdentityVerified:true,observations:'SYNTHETIC contract-only adoption of existing source bytes; no actual product identity judgment',currentReferences:core.sourceBindings(x.b,x.root)};x.json(source.adoptionRecord,a);return a;
}
test('reuse mode adopts local source without rewriting historical generation or allowing new calls',()=>withSynthetic(x=>{
 const originalFile=path.join(x.root,x.b.story.sources[0].generationRecord),original=fs.readFileSync(originalFile),old=JSON.parse(original);adoptForReuse(x);
 assert.notEqual(old.planFingerprint,core.planFingerprint(x.b));assert.equal(x.b.generationPlan.maxSubmissions,0);assert.equal(core.actual(x.b,x.root),true);assert.deepEqual(fs.readFileSync(originalFile),original);assert.equal(JSON.parse(fs.readFileSync(originalFile)).submittedThisRound,1);
}));
function rejectReuse(title,mutate,re){test(title,()=>withSynthetic(x=>{adoptForReuse(x);mutate(x);assert.throws(()=>core.actual(x.b,x.root),re);}));}
rejectReuse('reuse mode requires the explicit current adoption record',x=>delete x.b.story.sources[0].adoptionRecord,/provenance|fingerprint/i);
rejectReuse('reuse mode cannot silently keep a new generation attempt budget',x=>x.b.generationPlan.maxSubmissions=1,/attempt budget|submission/i);
rejectReuse('adoption must bind the unchanged historical generation record',x=>editJSON(x,'evidence/reuse-adoption.json',a=>a.originalGenerationRecordSha256='0'.repeat(64)),/provenance|fingerprint/i);
rejectReuse('adoption cannot substitute a different source file',x=>editJSON(x,'evidence/reuse-adoption.json',a=>a.sourceSha256='0'.repeat(64)),/provenance|fingerprint/i);
rejectReuse('adoption must recheck same-product identity',x=>editJSON(x,'evidence/reuse-adoption.json',a=>a.productIdentityVerified=false),/provenance|fingerprint/i);
rejectReuse('adoption must bind the current product references',x=>editJSON(x,'evidence/reuse-adoption.json',a=>a.currentReferences=[]),/provenance|fingerprint/i);
rejectReuse('adoption cannot borrow a stale plan fingerprint',x=>editJSON(x,'evidence/reuse-adoption.json',a=>a.planFingerprint='historical-stale-plan'),/provenance|fingerprint/i);
rejectReuse('rewriting the old generation record breaks existing adoption andsource review hashes',x=>editJSON(x,'evidence/source-generation.json',g=>g.planFingerprint=core.planFingerprint(x.b)),/provenance|fingerprint|review/i);

test('planning may leave real music beats pending but rendering may not',()=>{const b=brief('boots');b.music.beatTimes=[];assert.equal(core.plan(b),true);assert.throws(()=>core.technicalMedia(b,'/private/tmp'),/actual music beat grid/);});

reject('selected candidate must describe actual rendered order',b=>b.editorialPlan.candidates[0].order=['video','feature'],/actual timeline order/);
test('documented exterior anchor is supported by an actual motion family',()=>{const b=brief('boots'),x=b.timeline.find(x=>x.effect==='detail-glide');x.effect='evidence-track';x.annotations=[{featureId:x.featureIds[0],label:'Documented exterior',anchor:{x:.5,y:.4},labelPosition:{x:140,y:250}}];assert.equal(core.plan(b),true)});
reject('a callout cannot invent a feature absent from its evidence block',b=>{const x=b.timeline.find(x=>x.effect==='detail-glide');x.effect='evidence-track';x.annotations=[{featureId:'invented-waterproof-test',label:'No evidence',anchor:{x:.5,y:.4},labelPosition:{x:140,y:250}}]},/callout anchored/);

reject('face hold cannot be omitted from the video plan',b=>delete b.scriptPlan.shots[1].facePlan.minVisibleSec,/face AND product/);
rejectActual('source face visibility duration must be real and finite',x=>editJSON(x,'evidence/source-review.json',r=>delete r.shots.find(q=>q.faceReview).faceReview.subjects[0].visibleForSec),/face\/product/);
rejectActual('scene face duration cannot be omitted',x=>editJSON(x,'evidence/scene-review.json',r=>delete r.faceReview.subjects[0].visibleForSec),/face/);
reject('one person cannot be duplicated as two cast bindings',b=>b.scriptPlan.shots[1].castIds.push('user'),/cast\/use/);
rejectActual('valid cutout cannot override failed source semantic review',x=>editJSON(x,'evidence/source-review.json',r=>r.status='failed'),/source actual visual review/);
rejectActual('valid cutout cannot override failed source product identity',x=>editJSON(x,'evidence/source-review.json',r=>r.shots[0].identity='failed'),/actual shot identity/);
