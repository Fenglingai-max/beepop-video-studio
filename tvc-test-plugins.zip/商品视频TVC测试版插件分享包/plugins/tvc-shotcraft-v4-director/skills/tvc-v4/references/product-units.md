# 商品单位与参考补全

参考图的物件数量不等于实际使用数量，也不等于销售包装数量。分镜前填写productUnderstanding：category、referenceUnitCount、saleUnit、useUnit、heroUnitCount、endingUnitCount、decisionSource，以及completion的required/reason/status/assets/uncertainty。

根据用户要求、用途和商品资料判断 single / pair / set / unknown。销售数量无资料时保留unknown，不能因成对使用声称按双销售。用户明确要求单件展示时尊重其范围。鞋、手套等成对使用商品只有单件参考时，默认先补齐配对主参考，再规划完整识别镜、至少一个使用镜和收尾；单只鞋的材质特写仍可保留。锅、灯等普通单件商品无需凭空加倍，套装按实际资料补齐，不能推测未知配件清单。

补齐不是把同一只鞋复制两份或镜像带字部件。另一只须符合左右脚配对关系，保持同款轮廓、颜色、部件数量及连接，文字不能镜像；避免无依据的后背、底面、内部结构。补全内容标注为推导或生成，不当成实拍证明。不能可靠确定关键结构时记录uncertainty，选择参考支持的机位，必要时请求另一侧资料。只限制不受支持的视角，不因缺一只参考而将所有完整镜头锁成单只。

completion.status：not-required / planned / ready。plan阶段可以planned，先输出补图需求；提交视频生成前必须先有ready的补全主参考及原图，两者一起传给模型，注明原图负责外观事实，补图负责配对和构图。ready不代表免审，必须检查左右配对、数量、比例、字样、鞋带和鞋底一致性。补图/重抽不扩大用户已有的视频次数与预算。

为每项scriptPlan.shots、scenePlans填写productUnitCount，表示该镜头计划实际可见的完整商品件数，局部细节可为1；成对商品的完整识别镜与收尾应成对，至少一个使用镜提供双脚关系，场景图可以一张局部穿着、一张双脚全景。生成后按实际内容审查，不能把单鞋素材声明成双鞋通过校验。

## 用户指定与来源校验

useUnit表示产品的正常使用关系，不强迫每种广告都展示完整组合。用户明确只展示单件时，设置displayPolicy=user-specified，并把用户原话写入displayReason；默认complete-unit。不要为了接受失败素材而事后改成user-specified。商品单位要求与分镜数量绑定到生成计划和构建指纹；参考补全ready后重新导出计划及generation:ready，才能提交。

补全ready需completion.reviewRecord指向真实审查JSON：reviewed=true、evidence为工程相对审片文件；sourceReferences=[{asset,sha256}]绑定真实原图；assets=[{asset,sha256,inferred:true,productUnitCount,pairingRelation,notes}]绑定补图。pairingRelation记录实际左右关系，notes写结构/字样及尚存缺口，不能只数图上鞋的数量。原图负责商品事实，补图承担推导出的组合，不得互相冒充来源。

4.0实际story.reviewRecord每个shot和各scene.reviewRecord都填productUnitCount，与对应计划一致；observations记录局部单件、完整配对或套装关系的实际观察。计数按可见画面填写，不按提示词复制；源视频/图片和证据均绑定哈希。具体格式见[生产数据](production30.md)。自动校验会拒绝件数不匹配、缺审查、旧哈希及没有配对参考的生产；它不能识别图片语义，左右脚、字样和部件必须实际看图。


多色/多排同款陈列、承载工具覆盖与小配件尺度还须按[多色陈列、比例与用途覆盖](assortment-scale-coverage.md)填写presentationPlan。完整阵列默认保留来源行列，参考件数与销售件数分开，不以单件或单排替代。
