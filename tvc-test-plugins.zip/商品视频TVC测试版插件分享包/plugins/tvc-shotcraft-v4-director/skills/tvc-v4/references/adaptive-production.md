# 自适应生产合同4.1.0

新项目`version=4.1.0, productionProfile=adaptive-video10`；durationSec25–30，videoDurationSec10。原4.0合同仅用于旧brief，不能把新计划退回旧固定15+15。

## 规划

保留assetPlan/scalePlan/productUnderstanding，来源图哈希、配对补全与重建审查仍有效。`features`2–8条（常用3–6），每条`id/title/fact/benefit/source/sourceIds[]`；sourceIds对应真实assetPlan.sources。displayValue/displayLabel仅用于有来源的规格。productAnalysis写category/audience/primaryJob/visualEvidence/uncertainties/comparisonDecision。资料不足不能补写“防水、全地形、脸型改善”等。

`scriptPlan.brandDirection`仍含proposition/visualMotif/lighting/rhythm/memoryBeat；cast含id/appearance/wardrobe；productLocks明确款式、件数、连接。shots为5–8项，`start/end`是10秒采用视频中的**源顺序预算**，连续0–10，每镜0.65–2.6秒。每镜含shotId/narrativeRole(product/use/detail)/visual/framing/camera/action/newInformation/environment/editConnection/transition(opening或cut、match-cut)/productVisible/productUnitCount/peoplePresent/castIds/includesUseScene。detail绑定featureId；use写contextKey/useTask。人物use写facePlan={required:true,minVisibleSec:1,framing,visibilityRule}。至少有可见细节和真实使用任务，不强制固定开头棚拍环绕。

`editorialPlan={mode:interleaved|grouped,rationale,variationReason,selectedCandidateId,candidates:[{id,order:[...]}]}`。至少两个实际不同候选。selected的order应与最终timeline类型顺序一致；根据证据挑选，不随机变体。

## 素材区间与成片时间线分离

```json
{
 "story":{
  "sources":[{"id":"source-1","asset":"assets/video.mp4","generationRecord":"evidence/generation.json","reviewRecord":"evidence/story-review.json"}],
  "segments":[{"clipId":"clip-1","shotId":"S1","sourceId":"source-1","sourceStart":0,"sourceEnd":1.5,"continuousCropSplit":false}]
 },
 "timeline":[
  {"id":"v1","type":"video","start":0,"end":1.5,"clipId":"clip-1","purpose":"真实生活hook","fullProductVisible":true},
  {"id":"m1","type":"feature","start":1.5,"end":5,"effect":"kinetic-type","effectReason":"解释当前可见结构对应的利益","featureIds":["f1"],"titleLines":["A REAL BENEFIT"],"layout":"right"}
 ]
}
```

片段按源实际剪点绑定，sourceStart/sourceEnd是原视频秒数；timeline start/end是成片秒数，分散也能原速播放。每clip只用一次，不重叠复制源区间；5–8镜总计10秒。允许同一生成视频拆出多个实际镜头、多个实际源文件及合理重排，不用数字裁切或重复段落冒充新镜。timeline全片连续、按composition.fps对齐帧；非video总计15–20秒；interleaved至少两组视频。源计划与actual使用区间不同不是造假，但须保留原生成及实看剪点证据。

Remotion类型feature/comparison/scene/ending；effect见motion-language。每块id/type/start/end/purpose，非视频还需effect/effectReason/featureIds（可空，如场景桥接）。至少三种适用动效，全部真实features都在对应图形解释中被绑定。至少一处完整识别稳读0.8秒；最后一块可video或Remotion，完整商品≥1.2秒且fullProductVisible=true。不强制五段顺序。

`detail-glide/evidence-track.cameraPath`按成片绝对秒覆盖整块，点含time/x/y/size（宽1920、高为1920×成片高宽比的设计坐标（16:9时1080），size为原图显示宽度）。文字在revealSec（通常.85）后退出。不要反复正负缩放；有意义的一次拉回需motionException解释，实际看帧检查。新模块不支持固定productViewport。

`scriptPlan.scenePlans`和`scenes`按sceneId绑定实际独立场景，含peoplePresent/castIds/productUnitCount，计划含facesRequired；scenes的asset/generationRecord/reviewRecord指真实文件。每张必须入片≥1秒，默认考虑两张，但可根据用途采用1–3张；不用同图裁切冒充独立。comparisons为显式数组（无则空并写comparisonDecision），每项id/mode(same-product-context/same-product-detail/sourced-spec)/leftAsset/rightAsset/leftLabel/rightLabel/basis/sourceIds/reviewRecord。对比必须真实，不存在证据不做。

captionStyle={align:"center",verticalAlign:"middle",fontRatio:.03,bottomRatio:.035,maxWidthRatio:.86,maxLines:2}。全局统一，禁逐镜captionBox和缩小视频加边框。design含background/ink/captionColor/fontFamily。

narration按成片绝对start/end/maxDurationSec/asset/text，英文约1.65–2.45词/秒预算，自然speed1.0；实际WAV覆盖≥64%成片、最长静默≤1.8秒。真实时长不能借虚填end凑覆盖。当前产品可沿用Kokoro已选自然声线。music含asset/source/rights/style/bpm/beatTimes，纯规划时beatTimes可留空表示待定；渲染前才要求实际核对的拍点，不声称公式等于测量。声音见audio-social.md。

## 生成、复用与诚实次数

generationPlan含provider/model/resolution/durationSec（通常10）/maxSubmissions（默认1）/authorizationSource。如果模型只能更长时长，durationSec写实际提交时长并加durationReason；最终仍只采用10秒。ready只检查产品参考，**不提交生成**。费用unknown/free-entitlement/known；known写实际amount≥0与unit，预计费用不能写实扣。一次提交中规划多镜，不自动按镜头拆多次抽卡。

每source的generationRecord保留type=generated-video、planFingerprint、submittedThisRound、submittedCumulative、requests（每次实际id/provider/model/resolution/durationSec/authorizationSource/references/charge）与output={asset,sha256}。失败也计数；每source可以共用一次任务的原始记录，但不得伪造jobId。以sourceBindings输出绑定参考。

复用旧素材时不重写原生成记录：generationPlan.mode="reuse",maxSubmissions=0,reuseReason；每source另写adoptionRecord={type:"reuse-adoption",planFingerprint:当前,originalGenerationRecordSha256,sourceSha256,productIdentityVerified:true,observations,currentReferences:当前sourceBindings}。历史请求留历史指纹，复用核对留当前证据；不将复用称新生成。若同时采用旧源与新生成，在sources旧源用adoptionRecord，generationPlan.maxSubmissions仅限制本任务新提交。

## 实际审查

source.reviewRecord: reviewed=true/status=passed/sourceSha256/generationRecordSha256/shots[]。每shot含shotId/sourceStart/sourceEnd/actualShotStart/actualShotEnd/actualCutVerified=true/identity=passed/physicalScale=passed/productUnitCount/narrativeRole/peoplePresent/castIds/castContinuity/observations/evidence。使用区间须处于一个真正镜头范围内。实际源首镜cutIn=opening；其余cutEvidence.before/after在actualShotStart±.25秒内，前后不同图，时间跨剪点。evidence={file,sha256,atSourceSec}必须绑定真实帧。use还需useSceneVerified=true；人物faceReview={status:passed,subjects:[{castId,faceClear:true,productRelationVisible:true,visibleForSec≥1,evidence}]}，证据须落在**采用的片段**中。计划fullProductVisible镜必须由实际审查确认，不凭提示词猜。

独立场景generationRecord保留independentlyGenerated=true/fromVideoFrame=false/requestId/output={asset,sha256}/referenceBindings至少绑定hero。输出不得视频截图；可以用视频人物帧作身份输入但如实记录。reviewRecord含status/outputSha256/identity/physicalScale/productUnitCount/evidence/observations，有人时faceReview须清楚同框并绑定cast。静态图evidence.atSourceSec=0。对比reviewRecord含status/leftSha256/rightSha256/noUnsupportedClaims=true/observations，实际核实标签与basis。

混音报告始终pending，实际完整试听后才passed。全部旁白、音乐、FX都纳入stems哈希。`render:preview`允许技术齐备但语义/听审缺口；`produce`要求真实审查齐备。release-review额外绑定当前videoSha256/inputFingerprint，visual/fullPlayback/fullListening/subtitleSafety/faces/rhythm/motionContinuity/comparisonHonesty/musicBalance/captionCentering/playbackCompatibility均需真实检查；编码成功不是主观审片。输出MP4、同版内嵌HTM、SRT、配置源码和真实来源记录。

`evidence-track.annotations`每项featureId/label/anchor={x,y原图0–1}/labelPosition={x,y设计画布}；最多3条，线端随真实商品运镜，只标原图能看见的结构。


## 展示素材验收

数据版本仍为4.1.0。目录白底主图默认先处理为真实透明PNG，generation:ready检查实际像素与浅/深/本片背景合成证据；original不能绕过，完整摄影或用户原底须登记实际依据。执行字段、支持的PNG格式、renderRegion与审查证据见[抠图规范](cutout.md)。所有旧视频的商品身份、比例、镜头与声音失败继续阻止produce；资产修复或预览重渲染不授予追加生成。


## 多色阵列与实物尺度

新模板声明presentationPlan，规划与实际验收由scripts/presentation-plan.cjs执行；字段及决策见[多色陈列、比例与用途覆盖](assortment-scale-coverage.md)。规划指纹绑定颜色、来源/展示行列、用途覆盖和scalePlan.references。旧工程未声明时保持兼容；不得为接受失败素材移除新工程的声明。完整阵列/片尾审查与实际比例测量均绑定真实源和采用片段，机器字段检查不等于自动视觉识别。
