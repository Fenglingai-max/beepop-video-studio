# 4.0生产数据与验收

工程brief.json是唯一输入；空白模板不能生产。product.json是prepare自动生成的渲染快照，不手工改以绕过验证。

## brief关键字段

- version=`4.0.0`，productionProfile=`hybrid30-video15`，durationSec=30，videoDurationSec=15。
- assetPlan/scalePlan/productUnderstanding沿用3.1.9角色、规格、配对参考规范。原图全文/拼图区域、主展示素材、补全图及重建证据须一致。
- features恰好两项：id/title/fact/benefit/source，可选asset（默认主图）、zoomFocus={x,y}、maxScale。不把benefit写成无依据性能承诺。
- scriptPlan.brandDirection：proposition/visualMotif/lighting/rhythm/memoryBeat；productLocks为结构事实数组；cast每人id/appearance/wardrobe。
- shots六项：shotId/start/end/narrativeRole(product/use/detail)/visual/framing/camera/action/result/newInformation/environment/transition/productVisible/productUnitCount/peoplePresent/castIds/includesUseScene。第二镜起editConnection必填。role与includesUseScene必须一致。
- 第一镜fullProductVisible=true、introMotion=small-orbit、fullReadSec≥0.8、orbitDegrees=5–30、orbitEvidence；最后一镜fullProductVisible=true、stableHandoffSec≥0.5。
- use镜sceneId/contextKey/useTask须分别定义真实情境，两或三镜contextKey不能重复。有人时facePlan={required:true,minVisibleSec:1,framing,visibilityRule}，每名主要使用者绑定castIds。
- detail镜featureId绑定真实features。六镜各1.5–3.5秒、连续覆盖0–15；实际模型剪点可不同，每实际镜1–4.5秒，总和15秒。
- scenePlans两项：sceneId/purpose/setting/framing/peoplePresent/castIds/facesRequired/productUnitCount。有人必须facesRequired=true；分别生成或复用有独立来源的合格生图。
- generationPlan：provider/model/resolution/durationSec=15/maxSubmissions（默认1）/authorizationSource。预算与授权来源写实际用户指令；此字段不代替真正授权。
- story：asset/generationRecord/reviewRecord/segments。segments每项shotId/start/end/sourceStart/sourceEnd，按实际剪点顺序连续覆盖0–15，原速、不重复源区间、不用crop虚拆。当前版本一个15秒视频源，六个实际镜头。
- scenes两项：sceneId/asset/generationRecord/reviewRecord，asset为public相对PNG/JPEG/WebP。不能把主图、参考图复制或把两场景复制成同字节。
- remotionPlan.blocks连续15–30、顺序feature/feature/scene/scene/ending。两卖点/场景ID各不重复；场景各≥1.5秒，结尾≥2秒。detailMotion=full-canvas、productRevealSec=0.8–1.2、handoff=cut。
- 主标题可按每槽titleBox规划，但字幕使用共享底部系统，不使用逐镜captionBox：全部字幕统一由全局底部系统绘制。必须预留商品净空并实际看帧。
- narration：text/start/end/maxDurationSec/asset；自然配音wav须不超过槽位，时间不能重叠。voice={mode:kokoro,id,language,speed:1}。music={asset,source,baseVolume?,duckRatio?}；audioMixAsset为30秒混音；audioReviewRecord和releaseReviewRecord是工程相对路径。

## 生成视频来源记录

`pnpm generation:ready`输出planFingerprint、references和hero哈希。提交视频后创建story.generationRecord（JSON），不自动制造“已生成”记录：

```json
{
  "type":"generated-video",
  "planFingerprint":"实际ready输出",
  "submittedThisRound":1,
  "submittedCumulative":1,
  "requests":[{
    "id":"服务任务ID","provider":"与generationPlan一致","model":"实际模型","resolution":"实际分辨率","durationSec":15,
    "accountAlias":"当前账号别名，不写凭据","submittedAt":"实际时间","authorizationSource":"制作指令",
    "references":[],"heroSha256":"实际主展示图哈希","charge":{"status":"unknown"}
  }],
  "output":{"asset":"story.mp4","sha256":"真实文件哈希"}
}
```

references原样绑定ready中的图/规格来源。charge.status只允许unknown、free-entitlement或known；known须有实际amount/unit，预计价不能写实扣。补图、生图另记各自来源和次数，视频次数不能把失败提交漏掉。追加授权后才能增加maxSubmissions并重新规划；旧失败记录保留，累计次数明确。

## 真实镜头审查

story.reviewRecord需要reviewed=true/status=passed/sourceSha256/generationRecordSha256和六项shots，按实际segment顺序。每项包括：shotId/sourceStart/sourceEnd/cutIn（首镜opening，其余actual-cut）/identity=passed/physicalScale=passed/productUnitCount/narrativeRole/continuousCropSplit=false/observations。

evidence={file:"evidence/S1.png",sha256:"实际证据图哈希",atSourceSec:0.5}。有真实内部剪点的镜头另填cutEvidence={before:evidence,after:evidence}，分别在剪点前后0.25秒内，不得同图。使用镜还填useSceneVerified=true/contextKey/visibleUseResult，不能只核对场景ID而不看真实内容。首镜fullProductVisible=true，尾镜另填stableHandoffSec≥0.5。handoff={status:passed,observations:"15秒视频末帧与后期首帧方向/尺度/亮度实际观察"}。

有人镜头还填castContinuity=passed，实际核对人物身份与服饰跨镜一致。有人使用的每一镜填faceReview={status:passed,subjects:[{castId,faceClear:true,productRelationVisible:true,visibleForSec:1,observations,evidence}]}，每个主要使用者一项。证据图须落在对应源区间；清晰度、无遮挡、同时能读出商品使用关系必须实际看图判断。字段和文件存在不代表机器识别人脸，脚本不会自动给语义打分。

## 两张独立场景图

每张generationRecord：type=generated-image/sceneId/requestId/provider/sourceDescription/independentlyGenerated=true/fromVideoFrame=false/output={asset,sha256}/referenceBindings=[{asset,sha256}]，至少绑定当前主展示图。两次独立生成有不同requestId；复用时保留原生成记录和当前用途说明，不编造新的任务ID。

每张reviewRecord：status=passed/outputSha256/identity=passed/physicalScale=passed/productUnitCount/observations/evidence。有人使用时同样需要faceReview，visibleForSec按在后期清晰展示时长记录，evidence.atSourceSec=0表示静态图，不谎称视频帧。

## 声音与构建

mix-audio.py写入技术报告及pending的audio-review，只有实际试听后才把status/listening改为passed，并填observations。stems必须绑定每条新配音和音乐的asset/sha256，mixSha256绑定混音；clippedSamples=0。系统不会替用户或Agent假造听审。

`pnpm render:preview`允许技术素材齐备但逐镜/生图/声音审查尚缺，输出mode=preview_pending_review，不能release。`pnpm produce`要求上述实际来源和审查齐备，使用Remotion渲染并全片解码，校对帧数、画幅、30秒和音轨；生成MP4、内嵌HTM及build.json。它仍不自动标记最终通过。

完整播放并试听最终MP4后写releaseReviewRecord：status=passed/videoSha256/inputFingerprint/visual=passed/fullPlayback=passed/fullListening=passed/subtitleSafety=passed/handoff=passed/faces=passed/observations。videoSha256与inputFingerprint来自build.json。`pnpm check:release`比较当前brief、public素材、渲染/校验脚本及审查证据哈希；若改变则旧构建失效。无真人的商品faces检查可记录“无人物使用镜，已核对计划与画面”并标passed，而不能假造人脸。

## 可做与不能自动做的事

本地脚本可验证结构、数量、时长、来源与文件指纹，不会判断图中是不是同款产品，也不会自动检测实际人脸或真实剪镜。真实语义由明确的人工/Agent逐镜审查承担。证据不全可以预览，不可以把预览或单元测试fixture当成正式商品验收。所有检查均不调用外部生成模型，不在失败后自动消费重试。

## 4.0.1数据字段

qualityPolicy.edition=4.0.1，captionMode=bottom-unified，narrationMode=full。默认minPost15SpokenSec=10.5、maxPost15SilentGapSec=1.3、minTotalSpokenSec=20、minPost15Lines=4。英文55–72词按ttsText或text计算。copyPlan包含hook、throughline、closing和至少四项post15Beats，每项start/end/purpose/featureIds，连续覆盖15–30；前两项覆盖两条有来源的卖点。

remotionPlan.style=desktop-continuous、whiteCardPanels=false，全局captionBottomRatio/fontRatio/maxWidthRatio与productSafeBottomRatio决定字幕和商品净空。用户明确无字幕/无旁白时填写qualityPolicy.overrideSource并切换相应例外，不偷偷降低full阈值。

requirements.cjs在规划阶段检查脚本/槽位，technicalMedia在生产阶段改用每条实际音频时长再次检查覆盖；宽松的end不能把短WAV伪装成饱满旁白。

生成指纹仍绑定商品事实与来源、参考/比例/件数、镜头计划、人物和模型，排除纯展示标题/benefit文案、缩放焦点以及镜头字幕框。改写后期文字不伪造新生成；变更事实或参考需重新核对真实绑定。完整构建指纹仍绑定全部配置、源代码与素材。

release-review除原有字段外还要求narrationContinuity、benefitSpecificity、captionUniformity、desktopStyle、playbackCompatibility均有实际检查。保留同一最终视频SHA与inputFingerprint绑定；不能用字段齐全替代语义审片/试听/真实播放。
