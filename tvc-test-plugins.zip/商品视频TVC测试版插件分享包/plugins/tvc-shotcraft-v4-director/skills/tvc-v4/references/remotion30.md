# 后15秒Remotion与声音

遵循visual-and-delivery.md和copy-and-voice.md：浅色底独立商品、连续位置与尺度变化、黑白无衬线文字分层进退；禁止场景照片叠白色信息卡。默认15–19秒卖点一、19–23秒卖点二、23–25秒独立场景一、25–27秒独立场景二、27–30秒完整商品收尾。两张场景各至少1.5秒，结尾至少2秒。

先完整稳读0.8–1.2秒再推进有证据的细节。模板用完整画布相机变换，不用固定细节窗口。商品最终位置按字幕安全区检查，不把轮子、手柄、脸或手压在字幕下。15秒处核对方向、比例、亮度；直接交接，不黑场。

字幕只用qualityPolicy.captionMode=bottom-unified的共享底部系统。不要再填写逐镜captionBox；主标题位置与字幕位置分开。用户要求none可明确关闭；custom必须记录明确指令原文，同时实现并测试对应渲染，不得只换模式标记。

先完成copyPlan和全文narration，再生成自然Kokoro配音。默认55–72个实际朗读词、7–9句，后15秒至少四个语义段、有声覆盖至少10.5秒（目标12–13秒），全片至少20秒，后半空白不超过1.3秒。实际检查每条WAV时长，不虚填end，不强制加速。

运行python scripts/generate-kokoro.py --config brief.json --model-dir <当前已核验模型目录> --apply；再运行python scripts/mix-audio.py --config brief.json。选择适合商品的音乐并记录来源、压低于旁白，核对同期新台词、字幕和标题。技术混音不能代替真实试听，未试听不能填passed。

原生Remotion画面由src/Root.tsx与public/motion-engine.js共享，FFmpeg只做最终兼容转码与音频封装。MP4和离线HTM必须内嵌同一个构建文件；输出H.264 Baseline/yuv420p/BT.709有限色域、AAC双声道、faststart，完整解码并实际打开最终路径。
