# 商品抠图与边缘验收

## 适用范围

先按[主图与比例](asset-roles-scale.md)选定真实商品区域，独立商品展示、双卖点与结构特写默认使用该区域的合格透明产品资产。用户明确要求保留原底、使用完整摄影布景或完整场景图时保留其设计，不强制抠掉场景。生成的家居场景图不受透明底要求约束。

## 处理与绑定

- 保留用户原图，另存处理版本，不覆盖来源。先检查现有工具是否支持抠图/透明输出；可用image_gen时按其编辑规则执行。不要把缺失的分割或去底服务当作已接通。
- 区分像素提取与生成式重建：后者填写display.method=generated-reconstruction，不称无损抠图。无论工具是什么，均对照原图核对花纹、文字、部件数量与连接；形状/花纹被改写时不得因为边缘干净就通过。
- 输出有真实alpha的PNG或WebP。不得用白色矩形、CSS混合模式或与页面同色背景代替透明素材；文件扩展名与存在alpha通道都不足以证明已去底。
- 保持商品外形、雕刻、底座、按钮、颜色和结构。透明水晶、玻璃、亚克力须区分实体轮廓、反射高光、内部雕刻与透射背景；保留合理的半透明过渡和高光，不得把球体挖空、内部雕刻擦除或保留一整块不透明白底。不能仅凭“亮色像素”阈值清除透明商品。
- 移除原背景、白边、灰色残底和不属于商品的底部白色底板；自然接触阴影可单独保留为透明柔影，避免灰白矩形与硬边。真实反射高光不应被误删。不能证明背景透射真实重建时，说明是视觉重建，不称物理准确抠图。
- 处理后重新核对完整轮廓与焦点；如有裁边或画布尺寸变化，重新计算focus/region，heroAsset及共用主图的features[].asset绑定处理版本。重新生成product、混音指纹所需配置、MP4与HTM，不能只更新预览图。

## 实际验收

在实际处理图片与渲染画面上检查，不凭工具“成功”状态填写通过：
1. 检查alpha分布及四周背景区域，排除全不透明输出与伪棋盘格；半透明商品不可要求所有主体像素均不透明。
2. 分别合成到浅色、深色和本片实际背景，以100%及计划最大放大倍率观察：不得有可见白边、灰边、残底、锯齿、缺角和被误删细节。检查球体周边、底座下沿、细小结构及内部透明区域。
3. 复查最终MP4/HTM的开场、两条卖点、最大特写、场景交接与收尾；检查连续运镜时光晕、硬边及阴影是否暴露。抽帧不替代完整播放验收。

在工程evidence/cutout-review.json记录原图/处理图路径与SHA256、实际工具和处理方式、alpha检查结果、三种背景的合成证据路径、实际观察与缺陷、最大检查倍率、所绑定的主图/卖点素材，以及status=passed|pending。用户要求保留原底时记录status=not-applicable及用户依据。证据只记录实际完成的检查，不虚构通过；随工程交付必要来源和证据。

4.0沿用assetPlan审查绑定会检查源图/输出哈希、方法、商品区域与观察记录，且生成前只接受reviewed=true、status=passed的fidelity记录；failed/pending不能以“看过”代替通过；本节alpha和商品语义检查仍需实际完成，不能由记录格式自动证明。若工具不可用或结果不合格，继续完成不依赖抠图的工作并明确交付缺口；不得静默交付残底素材并宣称正式视觉验收通过。优先修复素材，不通过改回白底、降低检查标准或删掉需求绕过问题。

## 4.1 新工程的可执行门槛

4.0历史工程维持原合同；4.1工程的 `assetPlan.display` 必须显式指定背景策略，新模板默认：

```json
{
  "method": "extracted",
  "backgroundPolicy": "cutout-required",
  "fidelityReviewRecord": "evidence/product-fidelity.json",
  "cutoutReviewRecord": "evidence/cutout-review.json"
}
```

纯白、纯色目录商品底属于 `cutout-required`；`method=original` 不能免检。原图本身已经是真透明PNG时可以保持original，但仍须完成实际alpha及合成审查。4.1的自动检查当前仅实现静态、8位、非交错、最大1600万像素的RGBA PNG去底输出；不支持的WebP、索引PNG、16位PNG、交错PNG或APNG必须明确转换后重新审查，不能仅改扩展名。RGB PNG可用于不透明合成证据，不能充当透明商品输出。

`generation:ready` 实际解码PNG、校验CRC和行过滤器，检查透明背景及可见主体，不要求主体alpha必须255。全不透明、全透明、仅清掉单像素、四边仍有大块残底均拒绝。透明面积须至少1%，可见主体至少4像素，外围像素至少95%透明；不以主体占整张画布的百分比设置下限，因此小器物和大量透明留白不会误拒。极小但非空主体仍需最大倍率的实际视觉审查，像素数量检查不证明可用清晰度。

抠图记录的最低字段如下（路径/哈希必须绑定实际文件）：

```json
{
  "reviewed": true,
  "status": "passed",
  "backgroundPolicy": "cutout-required",
  "source": {"asset":"assets/original.jpg","sha256":"真实SHA256"},
  "output": {"asset":"assets/product.png","sha256":"真实SHA256"},
  "tool": "实际工具",
  "method": "实际提取或生成重建方式",
  "observations": "实际检查的边缘、轮廓、件数与缺陷",
  "alphaCheck": {"outputSha256":"真实输出SHA256"},
  "maxCheckScale": 2.5,
  "maxScaleEvidence": {"file":"evidence/cutout-zoom.png","sha256":"真实SHA256"},
  "composites": [
    {"background":"light","color":"#ffffff","file":"evidence/cutout-light.png","sha256":"真实SHA256"},
    {"background":"dark","color":"#202020","file":"evidence/cutout-dark.png","sha256":"真实SHA256"},
    {"background":"film","color":"#f5f3ee","file":"evidence/cutout-film.png","sha256":"真实SHA256"}
  ]
}
```

三张合成证据与处理PNG同尺寸，分别按真实alpha合成；程序检查合成像素是否对应输出和声明背景色，不能用同一白底预览改标签冒充深底图。`film.color`须等于当前`design.background`。可另附更多人工审查截图；最大倍率证据需真实查看，不以一个倍率数字代替观察。`maxCheckScale`至少覆盖timeline实际相机倍率，按源图像素及可选`display.renderRegion={x,y,w,h}`计算。renderRegion为归一化构图裁切，不改变PNG及其alpha，不得借裁切丢掉必要商品件数；渲染器必须实现并实际审查该区域。

保留完整摄影布景时使用 `preserve-photographic-scene`，记录必须 `status=not-applicable`、`sourceBackground=photographic-scene`、`completeEnvironmentReviewed=true`，并包含原因和绑定源/输出的实际环境证据。用户要求原底时使用 `preserve-user-request`，记录必须含`authorization={source:"user",quote:"用户真实原话"}`、原因和证据。两种例外仅允许`method=original`；纯目录底不能声称完整环境，模型自己决定保留背景不能冒充用户指令。机器不能识别摄影语义或验证引文真实性，这部分仍由实际阅读和审查承担，不得称自动确认。

4.1的referencePhotoOverrides也必须逐项具备上述保留原底策略及cutoutReviewRecord，不能仅填reason绕过。所有显式非视频timeline商品素材必须是主展示或已审查的override；场景输出仍按独立场景合同管理。fidelity/cutout记录及其证据被纳入制作输入指纹，任一文件变化均令旧构建验收失效。

这些门槛只验证资产与证据一致性。商品改款、比例失败、缺脸、真实剪点不足等原有失败不能因抠图合格而改为passed；既有生成预算与重试授权保持不变。
