# 原生Remotion动效选择

`timeline[]`每个非video块绑定`effect`及`effectReason`，画面原生由`public/adaptive-engine.js`和Remotion Root绘制；不是只改提示词。设计画布宽1920、高为1920×成片高宽比（横屏16:9时1080），最终输出按composition适配，不拉伸素材。按最终分辨率检查文字与人物。

| effect | 信息用途 | 关键配置 |
|---|---|---|
| detail-glide | 可见材质/接口/结构连续观察 | `cameraPath[{time,x,y,size}]`绝对成片秒；同一段不反复缩小归零，x/y单调三次插值、size对数插值；推近前文案退场 |
| evidence-track | 有来源的外部部件/连接解释 | cameraPath与1–3个annotations，锚点跟随产品，label绑定featureId，不虚构内部结构 |
| kinetic-type | 一个高优先级利益点 | `titleLines,label,layout`，逐行短入场、商品自然漂移，不弹簧反弹 |
| benefit-stack | 同一个使用任务的多条关联利益 | 2–4条`featureIds`、分层节拍揭示；不把每条小字堆满屏 |
| spec-grid | 已给出的真实规格/容量/尺寸 | feature的`displayValue/displayLabel`有来源；真实数字静态可读，禁虚构图表 |
| compare-reveal | 同商品不同状态/用途或有证据规格 | `comparisonId`绑定两图与`basis/sourceIds`，左右标题，短揭示；不模拟无依据实验 |
| context-match | 独立生活场景 | `sceneId`绑定实际图；微弱全幅运动，保留人脸/产品关系 |
| hero-lockup | 完整组合/具体结果收束 | 自选left/right/center，短文字、完整产品≥1.2s；片尾也可直接使用真实视频 |

不是要求每片都用全八种。至少三种适用表现是防止全片仅一张图移动；如果某种效果不回答产品事实，不选。3–6个卖点可聚成一块，也可跨视频/图形解释，不等于每个卖点独占一个固定槽。

`detail-glide`初次出现产品通常先稳读0.8–1秒。可以保持同一尺度扫描多个真实结构，或一次推近后扫动，最后确有叙事需要再拉回一次并写`motionException`。不要套旧free-camera的whole→one→whole→two→whole。邻接同图连续相机块必须接住位置/尺度；有明确切镜可以换景别，实际看相邻帧判断。

字幕的`captionGeometry`使用actualBoundingBoxAscent/Descent/Left/Right，按整组字形的包围框将横/纵中心放在字幕框中心；一行、两行都要实际看帧，不凭近似baseline。统一字号、边距和底部位置。保留全幅视频，不能再用90%缩小换净空。

节拍不是永远每拍一切：生活动作开始/结束、卖点被读清、接触证据优先，关键切点可对齐真实音乐beatTimes。动效通常0.2–0.55秒入场、0.7–1.6秒有效推进，但时长由信息任务决定，不一律慢慢铺满几秒。
