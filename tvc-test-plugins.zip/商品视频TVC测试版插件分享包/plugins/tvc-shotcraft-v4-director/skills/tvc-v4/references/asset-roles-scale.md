# 主图、参考图与产品比例

制作前填写 `assetPlan` 与 `scalePlan`。图片的事实用途和是否进入成片分开判断；多张上传图不等于多张可直接展示的素材。

## 主图负责产品展示

先逐张看图，选定一张能够锁定商品轮廓、颜色、部件、文字与销售组合的主图。记录选择依据，不机械使用第一张或分辨率最高的一张。其余按事实用途标为细节、使用或规格参考；参考图默认不进入成片。

主图若是拼图，先以归一化 `productRegion={x,y,w,h}` 标出真正的商品区域，排除文字、对比图、佩戴示意或无关型号。完整套装/成对商品仍按 `productUnderstanding` 确认需要保留的完整组合。不能把整张拼图直接绑定为产品主画面，也不能因提取困难取消已确认的商品关系。

`heroAsset` 与默认 `features[].asset` 绑定同一合格的产品展示资产。两条卖点通过焦点、局部区域与运镜表达，不自动轮播上传照片。参考照片只有在用户明确要求，或脚本确实需要展示该照片且记录具体理由时，才加入 `referencePhotoOverrides`；不得用“参考更方便”替代展示决策。独立生成并审核合格的场景输出仍按场景段展示，不因禁止误贴参考照片而删除。4.0渲染器支持features.asset引用已声明且有明确理由的override；实际画面仍须审查，不把规格排版图默认当主展示。

```json
{
  "assetPlan": {
    "version": 1,
    "primarySourceId": "primary-1",
    "sources": [
      {
        "id": "primary-1",
        "asset": "assets/product-original.jpg",
        "role": "primary",
        "selectionReason": "此图可核对完整商品与部件关系",
        "productRegion": {"x": 0, "y": 0, "w": 1, "h": 1}
      }
    ],
    "display": {
      "asset": "assets/product-display.png",
      "sourceId": "primary-1",
      "method": "extracted",
      "fidelityReviewRecord": "evidence/product-fidelity.json"
    },
    "referencePhotoOverrides": []
  }
}
```

`sources[].role` 为 `primary | detail-reference | use-reference | spec-reference`；每项有唯一 `id` 与 `selectionReason`；primary、detail-reference、use-reference必须是图像并有真实 `asset`，主图还必须有有效 `productRegion`。规格来源可为图像，也可为用户提供的文字：`{id:"spec-text-1",role:"spec-reference",kind:"text",text:"用户提供的规格原文",selectionReason:"用户明确提供的尺寸依据"}`，文字规格无需asset，不要求用户额外补规格图片。参考图按其主要用途登记，补充用途写入选择依据。示例为字段形状，不是默认商品内容。

`display.method`：

- `original`：完整原图就是有意采用的展示构图；非完整 `productRegion` 的拼图不能借此直接入片。
- `extracted`：从选定商品区域提取并去底，保持原商品像素和形状；按[抠图验收](cutout.md)检查。
- `generated-reconstruction`：工具对商品进行了生成式重建。不得称无损抠图；逐项检查外形、花纹、文字、颜色、数量与连接，不能只因alpha干净就判商品一致性通过。发现改款须标记缺口，不把重建图当新的产品事实来源。

对于提取/重建资产，生成前准备校验需要真实审查JSON：`{reviewed:true,status:"passed",source:{asset,sha256},output:{asset,sha256},productRegion,method,observations}`。status为passed、failed或pending，generation:ready只接受reviewed=true且status=passed。路径均相对 `public`，审查记录路径相对工程根；哈希绑定实际原图与实际输出。`reviewed`只表示实际完成了审查，不能单独表示通过；`observations`必须如实写缺陷，失败或待定状态不得放行。4.0历史工程完整原图直接展示无需伪造处理记录；4.1必须按cutout.md登记实际透明审查或有依据的原底例外，original不是豁免。纯规划时展示素材可待提取，规划指纹绑定真实主源、参考图与文字，不伪造输出文件；generation:ready仍会阻止缺少展示素材。

## 构图大小与实际使用大小分别判断

**构图大小**是产品在composition画布中的占比；默认1920×1080，可按用户要求配置画幅。完整轮廓、成对/套装关系和安全留白优先。4.0使用`remotionPlan.detailMotion="full-canvas"`和`productRevealSec=0.8–1.2`；feature.maxScale及zoomFocus配置全画幅推近、回到全貌，不使用旧版presentation/cameraPath字段。文案和字幕通过每槽titleBox/captionBox避开脸、手和关键部件。物理尺寸与画面放大倍率分开判断。

**实际使用大小**是商品相对人体、手掌、发辫、家具或环境的真实比例。棚拍中的放大构图不等于真实尺寸，销售件数也不等于同时使用数量。优先采用一致且可核对的规格；其次通过真实使用图判断相对比例和附着位置。不能用装饰排版大小反推毫米，也不能把未知尺寸写成确定规格。

```json
{
  "scalePlan": {
    "physical": {
      "status": "relative",
      "sourceIds": ["use-1"],
      "evidence": "使用参考中可见商品相对承载部位的比例",
      "wearingRule": "沿参考支持的部位与方向放置，保持相对尺度，不新增连接方式"
    }
  }
}
```

- `verified`：有可靠规格，`dimensions=[{name,value,unit,sourceId}]` 记录正数、单位及 `spec-reference` 来源；sourceId可指规格图片或用户文字规格。规格来源互相矛盾时不能使用此状态。
- `relative`：`sourceIds` 绑定 `use-reference`，`evidence` 与 `wearingRule` 描述可观察的尺度、位置和附着关系；不编造数值尺寸。
- `unknown`：`evidence` 写明未知处，`wearingRule` 选择有参考支持的静态角度、保守动作和可审核构图，不填 `dimensions`。不知道尺寸不代表可以任意放大。

生成后逐镜比较实际使用比例、件数与接触/附着关系。4.0将实际比例审查合并到story.reviewRecord的每项shots，以及各scene.reviewRecord：physicalScale=passed、observations写参考依据、尺度与附着关系的实际观察、evidence绑定真实证据图。源规格/使用图由generation记录的references绑定，输出由源视频/场景输出SHA256绑定；换源图、规格或生成素材不能复用旧记录。完整格式见[4.0生产数据](production30.md)。不能为缺比例审查而只填passed。

## 校验边界

自动校验可以检查素材角色、引用路径、原图区域、来源哈希、记录覆盖、几何边界与全貌稳读区间，不能识别“太阳纹是否变叶纹”、尺寸标注是否真实或发扣是否正确套住发辫。规划通过、渲染成功、字段齐全均不等于视觉验收；必须实际看图、核对切点、播放和试听。失败素材不进入正式验收，不未经授权再次生成；预算和重试仍按当前用户授权执行。


多色/多排同款陈列、承载工具覆盖与小配件尺度还须按[多色陈列、比例与用途覆盖](assortment-scale-coverage.md)填写presentationPlan。完整阵列默认保留来源行列，参考件数与销售件数分开，不以单件或单排替代。
