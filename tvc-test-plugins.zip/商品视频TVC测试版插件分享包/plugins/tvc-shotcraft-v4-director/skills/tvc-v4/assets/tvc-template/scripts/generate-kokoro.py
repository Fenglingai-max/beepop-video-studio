"""Generate product-specific PCM WAV with Kokoro, never accelerate to force a slot."""
import argparse, copy, datetime, hashlib, importlib.metadata, json, math, sys, uuid
from pathlib import Path


def digest(p):
    h = hashlib.sha256()
    with p.open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--config', required=True)
    ap.add_argument('--model-dir')
    ap.add_argument('--voice', default=None)
    ap.add_argument('--speed', type=float, default=None)
    ap.add_argument('--duration', type=float, default=None)
    ap.add_argument('--sample', type=int, help='Generate only this zero-based narration index for listening')
    ap.add_argument('--apply', action='store_true', help='After all lines fit, back up and update the input config')
    args = ap.parse_args()
    if args.speed is not None and not 0.9 <= args.speed <= 1.1:
        raise ValueError('Use natural synthesis speed 0.9–1.1; shorten text rather than accelerating')
    if args.duration is not None and (not math.isfinite(args.duration) or args.duration <= 0 or args.duration > 600):
        raise ValueError('Invalid duration')
    if args.sample is not None and args.apply:
        raise ValueError('Sample never updates the product config; omit --apply')
    config = Path(args.config).resolve()
    original = config.read_bytes()
    data = json.loads(original)
    args.voice = args.voice or data.get('voice', {}).get('id')
    args.speed = args.speed if args.speed is not None else data.get('voice', {}).get('speed', 1.0)
    if not 0.9 <= args.speed <= 1.1:
        raise ValueError('Use natural synthesis speed 0.9–1.1')
    if not args.voice:
        raise ValueError('Choose voice.id or pass --voice; no fixed female default')
    args.duration = args.duration or data.get('durationSec', 15)
    lang = data.get('voice', {}).get('language', 'en-us')
    if args.voice.startswith('b'):
        lang = 'en-gb'
    elif args.voice.startswith('a'):
        lang = 'en-us'
    project = config.parent
    if not (project / 'public').is_dir():
        raise ValueError('Config must be in the work project root beside public/')
    lines = data.get('narration')
    if not isinstance(lines, list) or not lines:
        raise ValueError('Fill narration[] with this product\'s confirmed English text/start; no example fallback')
    for i, line in enumerate(lines):
        if not isinstance(line.get('text'), str) or not line['text'].strip():
            raise ValueError(f'Line {i}: text required')
        if not isinstance(line.get('start'), (int, float)) or not math.isfinite(line['start']) or not 0 <= line['start'] < args.duration:
            raise ValueError(f'Line {i}: invalid start')
        if i and line['start'] <= lines[i-1]['start']:
            raise ValueError('Narration starts must be strictly increasing')
    if args.sample is not None and not 0 <= args.sample < len(lines):
        raise ValueError('Sample index outside narration[]')
    model_dir = Path(args.model_dir).resolve() if args.model_dir else project / '.tvc-voice/models'
    specs = json.loads(Path(__file__).with_name('kokoro-models.json').read_text())
    for name, spec in specs.items():
        if not (model_dir / name).is_file() or digest(model_dir / name) != spec['sha256']:
            raise ValueError(f'Missing or unverified model: {name}; run setup-kokoro.py')
    import numpy as np
    import soundfile as sf
    from kokoro_onnx import Kokoro
    engine = Kokoro(str(model_dir / 'kokoro-v1.0.onnx'), str(model_dir / 'voices-v1.0.bin'))
    if args.voice not in engine.get_voices():
        raise ValueError('Requested voice is not present in the real model')
    run = datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ') + '-' + uuid.uuid4().hex[:8]
    relative = Path('voice-kokoro') / run
    out = project / 'public' / relative
    out.mkdir(parents=True, exist_ok=False)
    record = {'provider': 'kokoro-onnx', 'packageVersion': importlib.metadata.version('kokoro-onnx'),
              'voice': args.voice, 'language': lang, 'speed': args.speed, 'createdUtc': run,
              'modelHashes': {k: v['sha256'] for k, v in specs.items()},
              'inputConfig': config.name, 'inputSha256': hashlib.sha256(original).hexdigest(),
              'mode': 'sample' if args.sample is not None else 'full', 'lines': [],
              'sampleListening': 'not_checked', 'fullListening': 'not_checked',
              'captionSync': 'not_checked', 'mixListening': 'not_checked', 'timing': 'pending'}
    indices = [args.sample] if args.sample is not None else list(range(len(lines)))
    generated = []
    errors = []
    rate = None
    for i in indices:
        line = lines[i]
        text = line.get('ttsText', line['text'])
        if not isinstance(text, str) or not text.strip():
            raise ValueError(f'Line {i}: invalid ttsText')
        audio, sr = engine.create(text, voice=args.voice, speed=args.speed, lang=lang)
        audio = np.asarray(audio, dtype=np.float32).reshape(-1)
        if not len(audio) or not np.isfinite(audio).all() or float(np.max(np.abs(audio))) < 0.0001:
            raise ValueError(f'Line {i}: empty/invalid audio')
        if rate is not None and rate != sr:
            raise ValueError('Inconsistent sample rates')
        rate = sr
        duration = len(audio) / sr
        next_start = lines[i+1]['start'] if i+1 < len(lines) else args.duration
        limit = next_start - line['start'] - 0.12
        if 'maxDurationSec' in line:
            value = line['maxDurationSec']
            if not isinstance(value, (int, float)) or not math.isfinite(value) or value <= 0:
                raise ValueError(f'Line {i}: invalid maxDurationSec')
            limit = min(limit, value)
        if duration > limit:
            errors.append(f'Line {i}: {duration:.3f}s exceeds {limit:.3f}s; shorten text, no speed-up applied')
        generated.append((i, audio, duration))
    # One common gain for the run, preserving relative loudness; no per-line normalization.
    peak = max(float(np.max(np.abs(a))) for _, a, _ in generated)
    gain = min(1.0, 0.95 / peak)
    for i, audio, duration in generated:
        asset = (relative / f'line-{i:02d}.wav').as_posix()
        sf.write(project / 'public' / asset, audio * gain, rate, subtype='PCM_16')
        entry = {'index': i, 'text': lines[i]['text'], 'ttsText': lines[i].get('ttsText', lines[i]['text']),
                 'asset': asset, 'start': lines[i]['start'], 'end': lines[i]['start'] + duration,
                 'durationSec': duration, 'sampleRate': rate, 'sha256': digest(project / 'public' / asset)}
        record['lines'].append(entry)
        if args.sample is None:
            data['narration'][i].update(asset=asset, end=entry['end'], voice=args.voice, speed=args.speed)
    record['timing'] = 'failed' if errors else 'passed'
    record['timingErrors'] = errors
    record['gain'] = gain
    (out / 'voice-production.json').write_text(json.dumps(record, ensure_ascii=False, indent=2) + '\n')
    if args.sample is None:
        if errors:
            print(json.dumps({'status': 'timing_failed', 'report': str(out / 'voice-production.json'), 'errors': errors}, ensure_ascii=False))
            return 2
        full = np.zeros(round(args.duration * rate), dtype=np.float32)
        for i, audio, _ in generated:
            start = round(lines[i]['start'] * rate)
            end = start + len(audio)
            if end > len(full):
                raise ValueError('Audio exceeds composition duration')
            full[start:end] += audio * gain
        sf.write(out / 'voice-only.wav', full, rate, subtype='PCM_16')
        updated = out / 'product.kokoro.json'
        updated.write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n')
        if args.apply:
            if config.read_bytes() != original:
                raise ValueError('Input config changed during generation; refusing to overwrite')
            backup = config.with_name(config.stem + '.before-kokoro-' + run + '.json')
            backup.write_bytes(original)
            temp = config.with_name(config.name + '.kokoro-' + run + '.tmp')
            temp.write_bytes(updated.read_bytes())
            temp.replace(config)
    print(json.dumps({'status': 'generated', 'mode': record['mode'], 'voice': args.voice,
                      'output': str(out), 'configApplied': args.apply, 'listening': 'not_checked'}, ensure_ascii=False))
    return 0


if __name__ == '__main__':
    try:
        sys.exit(main())
    except Exception as e:
        print(f'Kokoro generation failed: {e}\nNo system TTS or example-audio fallback was used.', file=sys.stderr)
        sys.exit(1)
