// Strict 4.1 display gate. Pixel statistics are technical evidence, never a
// substitute for actual silhouette/edge/identity review. No external packages.
const fs=require('fs'),path=require('path'),zlib=require('zlib');
const {file,hash}=require('./contracts.cjs');
const fail=m=>{throw Error('Cutout: '+m)},str=x=>typeof x==='string'&&x.trim();
const crcTable=Array.from({length:256},(_,n)=>{for(let k=0;k<8;k++)n=(n>>>1)^((n&1)?0xedb88320:0);return n>>>0});
function crc32(b){let c=0xffffffff;for(const v of b)c=(c>>>8)^crcTable[(c^v)&255];return(c^0xffffffff)>>>0;}
function png(p){
 const b=fs.readFileSync(p),signature=Buffer.from([137,80,78,71,13,10,26,10]);
 if(b.length<33||!b.subarray(0,8).equals(signature))fail('Only real transparent PNG is supported for cutout displays (not renamed JPEG/WebP)');
 let w,h,type,depth,interlace,parts=[],ended=false;
 for(let o=8;o+12<=b.length;){const len=b.readUInt32BE(o),kind=b.toString('ascii',o+4,o+8);if(len>b.length-o-12)fail('Truncated PNG');const d=b.subarray(o+8,o+8+len);if(crc32(b.subarray(o+4,o+8+len))!==b.readUInt32BE(o+8+len))fail('PNG chunk CRC mismatch');if(kind==='tRNS'||kind==='acTL')fail('Use static RGBA PNG; RGB color-key transparency/APNG is unsupported');
  if(kind==='IHDR'){if(len!==13)fail('Invalid PNG header');w=d.readUInt32BE(0);h=d.readUInt32BE(4);depth=d[8];type=d[9];interlace=d[12];if(d[10]||d[11])fail('Unsupported PNG compression/filter method');}
  if(kind==='IDAT')parts.push(d);if(kind==='IEND'){ended=true;break;}o+=len+12;
 }
 if(!ended||!w||!h||w*h>16000000||depth!==8||interlace!==0||![2,6].includes(type))fail('PNG must be 8-bit, non-interlaced RGB/RGBA, at most 16 megapixels');
 const ch=type===6?4:3,stride=w*ch,expected=h*(stride+1);let raw;try{raw=zlib.inflateSync(Buffer.concat(parts),{maxOutputLength:expected});}catch(e){fail('Invalid/compressed PNG data: '+e.message)}if(raw.length!==expected)fail('PNG decoded byte length mismatch');
 const pixels=Buffer.alloc(w*h*ch);let o=0;
 const paeth=(a,b,c)=>{const p=a+b-c,pa=Math.abs(p-a),pb=Math.abs(p-b),pc=Math.abs(p-c);return pa<=pb&&pa<=pc?a:pb<=pc?b:c;};
 for(let y=0;y<h;y++){const f=raw[o++];if(f>4)fail('Unsupported PNG row filter');for(let x=0;x<stride;x++){const i=y*stride+x,a=x>=ch?pixels[i-ch]:0,b=y?pixels[i-stride]:0,c=y&&x>=ch?pixels[i-stride-ch]:0;pixels[i]=(raw[o++]+(f===0?0:f===1?a:f===2?b:f===3?Math.floor((a+b)/2):paeth(a,b,c)))&255;}}
 let transparent=0,partial=0,opaque=0,border=0,borderTransparent=0;
 for(let y=0;y<h;y++)for(let x=0;x<w;x++){const a=ch===4?pixels[(y*w+x)*4+3]:255;if(a<=8)transparent++;else if(a>=247)opaque++;else partial++;if(x===0||y===0||x===w-1||y===h-1){border++;if(a<=8)borderTransparent++;}}
 return{data:pixels,channels:ch,width:w,height:h,hasAlpha:ch===4,pixels:w*h,transparent,partial,opaque,transparentRatio:transparent/(w*h),borderTransparentRatio:borderTransparent/border};
}
function evidence(root,e){if(!str(e?.file)||!str(e.sha256)||hash(file(root,e.file))!==e.sha256)fail('Missing/stale cutout evidence hash');return file(root,e.file);}
function bound(root,e,asset){if(e?.asset!==asset||!str(e.sha256)||hash(file(path.join(root,'public'),asset))!==e.sha256)fail('Missing/stale cutout source/output hash');}
function validatePolicy(display){if(!['cutout-required','preserve-photographic-scene','preserve-user-request'].includes(display.backgroundPolicy))fail('Declare backgroundPolicy; catalog/plain backgrounds require cutout-required');if(!str(display.cutoutReviewRecord))fail('cutoutReviewRecord is required, including original/exception displays');}
function validate(root,b,display,source){
 validatePolicy(display);const r=JSON.parse(fs.readFileSync(file(root,display.cutoutReviewRecord),'utf8'));
 bound(root,r.source,source);bound(root,r.output,display.asset);
 if(r.reviewed!==true||r.backgroundPolicy!==display.backgroundPolicy||!str(r.observations)||!str(r.tool)||!str(r.method))fail('Actual bound cutout/exception observations, tool and method required');
 if(display.backgroundPolicy!=='cutout-required'){
  if(display.method!=='original'||r.status!=='not-applicable'||!str(r.reason))fail('Original-background exception requires not-applicable review and reason');
  if(display.backgroundPolicy==='preserve-photographic-scene'&&(r.sourceBackground!=='photographic-scene'||r.completeEnvironmentReviewed!==true))fail('Photography exception requires actual complete-environment review; catalog/plain is not a scene');
  if(display.backgroundPolicy==='preserve-user-request'&&(r.authorization?.source!=='user'||!str(r.authorization.quote)))fail('User-background exception requires the actual user instruction quote');
  evidence(root,r.evidence);return;
 }
 if(r.status!=='passed')fail('Actual cutout review must pass; pending/failed cannot release');
 const stats=png(file(path.join(root,'public'),display.asset));
 // A padded isolated-product display must have substantial real background and
 // clear outer padding. Partial pixels inside the subject remain permitted.
 if(!stats.hasAlpha||stats.transparentRatio<.01||stats.pixels-stats.transparent<4||stats.borderTransparentRatio<.95)fail('Real alpha must contain a visible subject and transparent padded background, not opaque/empty/single-pixel output');
 if(!r.alphaCheck||r.alphaCheck.outputSha256!==r.output.sha256)fail('Alpha review must bind actual output');
 const crop=display.renderRegion||{x:0,y:0,w:1,h:1},cw=stats.width*crop.w,ch=stats.height*crop.h;
 if(display.renderRegion){const x0=Math.floor(crop.x*stats.width+1e-7),y0=Math.floor(crop.y*stats.height+1e-7),x1=Math.ceil((crop.x+crop.w)*stats.width-1e-7),y1=Math.ceil((crop.y+crop.h)*stats.height-1e-7);for(let y=0;y<stats.height;y++)for(let x=0;x<stats.width;x++)if((x<x0||x>=x1||y<y0||y>=y1)&&stats.data[(y*stats.width+x)*4+3]>8)fail('renderRegion clips nontransparent product pixels; preserve the complete unit');}
 const required=Math.max(1,...(b.timeline||[]).filter(x=>x.type!=='video'&&(x.asset||b.heroAsset)===display.asset).flatMap(x=>x.cameraPath?.length?x.cameraPath.map(k=>k.size/cw):[Math.min(1920*(x.layout==='center'?.65:.51)/cw,(1920*b.composition.height/b.composition.width)*.73/ch)]));
 if(!Number.isFinite(r.maxCheckScale)||r.maxCheckScale+1e-9<required)fail('Review must cover planned maximum image scale');
 if(!Array.isArray(r.composites)||r.composites.length!==3)fail('Light/dark/film background composites required');
 for(const kind of ['light','dark','film']){const q=r.composites.find(q=>q.background===kind);if(!q||!str(q.color)||!/^#[0-9a-f]{6}$/i.test(q.color))fail('Three distinct background kinds with actual colors required');if(kind==='film'&&q.color.toLowerCase()!==b.design.background.toLowerCase())fail('Film composite must match actual design background');const st=png(evidence(root,q));if(st.width!==stats.width||st.height!==stats.height)fail('Composite dimensions must match cutout');
  const rgb=[1,3,5].map(i=>parseInt(q.color.slice(i,i+2),16));let bad=0;
  for(let i=0;i<stats.pixels;i++){const a=stats.data[i*4+3]/255;let mismatch=st.channels===4&&st.data[i*4+3]!==255;for(let c=0;c<3;c++)if(Math.abs(st.data[i*st.channels+c]-(stats.data[i*4+c]*a+rgb[c]*(1-a)))>10)mismatch=true;if(mismatch)bad++;}
  if(bad/stats.pixels>.01)fail('Composite pixels do not match real source alpha and declared background');
 }
 if(new Set(r.composites.map(q=>q.file)).size!==3||new Set(r.composites.map(q=>q.color.toLowerCase())).size<2)fail('Independent composite files and distinct light/dark colors required');
 const light=r.composites.find(q=>q.background==='light').color,dark=r.composites.find(q=>q.background==='dark').color;
 const lum=s=>[1,3,5].reduce((n,i)=>n+parseInt(s.slice(i,i+2),16),0)/3;if(lum(light)<200||lum(dark)>80)fail('Light/dark evidence backgrounds must actually be light/dark');
 evidence(root,r.maxScaleEvidence);
 return stats;
}
function records(b){return[b.assetPlan?.display,...(b.assetPlan?.referencePhotoOverrides||[])].filter(Boolean).flatMap(x=>[x.fidelityReviewRecord,x.cutoutReviewRecord].filter(Boolean));}
module.exports={png,validatePolicy,validate,records};
