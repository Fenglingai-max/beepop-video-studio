const fs=require('fs'),path=require('path'),c=require('./core.cjs');
const cmd=process.argv[2],f=path.resolve(process.argv[3]||'brief.json'),root=path.dirname(f),b=JSON.parse(fs.readFileSync(f));let result;
if(cmd==='plan')result=c.writePlan(b,root);
else if(cmd==='ready')result=c.ready(b,root);
else if(cmd==='inputs'){c.ready(b,root);c.actual(b,root);result={status:'reviewed_inputs',actualShots:b.story.segments.length};}
else if(cmd==='prepare')result=c.prepare(b,root);
else if(cmd==='release'){result=c.release(b,root);fs.writeFileSync(path.join(root,'acceptance.json'),JSON.stringify(result,null,2)+'\n');}
else throw Error('Expected plan|ready|inputs|prepare|release [brief.json]');
console.log(JSON.stringify(cmd==='plan'?{status:result.status,plannedShotCount:b.scriptPlan.shots.length,videoDurationSec:b.videoDurationSec,totalDurationSec:b.durationSec}:result,null,2));
