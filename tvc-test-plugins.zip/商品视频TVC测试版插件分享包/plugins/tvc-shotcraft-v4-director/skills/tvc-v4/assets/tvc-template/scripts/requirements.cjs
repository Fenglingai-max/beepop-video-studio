const fail=m=>{throw Error('TVC4 quality: '+m)},str=x=>typeof x==='string'&&x.trim();
function intervals(lines,a=15,b=30){return lines.filter(n=>n.end>a&&n.start<b).map(n=>[Math.max(a,n.start),Math.min(b,n.end)]).sort((x,y)=>x[0]-y[0])}
function coverage(lines,a=15,b=30){let end=a,spoken=0,gap=0;for(const [s,e]of intervals(lines,a,b)){gap=Math.max(gap,s-end);spoken+=Math.max(0,e-Math.max(end,s));end=Math.max(end,e)}return{spoken,gap:Math.max(gap,b-end),lines:intervals(lines,a,b).filter(([s,e])=>e-s>=.3).length}}
function policy(b){const q=b.qualityPolicy,r=b.remotionPlan;if(!q||q.edition!=='4.0.1')fail('set optimized qualityPolicy edition4.0.1');
 if(!['bottom-unified','none','custom'].includes(q.captionMode))fail('captionMode must be explicit');if(q.captionMode!=='bottom-unified'&&!str(q.overrideSource))fail('caption exception needs the current user instruction');
 if(!['full','silent','custom'].includes(q.narrationMode))fail('narrationMode must be explicit');if(q.narrationMode!=='full'&&!str(q.overrideSource))fail('narration exception needs current user instruction');
 if(r.style!=='desktop-continuous'||r.whiteCardPanels!==false)fail('restore desktop continuous product/type motion; no white information cards');
 if(q.captionMode==='bottom-unified'){
  if(!(r.captionBottomRatio>=.025&&r.captionBottomRatio<=.08&&r.captionFontRatio>=.024&&r.captionFontRatio<=.038&&r.captionMaxWidthRatio>=.65&&r.captionMaxWidthRatio<=.9&&r.productSafeBottomRatio>0&&r.productSafeBottomRatio<=.86))fail('shared bottom caption style and product clearance required');
  for(const x of [...b.scriptPlan.shots,...r.blocks])if(x.captionBox)fail('remove per-shot captionBox; captions use one global bottom system');
 }
 if(q.narrationMode!=='full')return true;
 const p=b.copyPlan;if(!p||!['hook','throughline','closing'].every(k=>str(p[k])))fail('write a hook, throughline and concrete closing before generation');
 if(!Array.isArray(p.post15Beats)||p.post15Beats.length<4)fail('plan four post15 beats: feature1, feature2, scene bridge, closing');let end=15;const ids=new Set();
 for(const [i,x]of p.post15Beats.entries()){if(!str(x.purpose)||!Array.isArray(x.featureIds)||Math.abs(x.start-end)>.035||!(x.end>x.start)||x.end>30.001)fail('post15 copy beats continuously cover15–30 with concrete purposes');for(const id of x.featureIds){if(!b.features.some(f=>f.id===id))fail('copy beat refers to unknown benefit');if(i<2)ids.add(id)}end=x.end}
 if(Math.abs(end-30)>.035||ids.size!==2)fail('both sourced benefits must appear in the first two post15 beats');
 if(b.narration.length<7)fail('full30s narration needs at least7 naturally paced lines');
 const words=b.narration.map(n=>n.ttsText||n.text).join(' ').trim().split(/\s+/).filter(Boolean).length;if(/^en/.test(b.voice?.language||'en')&&(words<55||words>72))fail('English narration needs55–72 spoken words; use ttsText for numbers');
 if(!['minPost15SpokenSec','maxPost15SilentGapSec','minPost15Lines','minTotalSpokenSec'].every(k=>Number.isFinite(q[k])))fail('explicit finite narration quality thresholds required');
 if(q.minPost15SpokenSec<10.5||q.maxPost15SilentGapSec>1.3||q.minPost15Lines<4||q.minTotalSpokenSec<20)fail('do not lower full-narration coverage thresholds');
 return checkCoverage(b,b.narration);
}
function checkCoverage(b,lines){if(b.qualityPolicy.narrationMode!=='full')return true;const q=b.qualityPolicy,post=coverage(lines),all=coverage(lines,0,30);if(post.spoken+0.035<q.minPost15SpokenSec||post.gap>q.maxPost15SilentGapSec+.035||post.lines<q.minPost15Lines||all.spoken+.035<q.minTotalSpokenSec)fail(`narration has gaps: post15=${post.spoken.toFixed(2)}s/${post.lines}lines, max gap=${post.gap.toFixed(2)}s, total=${all.spoken.toFixed(2)}s; rewrite or re-time, do not speed up`);return true}
module.exports={policy,checkCoverage,coverage};
