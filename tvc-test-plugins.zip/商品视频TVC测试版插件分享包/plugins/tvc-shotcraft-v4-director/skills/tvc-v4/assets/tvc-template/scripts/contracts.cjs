const fs=require('fs'),path=require('path'),crypto=require('crypto');
const stable=v=>{const sort=x=>x&&typeof x==='object'?Array.isArray(x)?x.map(sort):Object.fromEntries(Object.keys(x).sort().map(k=>[k,sort(x[k])])):x;return JSON.stringify(sort(v))};
const hash=f=>crypto.createHash('sha256').update(fs.readFileSync(f)).digest('hex');
function file(root,rel){if(typeof rel!=='string'||!rel||path.isAbsolute(rel))throw Error('Expected relative project file: '+rel);const base=fs.realpathSync(root),f=path.resolve(base,rel);if(!f.startsWith(base+path.sep)||!fs.existsSync(f)||!fs.statSync(f).isFile()||!fs.realpathSync(f).startsWith(base+path.sep))throw Error('Missing/unsafe file: '+rel);return f}
module.exports={stable,hash,file};
