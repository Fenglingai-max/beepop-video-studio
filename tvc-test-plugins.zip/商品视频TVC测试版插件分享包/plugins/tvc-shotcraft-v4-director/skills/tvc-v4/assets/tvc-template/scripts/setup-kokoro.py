"""Install isolated Kokoro runtime and verified model files in a work project."""
import argparse, hashlib, json, os, shutil, subprocess, sys, urllib.request, venv
from pathlib import Path


def digest(p):
    h = hashlib.sha256()
    with p.open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def main():
    a = argparse.ArgumentParser()
    a.add_argument('--project', required=True)
    a.add_argument('--runtime-python', help='Use an existing Python virtual environment; validate/install pinned dependencies there')
    a.add_argument('--models-from', help='Offline directory containing both official model files')
    args = a.parse_args()
    if not (3, 12) <= sys.version_info[:2] <= (3, 13):
        raise ValueError('Use Python 3.12–3.13; recommended Python 3.12')
    project = Path(args.project).resolve()
    if not (project / 'product.json').is_file():
        raise ValueError('Create a work project first; product.json is required')
    runtime = project / '.tvc-voice'
    env = runtime / 'venv'
    python = Path(args.runtime_python).absolute() if args.runtime_python else env / ('Scripts/python.exe' if os.name == 'nt' else 'bin/python')
    if args.runtime_python and not python.is_file():
        raise ValueError('Existing runtime Python not found')
    if not args.runtime_python and not python.exists():
        venv.EnvBuilder(with_pip=True).create(env)
    probe = subprocess.run([str(python), '-c', 'import json,sys; print(json.dumps({"virtual":sys.prefix!=sys.base_prefix,"version":list(sys.version_info[:2])}))'], capture_output=True, text=True, check=True)
    info = json.loads(probe.stdout)
    if not info['virtual'] or not [3, 12] <= info['version'] <= [3, 13]:
        raise ValueError('Use an isolated Python 3.12–3.13 virtual environment; refusing global install')
    req = Path(__file__).with_name('requirements-kokoro.txt')
    subprocess.run([str(python), '-m', 'pip', 'install', '--disable-pip-version-check', '-r', str(req)], check=True)
    models = runtime / 'models'
    models.mkdir(parents=True, exist_ok=True)
    specs = json.loads(Path(__file__).with_name('kokoro-models.json').read_text())
    for name, spec in specs.items():
        target = models / name
        if target.exists():
            if digest(target) != spec['sha256']:
                raise ValueError(f'{target} checksum mismatch; preserve it and use a clean project')
            continue
        tmp = target.with_suffix(target.suffix + '.download')
        try:
            if args.models_from:
                shutil.copyfile(Path(args.models_from) / name, tmp)
            else:
                print('Downloading verified upstream model:', name, flush=True)
                request = urllib.request.Request(spec['url'], headers={'User-Agent': 'TVC-Kokoro/2.0.2'})
                with urllib.request.urlopen(request, timeout=120) as response, tmp.open('wb') as f:
                    shutil.copyfileobj(response, f, length=1024 * 1024)
            if digest(tmp) != spec['sha256']:
                raise ValueError(f'{name} SHA256 mismatch; refusing this model')
            tmp.replace(target)
        finally:
            if tmp.exists():
                tmp.unlink()
    subprocess.run([str(python), '-c', 'import kokoro_onnx, soundfile, numpy'], check=True)
    (runtime / 'runtime.json').write_text(json.dumps({'python': str(python)}, indent=2))
    print(json.dumps({'status': 'ready', 'python': str(python), 'modelDir': str(models), 'voice': 'af_heart'}, ensure_ascii=False))


if __name__ == '__main__':
    try:
        main()
    except Exception as e:
        print(f'Kokoro setup failed: {e}\nNo system TTS fallback was used.', file=sys.stderr)
        sys.exit(1)
