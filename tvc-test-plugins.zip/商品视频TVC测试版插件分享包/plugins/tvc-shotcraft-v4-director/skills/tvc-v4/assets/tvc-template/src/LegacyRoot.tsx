import React,{useEffect,useLayoutEffect,useRef,useState} from 'react';
import {AbsoluteFill,Audio,Composition,OffthreadVideo,Sequence,staticFile,useCurrentFrame,useVideoConfig,delayRender,continueRender,cancelRender} from 'remotion';
import initial from '../brief.json';
// @ts-ignore Shared native Remotion canvas engine; no information-card fallback.
import engine from '../public/motion-engine';
const Film:React.FC<any>=(d)=>{
 const frame=useCurrentFrame(),{fps}=useVideoConfig(),t=frame/fps,ref=useRef<HTMLCanvasElement>(null),[images,setImages]=useState<Record<string,HTMLImageElement>>({}),[handle]=useState(()=>delayRender('Load product and independent scene images'));
 const assets=[...new Set<string>([d.heroAsset,...d.features.map((f:any)=>f.asset),...d.scenes.map((s:any)=>s.asset)].filter(Boolean))];
 useEffect(()=>{let live=true;Promise.all(assets.map(asset=>new Promise<[string,HTMLImageElement]>((resolve,reject)=>{const im=new Image();im.onload=()=>resolve([asset,im]);im.onerror=()=>reject(Error('Missing '+asset));im.src=staticFile(asset)}))).then(items=>{if(live)setImages(Object.fromEntries(items))}).catch(cancelRender);return()=>{live=false}},[assets.join('|')]);
 useLayoutEffect(()=>{if(!ref.current||!images[d.heroAsset])return;try{engine.draw(ref.current.getContext('2d'),t,d,images);continueRender(handle)}catch(e){cancelRender(e)}},[frame,images]);
 return <AbsoluteFill style={{background:d.design.background}}><Sequence from={0} durationInFrames={15*fps}><OffthreadVideo src={staticFile(d.story.asset)} muted style={{width:'100%',height:'100%',objectFit:'contain'}}/></Sequence><canvas ref={ref} width={1920} height={1080} style={{position:'absolute',width:'100%',height:'100%'}}/>{d.renderAudio!==false&&d.audioMixAsset&&<Audio src={staticFile(d.audioMixAsset)}/>}</AbsoluteFill>
};
export const Root:React.FC=()=> <Composition id="TVC4" component={Film} width={1280} height={720} fps={24} durationInFrames={720} defaultProps={initial as any} calculateMetadata={({props}:any)=>({width:props.composition.width,height:props.composition.height,fps:props.composition.fps,durationInFrames:30*props.composition.fps})}/>;
