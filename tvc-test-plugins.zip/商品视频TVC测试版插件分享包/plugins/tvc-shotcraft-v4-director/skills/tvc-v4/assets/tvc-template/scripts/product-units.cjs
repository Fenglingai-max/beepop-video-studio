const fs=require('fs');
function validate(b,{ready=false,root}={}){
 const u=b.productUnderstanding,required=['4.0.0','4.1.0'].includes(b.version);if(!u){if(required)throw Error('Product understanding required before planning');return;}
 const str=x=>typeof x==='string'&&x.trim(),count=x=>Number.isInteger(x)&&x>0;
 if(!str(u.category)||!count(u.referenceUnitCount)||!['single','pair','set','unknown'].includes(u.saleUnit)||!['single','pair','set','unknown'].includes(u.useUnit)||!count(u.heroUnitCount)||!count(u.endingUnitCount)||!str(u.decisionSource))throw Error('Fill product category, reference/use/sale units, display counts and evidence');
 const override=u.displayPolicy==='user-specified';if(u.displayPolicy&&!['complete-unit','user-specified'].includes(u.displayPolicy)||override&&!str(u.displayReason))throw Error('User-specified display needs the explicit user request');
 const c=u.completion;if(!c||typeof c.required!=='boolean'||!str(c.reason)||!['not-required','planned','ready'].includes(c.status)||!Array.isArray(c.assets))throw Error('Fill product completion decision');
 const shots=b.scriptPlan?.shots||[],scenes=b.scriptPlan?.scenePlans||[];
 if([...shots,...scenes].some(s=>!count(s.productUnitCount)))throw Error('Each shot/scene needs planned productUnitCount');
 if(u.useUnit==='pair'&&!override){
  if(u.heroUnitCount!==2||u.endingUnitCount!==2||shots.find(s=>s.narrativeRole==='product')?.productUnitCount!==2||!shots.some(s=>s.includesUseScene&&s.productUnitCount===2))throw Error('Pair product requires paired hero, ending and at least one paired use shot');
  if(u.referenceUnitCount<2&&!c.required)throw Error('Single reference for pair product needs explicit completion');
 }
 if(c.required&&c.status==='not-required')throw Error('Completion requirement contradicts its status');
 if(ready&&c.required){if(u.useUnit==='pair'&&!override&&!c.assets.includes(b.heroAsset))throw Error('Paired completed reference must replace the single-item hero');if(c.status!=='ready'||!c.assets.length)throw Error('Complete and review product references before production');reviewCompletion(b,root);}
}
function prompt(b){const u=b.productUnderstanding;if(!u)return '';return `商品单位：参考图${u.referenceUnitCount}件，使用关系${u.useUnit}，销售单位${u.saleUnit}；识别主图${u.heroUnitCount}件、收尾${u.endingUnitCount}件。依据：${u.decisionSource}。补全状态${u.completion.status}，补全参考${u.completion.assets.join('、')||'待准备'}。原图锁定款式事实，补图锁定配对构图，不能镜像字样或新增无依据部件。${u.completion.uncertainty||''}`;}
function reviewCompletion(b,root){
 const {file,hash}=require('./contracts.cjs'),u=b.productUnderstanding,c=u.completion,r=JSON.parse(fs.readFileSync(file(root,c.reviewRecord)));
 if(r.reviewed!==true||!r.evidence||!Array.isArray(r.assets)||!r.sourceReferences?.length)throw Error('Completion needs a real review and source references');file(root,r.evidence);
 for(const source of r.sourceReferences)if(source.sha256!==hash(file(root,'public/'+source.asset)))throw Error('Completion reference hash changed');
 for(const a of c.assets){const output=r.assets.find(x=>x.asset===a);if(!output||output.sha256!==hash(file(root,'public/'+a))||output.inferred!==true||!output.notes?.trim()||!output.pairingRelation?.trim()||(u.useUnit==='pair'&&u.displayPolicy!=='user-specified'&&output.productUnitCount!==2))throw Error('Completion must document actual count, inferred anatomy, identity and asset hash');}
}
module.exports={validate,prompt,reviewCompletion};
