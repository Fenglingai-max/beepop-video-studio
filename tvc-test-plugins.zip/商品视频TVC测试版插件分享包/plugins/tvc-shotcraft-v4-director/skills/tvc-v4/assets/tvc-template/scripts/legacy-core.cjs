const fs=require('fs'),path=require('path'),crypto=require('crypto');
const {file,hash,stable}=require('./contracts.cjs');
const fail=m=>{throw Error('TVC4: '+m)},str=x=>typeof x==='string'&&x.trim().length>0,num=x=>Number.isFinite(x),near=(a,b)=>Math.abs(a-b)<.035;
const sha=x=>crypto.createHash('sha256').update(typeof x==='string'?x:stable(x)).digest('hex');
const read=(root,rel)=>JSON.parse(fs.readFileSync(file(root,rel),'utf8'));
const pub=(root,rel)=>file(path.join(root,'public'),rel);
function required(o,keys,label){for(const k of keys)if(!str(o?.[k]))fail(label+'.'+k+' required');}
function plan(b){
 if(b.version!=='4.0.0'||b.productionProfile!=='hybrid30-video15'||b.durationSec!==30||b.videoDurationSec!==15)fail('profile must be4.0.0 / hybrid30-video15 /30s=15+15');
 required(b,['productName','description','heroAsset'],'brief');if(b.factsReviewed!==true)fail('read actual product facts first');
 const c=b.composition;if(!c||![24,25,30,50,60].includes(c.fps)||!Number.isInteger(c.width)||!Number.isInteger(c.height)||c.width<320||c.height<320||c.width%2||c.height%2)fail('valid even composition size/fps required');
 const r=b.productionRequirements;if(!r||r.story!=='generated-video'||r.minStoryShots!==6||r.maxStoryShots!==6||r.useScenesMin!==2||r.useScenesMax!==3||r.facesInHumanUseShots!==true||r.sceneImages!==2||r.scenes!=='independently-generated'||r.handoffSec!==15)fail('lock6shots,2–3use scenes,faces,2independent images,15s handoff');
 require('./asset-plan.cjs').validate(b);require('./product-units.cjs').validate(b);
 if(!Array.isArray(b.features)||b.features.length!==2||new Set(b.features.map(x=>x.id)).size!==2)fail('two sourced features required');
 b.features.forEach(f=>required(f,['id','title','fact','benefit','source'],'feature'));
 const s=b.scriptPlan;required(s?.brandDirection,['proposition','visualMotif','lighting','rhythm','memoryBeat'],'brandDirection');
 if(!Array.isArray(s.productLocks)||s.productLocks.length<2||s.productLocks.some(x=>!str(x)))fail('product structure/color/unit locks required');
 if(!Array.isArray(s.cast))fail('cast must be an explicit array');const castIds=new Set();
 for(const person of s.cast){required(person,['id','appearance','wardrobe'],'cast');if(castIds.has(person.id))fail('duplicate cast');castIds.add(person.id);}
 if(!Array.isArray(s.shots)||s.shots.length!==6)fail('exactly6planned shots required');let end=0;const ids=new Set();
 for(const [i,x]of s.shots.entries()){
  required(x,['shotId','narrativeRole','visual','framing','camera','action','result','newInformation','environment','transition'],'shot');
  if(!['product','use','detail'].includes(x.narrativeRole)||ids.has(x.shotId)||!num(x.start)||!num(x.end)||!near(x.start,end)||x.end-x.start<1.5||x.end-x.start>3.5||x.end>15.001)fail('six unique1.5–3.5s shots continuously cover0–15');
  if(i===0?x.transition!=='opening':!['cut','match-cut'].includes(x.transition))fail('real cuts required; continuous digital crop is not a shot');
  if(i>0)required(x,['editConnection'],'shot');
  if(x.productVisible!==true||!Number.isInteger(x.productUnitCount)||x.productUnitCount<1||typeof x.peoplePresent!=='boolean'||!Array.isArray(x.castIds)||x.castIds.some(id=>!castIds.has(id))||new Set(x.castIds).size!==x.castIds.length)fail('shot product counts, people and cast bindings required');
  if(x.peoplePresent!==Boolean(x.castIds.length))fail('peoplePresent must agree with actual cast');
  if(x.includesUseScene!==(x.narrativeRole==='use'))fail('use role and includesUseScene must agree; do not relabel use as detail');
  if(x.narrativeRole==='use'){
   required(x,['sceneId','contextKey','useTask'],'use shot');
   if(x.peoplePresent){required(x.facePlan,['framing','visibilityRule'],'facePlan');if(x.facePlan.required!==true||!num(x.facePlan.minVisibleSec)||x.facePlan.minVisibleSec<1||x.facePlan.minVisibleSec>x.end-x.start)fail('human use shot requires clear face+product for>=1s');}
  }
  if(x.narrativeRole==='detail'&&!b.features.some(f=>f.id===x.featureId))fail('detail shot must bind sourced feature');
  end=x.end;ids.add(x.shotId);
 }
 if(!near(end,15))fail('video must end at15s');
 const first=s.shots[0],last=s.shots[5],use=s.shots.filter(x=>x.narrativeRole==='use');
 if(first.narrativeRole!=='product'||first.fullProductVisible!==true||first.introMotion!=='small-orbit'||!num(first.fullReadSec)||first.fullReadSec<.8||first.fullReadSec>first.end-first.start)fail('intro must show complete product first then small supported orbit');
 if(!str(first.orbitEvidence)||!num(first.orbitDegrees)||first.orbitDegrees<5||first.orbitDegrees>30)fail('intro needs5–30degree reference-supported front-side arc, not invented360 back');
 if(last.narrativeRole!=='product'||last.fullProductVisible!==true||!num(last.stableHandoffSec)||last.stableHandoffSec<.5)fail('last video shot must hand off complete product stably');
 if(use.length<2||use.length>3||new Set(use.map(x=>x.sceneId)).size!==use.length||new Set(use.map(x=>x.contextKey)).size!==use.length)fail('2–3 genuinely different use scenes in first15s required');
 if(first.productUnitCount!==b.productUnderstanding.heroUnitCount||last.productUnitCount!==b.productUnderstanding.endingUnitCount)fail('hero/ending unit counts must match product understanding');
 if(!s.shots.some(x=>x.narrativeRole==='detail'))fail('sourced detail shot required');
 if(!Array.isArray(s.scenePlans)||s.scenePlans.length!==2)fail('two independent Remotion scene plans required');
 for(const x of s.scenePlans){required(x,['sceneId','purpose','setting','framing'],'scenePlan');if(typeof x.peoplePresent!=='boolean'||!Array.isArray(x.castIds)||x.castIds.some(id=>!castIds.has(id))||x.peoplePresent!==Boolean(x.castIds.length))fail('scene cast/people binding required');if(x.peoplePresent&&x.facesRequired!==true)fail('people in use-scene image must show clear face');}
 if(new Set(s.scenePlans.map(x=>x.sceneId)).size!==2||s.scenePlans[0].setting===s.scenePlans[1].setting&&s.scenePlans[0].purpose===s.scenePlans[1].purpose)fail('independent scenes must have distinct purpose/context');
 const rp=b.remotionPlan;if(!rp||rp.detailMotion!=='full-canvas'||!num(rp.productRevealSec)||rp.productRevealSec<.8||rp.productRevealSec>1.2||rp.handoff!=='cut')fail('full canvas,complete0.8–1.2s read and direct15s handoff required');
 if(!Array.isArray(rp.blocks)||rp.blocks.length!==5)fail('five Remotion blocks required');let re=15;const types=['feature','feature','scene','scene','ending'];
 for(const [i,x]of rp.blocks.entries()){
  if(x.type!==types[i]||!num(x.start)||!num(x.end)||!near(x.start,re)||x.end<=x.start||x.end>30.001)fail('Remotion continuously covers15–30s in feature/feature/scene/scene/ending order');
  if(x.type==='feature'&&!b.features.some(f=>f.id===x.featureId))fail('Remotion feature binding missing');
  if(x.type==='scene'&&(!s.scenePlans.some(q=>q.sceneId===x.sceneId)||x.end-x.start<1.5))fail('independent scene display>=1.5s');
  if(x.type==='ending'&&x.end-x.start<2)fail('full-product ending>=2s');re=x.end;
 }
 if(!near(re,30)||rp.blocks[0].featureId===rp.blocks[1].featureId||rp.blocks[2].sceneId===rp.blocks[3].sceneId)fail('two distinct features/scenes must end at30s');
 if(!Array.isArray(b.narration))fail('narration must be an explicit array');let ne=0;
 for(const n of b.narration){required(n,['text'],'narration');if(!num(n.start)||!num(n.end)||n.start<ne-.001||n.end<=n.start||n.end>30||!num(n.maxDurationSec)||n.maxDurationSec<n.end-n.start-.035)fail('natural narration must fit disjoint0–30s slots');ne=n.end;}
 const words=b.narration.map(n=>n.text).join(' ').trim().split(/\s+/).filter(Boolean).length;if(words>72)fail('30s narration exceeds72words: shorten, do not accelerate');
 for(const x of [...s.shots,...rp.blocks])for(const key of ['captionBox','titleBox'])if(x[key]){const q=x[key];if(!['left','top','width'].every(k=>num(q[k]))||q.left<0||q.top<0||q.width<=0||q.width>1||q.left+q.width>1||q.top>=.95)fail('normalized safe caption/title boxes required');}
 if(!b.design||!['background','ink','captionColor','fontFamily'].every(k=>str(b.design[k])))fail('design colors and font required');
 if(b.voice&&(!num(b.voice.speed)||b.voice.speed<.9||b.voice.speed>1.1||b.voice.mode!=='kokoro'))fail('natural Kokoro voice speed0.9–1.1 required');
 require('./requirements.cjs').policy(b);
 return true;
}
function planFingerprint(b){const shots=b.scriptPlan.shots.map(({headline,titleBox,captionBox,...shot})=>shot);return sha({version:b.version,productName:b.productName,description:b.description,features:b.features.map(({id,fact,source})=>({id,fact,source})),assetPlan:b.assetPlan,scalePhysical:b.scalePlan.physical,units:b.productUnderstanding,scriptPlan:{...b.scriptPlan,shots},generationPlan:b.generationPlan});}
function sourceBindings(b,root){return b.assetPlan.sources.map(x=>x.kind==='text'?{id:x.id,textSha256:sha(x.text)}:{id:x.id,asset:x.asset,sha256:hash(pub(root,x.asset))});}
function ready(b,root){plan(b);require('./asset-plan.cjs').validate(b,{root,ready:true});require('./product-units.cjs').validate(b,{root,ready:true});const g=b.generationPlan;required(g,['provider','model','resolution','authorizationSource'],'generationPlan');if(g.durationSec!==15||!Number.isInteger(g.maxSubmissions)||g.maxSubmissions<1)fail('15s generation and authorized submission count required');return {status:'ready_not_submitted',planFingerprint:planFingerprint(b),references:sourceBindings(b,root),hero:{asset:b.heroAsset,sha256:hash(pub(root,b.heroAsset))},authorization:g.authorizationSource};}
function prompt(b){
 plan(b);const s=b.scriptPlan,u=b.productUnderstanding;const locks=s.productLocks.join('；');
 const refs=b.assetPlan.sources.map(x=>x.kind==='text'?x.id+'规格原文：'+x.text:x.asset+'（'+x.role+'）').join('；');
 const global=`参考用途：${refs}。主展示参考${b.heroAsset}锁定商品事实；补全图只补足组合，辅助图不直接当成品画面。制作15秒${b.composition.width>=b.composition.height?'横屏':'竖屏'}商品TVC，恰好六个不同机位或景别的实际摄影镜头、五次清晰硬切。每镜平均约2.5秒，节奏快且可读，不用数字裁切冒充新镜头。商品：${b.productName}；事实：${b.description}。${b.features.map(f=>f.fact+'（依据：'+f.source+'）').join('；')}。商品单位：${require('./product-units.cjs').prompt(b)}。结构锁定：${locks}。定调：${Object.values(s.brandDirection).join('；')}。人物连续性：${s.cast.map(x=>x.id+' '+x.appearance+'，服装'+x.wardrobe).join('；')||'无人物'}。真实使用比例：${b.scalePlan.physical.evidence}；${b.scalePlan.physical.wearingRule}。原图中的说明文字、尺寸线、边框只作资料，不出现在广告。`;
 const shots=s.shots.map((x,i)=>`${i===0?'开场第1镜':'明确硬切第'+(i+1)+'镜'}：${x.visual}。环境${x.environment}；${x.framing}；运镜${x.camera}；动作${x.action}；结果${x.result}；新增信息${x.newInformation}。商品${x.productUnitCount}件。${x.narrativeRole==='use'?'真实使用情境：'+x.useTask+'。':''}${x.peoplePresent?'人物'+x.castIds.join('、')+'，身份衣着保持一致。':''}${x.narrativeRole==='use'&&x.peoplePresent?'必须清楚看到每位主要使用者的人脸与商品使用关系至少1秒；'+x.facePlan.framing+'；'+x.facePlan.visibilityRule+'。不能只拍手、腰、背影或远处虚脸。':''}${i===0?'先完整稳读'+x.fullReadSec+'秒，再以'+x.orbitDegrees+'度小幅前侧环绕，不生成参考没有的背面。':''}${i>0?'切镜承接：'+x.editConnection+'。':''}${i===5?'最后至少0.5秒完整产品稳住，不淡黑。':''}`);
 return [global,...shots,'仅此六镜，2–3个不同使用情境不是同次动作换景别。细节只展示有依据的结构，不虚构性能、拆装或配件。无文字、字幕、Logo叠字、水印、配音或音乐，后期另加。'].join('\n\n');
}
function writePlan(b,root){plan(b);const p={status:'planned_not_generated',profile:b.productionProfile,planFingerprint:planFingerprint(b),durationSec:30,videoDurationSec:15,plannedShotCount:6,shots:b.scriptPlan.shots,remotion:b.remotionPlan.blocks,videoPrompt:prompt(b),scenePrompts:b.scriptPlan.scenePlans.map((x,i)=>`独立生成场景图${i+1} ${x.sceneId}：${x.purpose}；${x.setting}；${x.framing}。商品${b.productName}，数量${x.productUnitCount}，保持${b.scriptPlan.productLocks.join('；')}。真实比例${b.scalePlan.physical.wearingRule}。${x.peoplePresent?'使用者'+x.castIds.join('、')+'清楚露脸，脸/手/产品不遮挡。':'无人物。'}无文字与尺寸标尺。不能用视频截图、另一图裁切或改名替代。`)};
 for(const [name,data]of [['生成脚本.json',JSON.stringify(p,null,2)],['视频生成提示词.txt',p.videoPrompt],['生成脚本.md',`# 30秒商品导演脚本\n\n前15秒六镜生成视频；后15秒Remotion。以下为规划，不代表模型或验收已完成。\n\n${b.scriptPlan.shots.map(x=>`- ${x.start}–${x.end}s ${x.shotId} ${x.narrativeRole}：${x.visual}；${x.camera}`).join('\n')}\n\n${b.remotionPlan.blocks.map(x=>`- ${x.start}–${x.end}s Remotion ${x.type}`).join('\n')}`],...p.scenePrompts.map((x,i)=>[`场景图${i+1}生成提示词.txt`,x])])fs.writeFileSync(path.join(root,name),data+'\n');return p;}
function bound(root,x,publicAsset=false){if(!str(x?.sha256)||x.sha256!==hash(publicAsset?pub(root,x.asset):file(root,x.file)))fail('missing/stale evidence hash '+(x?.asset||x?.file));}
function evidence(root,x,{start,end}={}){bound(root,x);if(!num(x.atSourceSec)||start!==undefined&&(x.atSourceSec<start-.035||x.atSourceSec>end+.035))fail('evidence frame is outside reviewed source interval');}
function face(root,review,planned,start,end){
 if(!planned.peoplePresent||planned.narrativeRole==='detail')return;
 if(review?.status!=='passed'||!Array.isArray(review.subjects)||review.subjects.length!==planned.castIds.length)fail('each human user needs actual face review');
 const ids=new Set();for(const x of review.subjects){if(!planned.castIds.includes(x.castId)||ids.has(x.castId)||!num(x.visibleForSec)||x.visibleForSec<(planned.facePlan?.minVisibleSec||1)||x.visibleForSec>end-start+.035||x.faceClear!==true||x.productRelationVisible!==true||!str(x.observations))fail('actual face must be clear with product relationship for>=1s');evidence(root,x.evidence,{start,end});ids.add(x.castId);}
}
function technicalMedia(b,root){
 const {probe}=require('./media.cjs');const v=probe(root,b.story.asset),stream=v.streams.find(x=>x.codec_type==='video');if(!stream||+v.format.duration<14.96)fail('source must include15s real video');
 if(!Array.isArray(b.story.segments)||b.story.segments.length!==6)fail('actual story needs6segments');let e=0,se=0;
 for(const [i,x]of b.story.segments.entries()){
  if(x.shotId!==b.scriptPlan.shots[i].shotId||!num(x.start)||!num(x.end)||!near(x.start,e)||x.end-x.start<1||x.end-x.start>4.5||!num(x.sourceStart)||!num(x.sourceEnd)||!near(x.sourceStart,se)||!near(x.sourceEnd-x.sourceStart,x.end-x.start)||x.sourceEnd>+v.format.duration+.035||x.playbackRate!==undefined&&x.playbackRate!==1||x.crop!==undefined)fail('actual6 contiguous source shots, original speed, no crop-split or reordered footage');e=x.end;se=x.sourceEnd;
 }
 if(!near(e,15))fail('actual video coverage must end15s');
 if(!Array.isArray(b.scenes)||b.scenes.length!==2||new Set(b.scenes.map(x=>x.sceneId)).size!==2)fail('two scene assets required');
 const referenceHashes=new Set(b.assetPlan.sources.filter(x=>x.kind!=='text').map(x=>hash(pub(root,x.asset))));const imageHashes=new Set();
 for(const s of b.scenes){if(!b.scriptPlan.scenePlans.some(x=>x.sceneId===s.sceneId))fail('scene asset not planned');const m=probe(root,s.asset);if(!m.streams.some(x=>x.codec_type==='video'))fail('scene must decode as image');if(!/\.(png|jpe?g|webp)$/i.test(s.asset))fail('independent scene must be image');const h=hash(pub(root,s.asset));if(imageHashes.has(h)||referenceHashes.has(h)||h===hash(pub(root,b.heroAsset)))fail('scene cannot be copied from another scene/reference/main image');imageHashes.add(h);}
 const mix=probe(root,b.audioMixAsset);if(!mix.streams.some(x=>x.codec_type==='audio')||Math.abs(+mix.format.duration-30)>.08)fail('mixed audio must be30s');
 if(b.qualityPolicy.narrationMode==='full'&&b.narration.length<7)fail('at least7 natural narration lines required');
 for(const n of b.narration){required(n,['asset'],'narration');const m=probe(root,n.asset);if(!m.streams.some(x=>x.codec_type==='audio')||+m.format.duration>n.end-n.start+.12||+m.format.duration>n.maxDurationSec+.12||n.start+ +m.format.duration>30.035)fail('voice must fit actual slot; no cut-off/overlap');}
 require('./requirements.cjs').checkCoverage(b,b.narration.map(n=>({...n,end:n.start+ +probe(root,n.asset).format.duration})));
 required(b.music,['asset','source'],'music');if(+probe(root,b.music.asset).format.duration<29.96)fail('music must cover30s, no silent fallback');return true;
}
function actual(b,root){
 ready(b,root);technicalMedia(b,root);const gen=read(root,b.story.generationRecord),vhash=hash(pub(root,b.story.asset));
 if(gen.type!=='generated-video'||gen.planFingerprint!==planFingerprint(b)||gen.output?.asset!==b.story.asset||gen.output.sha256!==vhash||!Array.isArray(gen.requests)||gen.requests.length<1||gen.requests.length>b.generationPlan.maxSubmissions||gen.submittedThisRound!==gen.requests.length||!Number.isInteger(gen.submittedCumulative)||gen.submittedCumulative<gen.submittedThisRound)fail('generation provenance must bind plan/output and honest submission counts');
 for(const req of gen.requests){required(req,['id','provider','model','resolution','accountAlias','submittedAt','authorizationSource'],'generation request');if(req.provider!==b.generationPlan.provider||req.durationSec!==15||req.model!==b.generationPlan.model||req.resolution!==b.generationPlan.resolution||!['known','unknown','free-entitlement'].includes(req.charge?.status))fail('request model/resolution/duration/charge status mismatch');if(req.charge.status==='known'&&(!num(req.charge.amount)||req.charge.amount<0||!str(req.charge.unit)))fail('known cost needs actual amount/unit');if(stable(req.references)!==stable(sourceBindings(b,root))||req.heroSha256!==hash(pub(root,b.heroAsset)))fail('generation references changed');}
 const r=read(root,b.story.reviewRecord);if(r.status!=='passed'||r.reviewed!==true||r.sourceSha256!==vhash||r.generationRecordSha256!==hash(file(root,b.story.generationRecord))||!Array.isArray(r.shots)||r.shots.length!==6)fail('real six-shot review bound to actual source and generation record required');
 for(const [i,x]of b.story.segments.entries()){
  const q=r.shots[i],p=b.scriptPlan.shots[i];if(q.shotId!==x.shotId||!near(q.sourceStart,x.sourceStart)||!near(q.sourceEnd,x.sourceEnd)||q.cutIn!==(i?'actual-cut':'opening')||q.identity!=='passed'||q.physicalScale!=='passed'||q.productUnitCount!==p.productUnitCount||q.narrativeRole!==p.narrativeRole||!str(q.observations)||q.continuousCropSplit!==false)fail('actual shot must have observed cut/identity/scale/unit/narrative evidence');
  evidence(root,q.evidence,{start:x.sourceStart,end:x.sourceEnd});if(i){const ce=q.cutEvidence;if(!ce)fail('actual cut requires before/after frame evidence');evidence(root,ce.before,{start:Math.max(0,x.sourceStart-.25),end:x.sourceStart});evidence(root,ce.after,{start:x.sourceStart,end:x.sourceStart+.25});if(ce.before.atSourceSec>=x.sourceStart||ce.after.atSourceSec<x.sourceStart||ce.before.sha256===ce.after.sha256)fail('cut evidence must straddle boundary with distinct frames');}if(p.narrativeRole==='use'&&(q.useSceneVerified!==true||q.contextKey!==p.contextKey||!str(q.visibleUseResult)))fail('actual use must verify distinct planned context and result');if(i===0&&q.fullProductVisible!==true||i===5&&(q.fullProductVisible!==true||q.stableHandoffSec<.5))fail('actual complete opening/steady ending required');if(p.peoplePresent&&q.castContinuity!=='passed')fail('review actual cast identity and wardrobe continuity');face(root,q.faceReview,p,x.sourceStart,x.sourceEnd);
 }
 if(r.handoff?.status!=='passed'||!str(r.handoff.observations))fail('review actual15s cut for direction/scale/brightness continuity');
 const sceneRequestIds=new Set();for(const s of b.scenes){
  const q=read(root,s.generationRecord),p=b.scriptPlan.scenePlans.find(x=>x.sceneId===s.sceneId),h=hash(pub(root,s.asset));
  if(q.type!=='generated-image'||q.sceneId!==s.sceneId||!str(q.requestId)||sceneRequestIds.has(q.requestId)||q.output?.asset!==s.asset||q.output.sha256!==h||q.independentlyGenerated!==true||q.fromVideoFrame!==false||!str(q.provider)||!str(q.sourceDescription)||!Array.isArray(q.referenceBindings)||!q.referenceBindings.some(x=>x.asset===b.heroAsset&&x.sha256===hash(pub(root,b.heroAsset))))fail('two independently generated images need distinct generation records and honest references');
  sceneRequestIds.add(q.requestId);const rv=read(root,s.reviewRecord);if(rv.status!=='passed'||rv.outputSha256!==h||rv.identity!=='passed'||rv.physicalScale!=='passed'||rv.productUnitCount!==p.productUnitCount||!str(rv.observations))fail('scene identity/scale/unit review missing');evidence(root,rv.evidence);face(root,rv.faceReview,{...p,narrativeRole:'use',facePlan:{minVisibleSec:1}},0,Math.max(1,b.remotionPlan.blocks.find(x=>x.sceneId===s.sceneId).end-b.remotionPlan.blocks.find(x=>x.sceneId===s.sceneId).start));
 }
 const ar=read(root,b.audioReviewRecord);if(ar.mixSha256!==hash(pub(root,b.audioMixAsset))||ar.status!=='passed'||ar.listening!=='passed'||!str(ar.observations)||ar.clippedSamples!==0||!Array.isArray(ar.stems))fail('listen to current voice/music mix and bind actual hashes');
 for(const x of [...b.narration,{asset:b.music.asset}]){const stem=ar.stems.find(q=>q.asset===x.asset);if(!stem||stem.sha256!==hash(pub(root,x.asset)))fail('audio stem hash changed');}
 return true;
}
function walk(dir){return fs.existsSync(dir)?fs.readdirSync(dir,{withFileTypes:true}).flatMap(e=>e.isDirectory()?walk(path.join(dir,e.name)):[path.join(dir,e.name)]):[];}
function inputState(b,root){
 const files=[...walk(path.join(root,'public')),...walk(path.join(root,'src')),...walk(path.join(root,'scripts')),path.join(root,'package.json'),path.join(root,'remotion.config.ts')];
 for(const rel of [b.story.generationRecord,b.story.reviewRecord,b.audioReviewRecord,...b.scenes.flatMap(x=>[x.generationRecord,x.reviewRecord])].filter(Boolean))if(fs.existsSync(path.join(root,rel)))files.push(file(root,rel));
 // Bind frame evidence too; release review is deliberately excluded because it is written after rendering.
 for(const f of [...files])if(f.endsWith('.json')){try{const d=JSON.parse(fs.readFileSync(f));const visit=x=>{if(!x||typeof x!=='object')return;if(str(x.file)&&str(x.sha256)&&fs.existsSync(path.join(root,x.file)))files.push(file(root,x.file));Object.values(x).forEach(v=>Array.isArray(v)?v.forEach(visit):visit(v));};visit(d);}catch(e){if(e.message?.startsWith('Missing/unsafe'))throw e;}}
 const entries=[...new Set(files)].sort().map(f=>({file:path.relative(root,f).split(path.sep).join('/'),sha256:hash(f)}));return {fingerprint:sha({brief:b,files:entries}),files:entries};
}
function prepare(b,root,{preview=false}={}){ready(b,root);if(preview)technicalMedia(b,root);else actual(b,root);const state=inputState(b,root);const out={...b,renderAudio:false,buildInputFingerprint:state.fingerprint,reviewMode:preview?'preview_pending_review':'reviewed_inputs'};const stamp=t=>{let ms=Math.round(t*1000);const h=Math.floor(ms/3600000);ms%=3600000;const m=Math.floor(ms/60000);ms%=60000;const sec=Math.floor(ms/1000);ms%=1000;return [h,m,sec].map(x=>String(x).padStart(2,'0')).join(':')+','+String(ms).padStart(3,'0');};fs.writeFileSync(path.join(root,'台词字幕.srt'),b.narration.map((n,i)=>`${i+1}\n${stamp(n.start)} --> ${stamp(n.end)}\n${n.text}`).join('\n\n')+'\n');fs.writeFileSync(path.join(root,'product.json'),JSON.stringify(out,null,2)+'\n');fs.writeFileSync(path.join(root,'inputs.json'),JSON.stringify(state,null,2)+'\n');return out;}
function release(b,root){actual(b,root);const build=read(root,'build.json');if(build.mode!=='reviewed_inputs'||build.inputFingerprint!==inputState(b,root).fingerprint)fail('reviewed render stale or preview; rebuild');if(build.videoSha256!==hash(file(root,build.video))||build.htmlSha256!==hash(file(root,build.html)))fail('built artifacts changed');const r=read(root,b.releaseReviewRecord);if(r.status!=='passed'||r.videoSha256!==build.videoSha256||r.inputFingerprint!==build.inputFingerprint||!['visual','fullPlayback','fullListening','subtitleSafety','handoff','faces','narrationContinuity','benefitSpecificity','captionUniformity','desktopStyle','playbackCompatibility'].every(k=>r[k]==='passed')||!str(r.observations))fail('bind full final playback/listening/face/subtitle/handoff review to current build');return {status:'accepted',version:b.version,durationSec:30,actualShots:6,sceneImages:2,video:build.video,html:build.html,submittedThisRound:read(root,b.story.generationRecord).submittedThisRound};}
module.exports={plan,ready,prompt,writePlan,planFingerprint,sourceBindings,technicalMedia,actual,inputState,prepare,release,read,pub,sha};
