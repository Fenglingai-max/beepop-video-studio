const legacy=require('./legacy-core.cjs'),modern=require('./adaptive-core.cjs');
const out={};for(const key of Object.keys(modern))out[key]=(...args)=>{const b=args[0];return b?.productionProfile==='adaptive-video10'?modern[key](...args):legacy[key](...args)};
// Utility calls accept root/path rather than brief; keep their original contract.
for(const key of ['read','pub','sha'])out[key]=legacy[key];module.exports=out;
