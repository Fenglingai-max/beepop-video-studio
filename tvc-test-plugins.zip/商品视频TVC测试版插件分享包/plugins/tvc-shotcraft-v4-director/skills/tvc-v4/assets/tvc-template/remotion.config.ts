import {Config} from '@remotion/cli/config';
Config.overrideWebpackConfig(c=>({...c,experiments:{...c.experiments,lazyCompilation:false}}));
