// Source roles, main-product extraction and physical-scale evidence. These checks
// bind declarations to files; they do not infer image semantics or actual sizes.
const fs=require('fs'),path=require('path'),crypto=require('crypto'),{file,hash,stable}=require('./contracts.cjs');
const enabled=b=>['4.0.0','4.1.0'].includes(b.version);
const str=x=>typeof x==='string'&&x.trim().length>0;
const fail=m=>{throw Error('Asset/scale plan: '+m)};
const textHash=text=>crypto.createHash('sha256').update(text,'utf8').digest('hex');
function relativeAsset(a){
 if(!str(a)||path.isAbsolute(a)||a.includes('\\')||a.split('/').some(p=>p==='..'||p==='.'||!p))fail('Use a normalized public-relative asset path');
}
function region(r){return r&&['x','y','w','h'].every(k=>Number.isFinite(r[k]))&&r.x>=0&&r.y>=0&&r.w>0&&r.h>0&&r.x+r.w<=1+1e-9&&r.y+r.h<=1+1e-9;}
const full=r=>region(r)&&Math.abs(r.x)<1e-9&&Math.abs(r.y)<1e-9&&Math.abs(r.w-1)<1e-9&&Math.abs(r.h-1)<1e-9;
function read(root,rel){if(!root)fail('A project root is required for file review');return JSON.parse(fs.readFileSync(file(root,rel),'utf8'));}
function bound(root,v){relativeAsset(v?.asset);if(!str(v.sha256)||v.sha256!==hash(file(path.join(root,'public'),v.asset)))fail('Missing/stale source or output hash: '+v.asset);}
function validate(b,{root,ready=false}={}){
 if(!enabled(b))return true;
 const a=b.assetPlan;if(!a||a.version!==1||!Array.isArray(a.sources)||!a.sources.length)fail('Fill assetPlan version 1 and source roles');
 const ids=new Set(),assets=new Set();
 for(const s of a.sources){
  if(!str(s.id)||ids.has(s.id))fail('Source IDs must be unique');
  if(!['primary','detail-reference','use-reference','spec-reference'].includes(s.role)||!str(s.selectionReason))fail('Each source needs a role and selection reason');
  if(s.kind==='text'){
   if(s.role!=='spec-reference'||!str(s.text)||s.asset!==undefined||s.productRegion!==undefined)fail('Text specifications need spec-reference role and original text, without an image asset/region');
  }else{
   if(s.kind!==undefined&&s.kind!=='image')fail('Image sources may use kind image, while only specifications may use kind text');
   relativeAsset(s.asset);if(assets.has(s.asset))fail('A source asset must have one unambiguous role');
   if(s.productRegion!==undefined&&!region(s.productRegion))fail('Invalid source productRegion');
   assets.add(s.asset);
  }
  ids.add(s.id);
 }
 const primary=a.sources.find(s=>s.id===a.primarySourceId),primaries=a.sources.filter(s=>s.role==='primary');
 if(primaries.length!==1||primary?.role!=='primary'||!region(primary.productRegion))fail('Choose exactly one primary source and its productRegion');
 const display=a.display;if(!display||display.sourceId!==primary.id||!['original','extracted','generated-reconstruction'].includes(display.method))fail('Display must derive from the primary source with an explicit method');
 if(b.version==='4.1.0')require('./cutout.cjs').validatePolicy(display);
 if(display.renderRegion!==undefined&&!region(display.renderRegion))fail('Invalid display renderRegion; use normalized crop coordinates');
 relativeAsset(display.asset);if(display.asset!==b.heroAsset)fail('heroAsset must equal the primary display asset');
 if(display.method==='original'){
  if(display.asset!==primary.asset||!full(primary.productRegion))fail('A collage/subregion primary must be extracted before display; original requires the full source asset');
 }else if(display.asset===primary.asset)fail('Preserve the original source; extraction/reconstruction needs a separate output asset');
 if(!Array.isArray(a.referencePhotoOverrides))fail('referencePhotoOverrides must be an explicit array, empty by default');
 const overrides=new Set();for(const o of a.referencePhotoOverrides){
  if(!o||!assets.has(o.asset)||!str(o.reason)||overrides.has(o.asset))fail('Reference-photo override needs a unique known source asset and explicit user reason');
  if(b.version==='4.1.0'){require('./cutout.cjs').validatePolicy(o);if(o.backgroundPolicy==='cutout-required')fail('Reference-photo overrides need an explicit preserved-background exception; product cutouts use the primary display');}
  overrides.add(o.asset);
 }
 for(const f of b.features||[]){const asset=f.asset||b.heroAsset;relativeAsset(asset);if(asset!==display.asset&&!overrides.has(asset))fail('Feature display must use the primary product asset; reference photos need an explicit override: '+asset);}
 for(const block of b.timeline||[])if(block.type!=='video'&&block.asset){relativeAsset(block.asset);if(block.asset!==display.asset&&!overrides.has(block.asset))fail('Timeline product display must use primary display or a reviewed reference-photo override');}
 const references=new Set(a.sources.filter(s=>s.role!=='primary'&&s.kind!=='text').map(s=>s.asset));
 for(const scene of [...(b.scenes||[]),...(b.shots||[])])if(scene.asset){relativeAsset(scene.asset);if(references.has(scene.asset))fail('A reference-only source cannot masquerade as an independent scene output');}
 const physical=b.scalePlan?.physical;if(!physical||!['verified','relative','unknown'].includes(physical.status)||!Array.isArray(physical.sourceIds)||!str(physical.evidence)||!str(physical.wearingRule))fail('Fill scalePlan physical status, evidence and wearingRule');
 if(new Set(physical.sourceIds).size!==physical.sourceIds.length||physical.sourceIds.some(id=>!ids.has(id)))fail('Physical scale sourceIds must be unique known source IDs');
 const sources=physical.sourceIds.map(id=>a.sources.find(s=>s.id===id));
 if(physical.status==='relative'&&(!sources.length||sources.some(s=>s.role!=='use-reference')))fail('Relative physical scale requires wearing/use-reference sources');
 if(physical.status==='verified'){
  if(!Array.isArray(physical.dimensions)||!physical.dimensions.length)fail('Verified scale requires sourced dimensions');
  for(const d of physical.dimensions){
   if(!str(d.name)||!Number.isFinite(d.value)||d.value<=0||!str(d.unit)||!sources.some(s=>s.id===d.sourceId&&s.role==='spec-reference'))fail('Each verified dimension needs a positive value, unit and bound spec-reference source');
  }
 }else if(physical.dimensions!==undefined)fail('Only verified physical scale can contain numerical dimensions');
 if(ready){
  if(!root)fail('Readiness requires project root');
  a.sources.filter(s=>s.kind!=='text').forEach(s=>file(path.join(root,'public'),s.asset));file(path.join(root,'public'),display.asset);
  // Original, full-frame use needs no reconstruction review. An optional review
  // still binds all declared facts when supplied, rather than being ignored.
  if(display.method!=='original'||str(display.fidelityReviewRecord)){
   if(!str(display.fidelityReviewRecord))fail('Extraction/reconstruction requires fidelityReviewRecord');
   const r=read(root,display.fidelityReviewRecord);
   if(r.reviewed!==true||r.status!=='passed'||r.source?.asset!==primary.asset||r.output?.asset!==display.asset||r.method!==display.method||stable(r.productRegion)!==stable(primary.productRegion)||!str(r.observations))fail('Fidelity review must bind the selected region, source, output, method and actual observations');
   if(display.method==='generated-reconstruction'&&r.lossless===true)fail('Generated reconstruction cannot be declared lossless extraction');
   bound(root,r.source);bound(root,r.output);
  }
  if(b.version==='4.1.0'){const cutout=require('./cutout.cjs');cutout.validate(root,b,display,primary.asset);for(const o of a.referencePhotoOverrides)cutout.validate(root,b,{...o,method:'original'},o.asset);}
  // A renamed copy is still a reference photograph. Scene outputs may be absent
  // at readiness, but any file already present must differ from reference-only
  // image sources by content as well as path.
  const referenceHashes=new Set(a.sources.filter(s=>s.role!=='primary'&&s.kind!=='text').map(s=>hash(file(path.join(root,'public'),s.asset))));
  for(const scene of [...(b.scenes||[]),...(b.shots||[])])if(scene.asset&&fs.existsSync(path.join(root,'public',scene.asset))&&referenceHashes.has(hash(file(path.join(root,'public'),scene.asset))))fail('A renamed reference-only photograph cannot masquerade as an independent scene output');
 }
 return true;
}
module.exports={validate};
