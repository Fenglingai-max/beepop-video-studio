// Archive 4.0 tests use the frozen, valid legacy fixture; never inherit new 4.1
// scaffold defaults (which intentionally require cutout processing).
module.exports=require('../skills/tvc-v4/scripts/tests/fixture.cjs');
