// Schema tests against synthetic local cards/tones. These records are TEST FIXTURES,
// never evidence of a real product generation, human face quality or listening acceptance.
const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('fs'),path=require('path');
const root=process.env.TVC4_FIXTURE;if(!root)throw Error('Set TVC4_FIXTURE to the isolated synthetic integration project');
const core=require(path.join(root,'scripts/core.cjs')),{hash}=require(path.join(root,'scripts/contracts.cjs'));
const b=JSON.parse(fs.readFileSync(path.join(root,'brief.json'))),out=f=>path.join(root,f),j=f=>JSON.parse(fs.readFileSync(out(f))),write=(f,x)=>fs.writeFileSync(out(f),JSON.stringify(x,null,2));
const e=(i,at)=>({file:'public/test-card-'+i+'.png',sha256:hash(out('public/test-card-'+i+'.png')),atSourceSec:at});
const faces=(ev,sec=1)=>({status:'passed',subjects:[{castId:'person-1',visibleForSec:sec,faceClear:true,productRelationVisible:true,observations:'TEST SCHEMA ONLY; not real face inspection',evidence:ev}]});
function reset(){
 const g={type:'generated-video',planFingerprint:core.planFingerprint(b),submittedThisRound:1,submittedCumulative:1,requests:[{id:'TEST-NOT-A-SERVICE-TASK',provider:b.generationPlan.provider,model:b.generationPlan.model,resolution:b.generationPlan.resolution,durationSec:15,accountAlias:'TEST',submittedAt:'2026-11-02T00:00:00Z',authorizationSource:'TEST ONLY',references:core.sourceBindings(b,root),heroSha256:hash(out('public/hero.png')),charge:{status:'unknown'}}],output:{asset:'story.mp4',sha256:hash(out('public/story.mp4'))}};write(b.story.generationRecord,g);
 write(b.story.reviewRecord,{status:'passed',reviewed:true,sourceSha256:g.output.sha256,generationRecordSha256:hash(out(b.story.generationRecord)),handoff:{status:'passed',observations:'TEST SCHEMA ONLY'},shots:b.story.segments.map((s,i)=>({shotId:s.shotId,sourceStart:s.sourceStart,sourceEnd:s.sourceEnd,cutIn:i?'actual-cut':'opening',identity:'passed',physicalScale:'passed',productUnitCount:1,narrativeRole:b.scriptPlan.shots[i].narrativeRole,continuousCropSplit:false,castContinuity:'passed',observations:'TEST SCHEMA ONLY',evidence:e(i,s.sourceStart+.5),...(i?{cutEvidence:{before:e(i-1,s.sourceStart-.05),after:e(i,s.sourceStart+.05)}}:{}),...(i===1||i===2?{useSceneVerified:true,contextKey:b.scriptPlan.shots[i].contextKey,visibleUseResult:'TEST result',faceReview:faces(e(i,s.sourceStart+.5))}:{}),fullProductVisible:true,stableHandoffSec:.5}))});
 for(const [i,s]of b.scenes.entries()){
  write(s.generationRecord,{type:'generated-image',sceneId:s.sceneId,requestId:'TEST-IMAGE-'+i,provider:'LOCAL SYNTHETIC FIXTURE',sourceDescription:'Test PNG illustration. Not actually AI generated; schema fixture only.',independentlyGenerated:true,fromVideoFrame:false,output:{asset:s.asset,sha256:hash(out('public/'+s.asset))},referenceBindings:[{asset:b.heroAsset,sha256:hash(out('public/'+b.heroAsset))}]});
  write(s.reviewRecord,{status:'passed',outputSha256:hash(out('public/'+s.asset)),identity:'passed',physicalScale:'passed',productUnitCount:1,observations:'TEST SCHEMA ONLY',evidence:e(i+1,0),faceReview:faces(e(i+1,0))});
 }
 write(b.audioReviewRecord,{status:'passed',listening:'passed',mixSha256:hash(out('public/'+b.audioMixAsset)),clippedSamples:0,observations:'TEST SCHEMA ONLY; tones were not spoken narration',stems:[...b.narration,b.music].map(s=>({asset:s.asset,sha256:hash(out('public/'+s.asset))}))});
}
function bad(name,record,mutate,re){test(name,()=>{reset();const x=j(record);mutate(x);write(record,x);if(record===b.story.generationRecord){const sr=j(b.story.reviewRecord);sr.generationRecordSha256=hash(out(record));write(b.story.reviewRecord,sr);}assert.throws(()=>core.actual(b,root),re);});}
test('valid synthetic schema binds real local files; not semantic acceptance',()=>{reset();assert.equal(core.actual(b,root),true);});
bad('human use without actual face review fails',b.story.reviewRecord,x=>delete x.shots[1].faceReview,/actual face review/);
bad('tiny or unclear face fails',b.story.reviewRecord,x=>x.shots[2].faceReview.subjects[0].faceClear=false,/actual face/);
bad('face evidence outside actual shot fails',b.story.reviewRecord,x=>x.shots[1].faceReview.subjects[0].evidence.atSourceSec=13,/outside/);
bad('digital crop split cannot be a cut',b.story.reviewRecord,x=>x.shots[2].continuousCropSplit=true,/actual shot/);
bad('actual cut needs before and after frames',b.story.reviewRecord,x=>delete x.shots[1].cutEvidence,/before\/after/);
bad('same frame cannot prove a cut',b.story.reviewRecord,x=>x.shots[1].cutEvidence.after=e(0,2.55),/distinct frames/);
bad('use scene must be verified in actual material',b.story.reviewRecord,x=>x.shots[2].useSceneVerified=false,/actual use/);
bad('cast or wardrobe continuity failure cannot pass',b.story.reviewRecord,x=>x.shots[1].castContinuity='failed',/cast identity/);
bad('stale source video hash fails',b.story.reviewRecord,x=>x.sourceSha256='changed',/six-shot review/);
bad('unauthorized extra submission fails',b.story.generationRecord,x=>{x.requests.push({...x.requests[0],id:'TEST-EXTRA'});x.submittedThisRound=2;},/submission counts/);
bad('unverified cost cannot be declared known',b.story.generationRecord,x=>x.requests[0].charge={status:'known'},/actual amount/);
bad('video screenshot cannot masquerade as independent scene',b.scenes[0].generationRecord,x=>x.fromVideoFrame=true,/independently generated/);
bad('independent scenes need different generation requests',b.scenes[1].generationRecord,x=>x.requestId='TEST-IMAGE-0',/independently generated/);
bad('unlistened audio cannot pass',b.audioReviewRecord,x=>x.listening='not_checked',/listen/);
test('changed renderer invalidates build fingerprint',()=>{reset();const f=out('src/Root.tsx'),old=fs.readFileSync(f);const before=core.inputState(b,root).fingerprint;try{fs.appendFileSync(f,'\n//TEST change\n');assert.notEqual(core.inputState(b,root).fingerprint,before);}finally{fs.writeFileSync(f,old);}});
test('preview cannot pass formal release',()=>{reset();const f=out('build.json'),old=fs.existsSync(f)?fs.readFileSync(f):null;try{write('build.json',{mode:'preview_pending_review'});assert.throws(()=>core.release(b,root),/preview/);}finally{if(old)fs.writeFileSync(f,old);else fs.unlinkSync(f);}});
test('renamed reference cannot be independent scene',()=>{reset();const f=out('public/scene-1.png'),old=fs.readFileSync(f);try{fs.copyFileSync(out('public/hero.png'),f);assert.throws(()=>core.technicalMedia(b,root),/copied/);}finally{fs.writeFileSync(f,old);}});
