from pathlib import Path
import shutil,subprocess,json,wave,math,os
from PIL import Image,ImageDraw
import argparse
ap=argparse.ArgumentParser();ap.add_argument('--project',required=True);ap.add_argument('--ffmpeg',required=True);ap.add_argument('--node',default='node');args=ap.parse_args()
p=Path(args.project).resolve();template=Path(__file__).resolve().parents[1]/'templates/tvc-template'
if p.exists():raise ValueError('Use a new isolated test directory; never overwrite a product')
shutil.copytree(template,p)
public=p/'public';frames=p/'fixture-frames';frames.mkdir(exist_ok=True)
colors=['#dbe6ec','#e8d9c4','#d5e4c9','#ead9d9','#d8d5e9','#f0e4ba']
for i,c in enumerate(colors):
 im=Image.new('RGB',(640,360),c);d=ImageDraw.Draw(im);d.text((22,20),f'TEST ONLY / SHOT {i+1} / NOT A PRODUCT AD',fill='black');d.polygon([(230,290),(420,290),(390,270),(245,270)],fill='#333');d.polygon([(270,270),(300,135),(350,150),(320,270)],fill='#777');d.ellipse((475,80,525,130),outline='black',width=3);d.line((500,130,500,235),fill='black',width=4);d.line((500,180,350,220),fill='black',width=4);d.ellipse((487,98,491,102),fill='black');d.ellipse((510,98,514,102),fill='black');f=public/f'test-card-{i}.png';im.save(f)
 if i==0:im.save(public/'hero.png')
 if i in [1,2]:im.save(public/f'scene-{i}.png')
 for j in range(60):
  target=frames/f'{i*60+j+1:04d}.png'
  if not target.exists():os.link(f,target)
# short tone stems mark technical-only fixture, never claim human listening or TTS validation.
def wav(name,duration):
 sr=24000
 with wave.open(str(public/name),'wb')as w:
  import numpy as np
  w.setparams((1,2,sr,0,'NONE','not compressed'));t=np.arange(round(duration*sr))/sr;a=.035*np.sin(2*math.pi*330*t);w.writeframes((a*32767).astype('<i2').tobytes())
for i in range(6):wav(f'voice-{i}.wav',.3)
for n in ['music.wav','mix.wav']:wav(n,30)
bin=Path(args.ffmpeg).resolve();env=dict(os.environ,DYLD_LIBRARY_PATH=str(bin.parent))
subprocess.run([str(bin),'-v','error','-y','-framerate','24','-i',str(frames/'%04d.png'),'-c:v','libx264','-crf','20','-pix_fmt','yuv420p',str(public/'story.mp4')],env=env,check=True)
node=args.node;b=json.loads(subprocess.check_output([node,'-e',"console.log(JSON.stringify(require(process.argv[1]).brief()))",str(Path(__file__).with_name('fixture.cjs'))]));(p/'brief.json').write_text(json.dumps(b,ensure_ascii=False,indent=2))
print('Created synthetic technical fixture. Install project dependencies before test:media or rendering. No model calls or acceptance review.')
